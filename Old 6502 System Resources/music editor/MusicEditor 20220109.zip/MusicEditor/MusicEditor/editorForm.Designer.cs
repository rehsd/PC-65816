﻿namespace MusicEditor
{
    partial class editorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(editorForm));
            this.Ch1Oct1 = new System.Windows.Forms.TextBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.musicDataSet = new System.Data.DataSet();
            this.songDataTable = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataColumn73 = new System.Data.DataColumn();
            this.dataColumn74 = new System.Data.DataColumn();
            this.dataColumn75 = new System.Data.DataColumn();
            this.dataColumn109 = new System.Data.DataColumn();
            this.dataColumn110 = new System.Data.DataColumn();
            this.dataColumn111 = new System.Data.DataColumn();
            this.dataColumn145 = new System.Data.DataColumn();
            this.dataColumn146 = new System.Data.DataColumn();
            this.dataColumn147 = new System.Data.DataColumn();
            this.dataColumn181 = new System.Data.DataColumn();
            this.dataColumn182 = new System.Data.DataColumn();
            this.dataColumn183 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn76 = new System.Data.DataColumn();
            this.dataColumn77 = new System.Data.DataColumn();
            this.dataColumn78 = new System.Data.DataColumn();
            this.dataColumn112 = new System.Data.DataColumn();
            this.dataColumn113 = new System.Data.DataColumn();
            this.dataColumn114 = new System.Data.DataColumn();
            this.dataColumn148 = new System.Data.DataColumn();
            this.dataColumn149 = new System.Data.DataColumn();
            this.dataColumn150 = new System.Data.DataColumn();
            this.dataColumn184 = new System.Data.DataColumn();
            this.dataColumn185 = new System.Data.DataColumn();
            this.dataColumn186 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataColumn44 = new System.Data.DataColumn();
            this.dataColumn45 = new System.Data.DataColumn();
            this.dataColumn79 = new System.Data.DataColumn();
            this.dataColumn80 = new System.Data.DataColumn();
            this.dataColumn81 = new System.Data.DataColumn();
            this.dataColumn115 = new System.Data.DataColumn();
            this.dataColumn116 = new System.Data.DataColumn();
            this.dataColumn117 = new System.Data.DataColumn();
            this.dataColumn151 = new System.Data.DataColumn();
            this.dataColumn152 = new System.Data.DataColumn();
            this.dataColumn153 = new System.Data.DataColumn();
            this.dataColumn187 = new System.Data.DataColumn();
            this.dataColumn188 = new System.Data.DataColumn();
            this.dataColumn189 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn46 = new System.Data.DataColumn();
            this.dataColumn47 = new System.Data.DataColumn();
            this.dataColumn48 = new System.Data.DataColumn();
            this.dataColumn82 = new System.Data.DataColumn();
            this.dataColumn83 = new System.Data.DataColumn();
            this.dataColumn84 = new System.Data.DataColumn();
            this.dataColumn118 = new System.Data.DataColumn();
            this.dataColumn119 = new System.Data.DataColumn();
            this.dataColumn120 = new System.Data.DataColumn();
            this.dataColumn154 = new System.Data.DataColumn();
            this.dataColumn155 = new System.Data.DataColumn();
            this.dataColumn156 = new System.Data.DataColumn();
            this.dataColumn190 = new System.Data.DataColumn();
            this.dataColumn191 = new System.Data.DataColumn();
            this.dataColumn192 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn49 = new System.Data.DataColumn();
            this.dataColumn50 = new System.Data.DataColumn();
            this.dataColumn51 = new System.Data.DataColumn();
            this.dataColumn85 = new System.Data.DataColumn();
            this.dataColumn86 = new System.Data.DataColumn();
            this.dataColumn87 = new System.Data.DataColumn();
            this.dataColumn121 = new System.Data.DataColumn();
            this.dataColumn122 = new System.Data.DataColumn();
            this.dataColumn123 = new System.Data.DataColumn();
            this.dataColumn157 = new System.Data.DataColumn();
            this.dataColumn158 = new System.Data.DataColumn();
            this.dataColumn159 = new System.Data.DataColumn();
            this.dataColumn193 = new System.Data.DataColumn();
            this.dataColumn194 = new System.Data.DataColumn();
            this.dataColumn195 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn52 = new System.Data.DataColumn();
            this.dataColumn53 = new System.Data.DataColumn();
            this.dataColumn54 = new System.Data.DataColumn();
            this.dataColumn88 = new System.Data.DataColumn();
            this.dataColumn89 = new System.Data.DataColumn();
            this.dataColumn90 = new System.Data.DataColumn();
            this.dataColumn124 = new System.Data.DataColumn();
            this.dataColumn125 = new System.Data.DataColumn();
            this.dataColumn126 = new System.Data.DataColumn();
            this.dataColumn160 = new System.Data.DataColumn();
            this.dataColumn161 = new System.Data.DataColumn();
            this.dataColumn162 = new System.Data.DataColumn();
            this.dataColumn196 = new System.Data.DataColumn();
            this.dataColumn197 = new System.Data.DataColumn();
            this.dataColumn198 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn55 = new System.Data.DataColumn();
            this.dataColumn56 = new System.Data.DataColumn();
            this.dataColumn57 = new System.Data.DataColumn();
            this.dataColumn91 = new System.Data.DataColumn();
            this.dataColumn92 = new System.Data.DataColumn();
            this.dataColumn93 = new System.Data.DataColumn();
            this.dataColumn127 = new System.Data.DataColumn();
            this.dataColumn128 = new System.Data.DataColumn();
            this.dataColumn129 = new System.Data.DataColumn();
            this.dataColumn163 = new System.Data.DataColumn();
            this.dataColumn164 = new System.Data.DataColumn();
            this.dataColumn165 = new System.Data.DataColumn();
            this.dataColumn199 = new System.Data.DataColumn();
            this.dataColumn200 = new System.Data.DataColumn();
            this.dataColumn201 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn58 = new System.Data.DataColumn();
            this.dataColumn59 = new System.Data.DataColumn();
            this.dataColumn60 = new System.Data.DataColumn();
            this.dataColumn94 = new System.Data.DataColumn();
            this.dataColumn95 = new System.Data.DataColumn();
            this.dataColumn96 = new System.Data.DataColumn();
            this.dataColumn130 = new System.Data.DataColumn();
            this.dataColumn131 = new System.Data.DataColumn();
            this.dataColumn132 = new System.Data.DataColumn();
            this.dataColumn166 = new System.Data.DataColumn();
            this.dataColumn167 = new System.Data.DataColumn();
            this.dataColumn168 = new System.Data.DataColumn();
            this.dataColumn202 = new System.Data.DataColumn();
            this.dataColumn203 = new System.Data.DataColumn();
            this.dataColumn204 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataColumn61 = new System.Data.DataColumn();
            this.dataColumn62 = new System.Data.DataColumn();
            this.dataColumn63 = new System.Data.DataColumn();
            this.dataColumn97 = new System.Data.DataColumn();
            this.dataColumn98 = new System.Data.DataColumn();
            this.dataColumn99 = new System.Data.DataColumn();
            this.dataColumn133 = new System.Data.DataColumn();
            this.dataColumn134 = new System.Data.DataColumn();
            this.dataColumn135 = new System.Data.DataColumn();
            this.dataColumn169 = new System.Data.DataColumn();
            this.dataColumn170 = new System.Data.DataColumn();
            this.dataColumn171 = new System.Data.DataColumn();
            this.dataColumn205 = new System.Data.DataColumn();
            this.dataColumn206 = new System.Data.DataColumn();
            this.dataColumn207 = new System.Data.DataColumn();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn64 = new System.Data.DataColumn();
            this.dataColumn65 = new System.Data.DataColumn();
            this.dataColumn66 = new System.Data.DataColumn();
            this.dataColumn100 = new System.Data.DataColumn();
            this.dataColumn101 = new System.Data.DataColumn();
            this.dataColumn102 = new System.Data.DataColumn();
            this.dataColumn136 = new System.Data.DataColumn();
            this.dataColumn137 = new System.Data.DataColumn();
            this.dataColumn138 = new System.Data.DataColumn();
            this.dataColumn172 = new System.Data.DataColumn();
            this.dataColumn173 = new System.Data.DataColumn();
            this.dataColumn174 = new System.Data.DataColumn();
            this.dataColumn208 = new System.Data.DataColumn();
            this.dataColumn209 = new System.Data.DataColumn();
            this.dataColumn210 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn67 = new System.Data.DataColumn();
            this.dataColumn68 = new System.Data.DataColumn();
            this.dataColumn69 = new System.Data.DataColumn();
            this.dataColumn103 = new System.Data.DataColumn();
            this.dataColumn104 = new System.Data.DataColumn();
            this.dataColumn105 = new System.Data.DataColumn();
            this.dataColumn139 = new System.Data.DataColumn();
            this.dataColumn140 = new System.Data.DataColumn();
            this.dataColumn141 = new System.Data.DataColumn();
            this.dataColumn175 = new System.Data.DataColumn();
            this.dataColumn176 = new System.Data.DataColumn();
            this.dataColumn177 = new System.Data.DataColumn();
            this.dataColumn211 = new System.Data.DataColumn();
            this.dataColumn212 = new System.Data.DataColumn();
            this.dataColumn213 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataColumn70 = new System.Data.DataColumn();
            this.dataColumn71 = new System.Data.DataColumn();
            this.dataColumn72 = new System.Data.DataColumn();
            this.dataColumn106 = new System.Data.DataColumn();
            this.dataColumn107 = new System.Data.DataColumn();
            this.dataColumn108 = new System.Data.DataColumn();
            this.dataColumn142 = new System.Data.DataColumn();
            this.dataColumn143 = new System.Data.DataColumn();
            this.dataColumn144 = new System.Data.DataColumn();
            this.dataColumn178 = new System.Data.DataColumn();
            this.dataColumn179 = new System.Data.DataColumn();
            this.dataColumn180 = new System.Data.DataColumn();
            this.dataColumn214 = new System.Data.DataColumn();
            this.dataColumn215 = new System.Data.DataColumn();
            this.dataColumn216 = new System.Data.DataColumn();
            this.dataColumn217 = new System.Data.DataColumn();
            this.Ch1Tie1 = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Ch1Note1 = new System.Windows.Forms.TextBox();
            this.Ch1Note2 = new System.Windows.Forms.TextBox();
            this.Ch1Oct2 = new System.Windows.Forms.TextBox();
            this.Ch1Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch1Note3 = new System.Windows.Forms.TextBox();
            this.Ch1Oct3 = new System.Windows.Forms.TextBox();
            this.Ch1Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch1Note6 = new System.Windows.Forms.TextBox();
            this.Ch1Oct6 = new System.Windows.Forms.TextBox();
            this.Ch1Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch1Note5 = new System.Windows.Forms.TextBox();
            this.Ch1Oct5 = new System.Windows.Forms.TextBox();
            this.Ch1Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch1Note4 = new System.Windows.Forms.TextBox();
            this.Ch1Oct4 = new System.Windows.Forms.TextBox();
            this.Ch1Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch1Note12 = new System.Windows.Forms.TextBox();
            this.Ch1Oct12 = new System.Windows.Forms.TextBox();
            this.Ch1Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch1Note9 = new System.Windows.Forms.TextBox();
            this.Ch1Oct9 = new System.Windows.Forms.TextBox();
            this.Ch1Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch1Note11 = new System.Windows.Forms.TextBox();
            this.Ch1Oct11 = new System.Windows.Forms.TextBox();
            this.Ch1Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch1Note8 = new System.Windows.Forms.TextBox();
            this.Ch1Oct8 = new System.Windows.Forms.TextBox();
            this.Ch1Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch1Note10 = new System.Windows.Forms.TextBox();
            this.Ch1Oct10 = new System.Windows.Forms.TextBox();
            this.Ch1Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch1Note7 = new System.Windows.Forms.TextBox();
            this.Ch1Oct7 = new System.Windows.Forms.TextBox();
            this.Ch1Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch2Note12 = new System.Windows.Forms.TextBox();
            this.Ch2Oct12 = new System.Windows.Forms.TextBox();
            this.Ch2Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch2Note6 = new System.Windows.Forms.TextBox();
            this.Ch2Oct6 = new System.Windows.Forms.TextBox();
            this.Ch2Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch2Note9 = new System.Windows.Forms.TextBox();
            this.Ch2Oct9 = new System.Windows.Forms.TextBox();
            this.Ch2Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch2Note3 = new System.Windows.Forms.TextBox();
            this.Ch2Oct3 = new System.Windows.Forms.TextBox();
            this.Ch2Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch2Note11 = new System.Windows.Forms.TextBox();
            this.Ch2Oct11 = new System.Windows.Forms.TextBox();
            this.Ch2Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch2Note5 = new System.Windows.Forms.TextBox();
            this.Ch2Oct5 = new System.Windows.Forms.TextBox();
            this.Ch2Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch2Note8 = new System.Windows.Forms.TextBox();
            this.Ch2Oct8 = new System.Windows.Forms.TextBox();
            this.Ch2Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch2Note2 = new System.Windows.Forms.TextBox();
            this.Ch2Oct2 = new System.Windows.Forms.TextBox();
            this.Ch2Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch2Note10 = new System.Windows.Forms.TextBox();
            this.Ch2Oct10 = new System.Windows.Forms.TextBox();
            this.Ch2Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch2Note4 = new System.Windows.Forms.TextBox();
            this.Ch2Oct4 = new System.Windows.Forms.TextBox();
            this.Ch2Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch2Note7 = new System.Windows.Forms.TextBox();
            this.Ch2Oct7 = new System.Windows.Forms.TextBox();
            this.Ch2Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch2Note1 = new System.Windows.Forms.TextBox();
            this.Ch2Oct1 = new System.Windows.Forms.TextBox();
            this.Ch2Tie1 = new System.Windows.Forms.CheckBox();
            this.Ch3Note12 = new System.Windows.Forms.TextBox();
            this.Ch3Oct12 = new System.Windows.Forms.TextBox();
            this.Ch3Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch3Note6 = new System.Windows.Forms.TextBox();
            this.Ch3Oct6 = new System.Windows.Forms.TextBox();
            this.Ch3Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch3Note9 = new System.Windows.Forms.TextBox();
            this.Ch3Oct9 = new System.Windows.Forms.TextBox();
            this.Ch3Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch3Note3 = new System.Windows.Forms.TextBox();
            this.Ch3Oct3 = new System.Windows.Forms.TextBox();
            this.Ch3Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch3Note11 = new System.Windows.Forms.TextBox();
            this.Ch3Oct11 = new System.Windows.Forms.TextBox();
            this.Ch3Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch3Note5 = new System.Windows.Forms.TextBox();
            this.Ch3Oct5 = new System.Windows.Forms.TextBox();
            this.Ch3Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch3Note8 = new System.Windows.Forms.TextBox();
            this.Ch3Oct8 = new System.Windows.Forms.TextBox();
            this.Ch3Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch3Note2 = new System.Windows.Forms.TextBox();
            this.Ch3Oct2 = new System.Windows.Forms.TextBox();
            this.Ch3Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch3Note10 = new System.Windows.Forms.TextBox();
            this.Ch3Oct10 = new System.Windows.Forms.TextBox();
            this.Ch3Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch3Note4 = new System.Windows.Forms.TextBox();
            this.Ch3Oct4 = new System.Windows.Forms.TextBox();
            this.Ch3Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch3Note7 = new System.Windows.Forms.TextBox();
            this.Ch3Oct7 = new System.Windows.Forms.TextBox();
            this.Ch3Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch3Note1 = new System.Windows.Forms.TextBox();
            this.Ch3Oct1 = new System.Windows.Forms.TextBox();
            this.Ch3Tie1 = new System.Windows.Forms.CheckBox();
            this.Ch6Note12 = new System.Windows.Forms.TextBox();
            this.Ch6Oct12 = new System.Windows.Forms.TextBox();
            this.Ch6Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch5Note12 = new System.Windows.Forms.TextBox();
            this.Ch5Oct12 = new System.Windows.Forms.TextBox();
            this.Ch5Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch6Note6 = new System.Windows.Forms.TextBox();
            this.Ch6Oct6 = new System.Windows.Forms.TextBox();
            this.Ch6Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch4Note12 = new System.Windows.Forms.TextBox();
            this.Ch4Oct12 = new System.Windows.Forms.TextBox();
            this.Ch4Tie12 = new System.Windows.Forms.CheckBox();
            this.Ch6Note9 = new System.Windows.Forms.TextBox();
            this.Ch6Oct9 = new System.Windows.Forms.TextBox();
            this.Ch6Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch5Note6 = new System.Windows.Forms.TextBox();
            this.Ch5Oct6 = new System.Windows.Forms.TextBox();
            this.Ch5Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch6Note3 = new System.Windows.Forms.TextBox();
            this.Ch6Oct3 = new System.Windows.Forms.TextBox();
            this.Ch6Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch4Note6 = new System.Windows.Forms.TextBox();
            this.Ch4Oct6 = new System.Windows.Forms.TextBox();
            this.Ch4Tie6 = new System.Windows.Forms.CheckBox();
            this.Ch6Note11 = new System.Windows.Forms.TextBox();
            this.Ch6Oct11 = new System.Windows.Forms.TextBox();
            this.Ch6Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch5Note9 = new System.Windows.Forms.TextBox();
            this.Ch5Oct9 = new System.Windows.Forms.TextBox();
            this.Ch5Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch6Note5 = new System.Windows.Forms.TextBox();
            this.Ch6Oct5 = new System.Windows.Forms.TextBox();
            this.Ch6Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch4Note9 = new System.Windows.Forms.TextBox();
            this.Ch4Oct9 = new System.Windows.Forms.TextBox();
            this.Ch4Tie9 = new System.Windows.Forms.CheckBox();
            this.Ch6Note8 = new System.Windows.Forms.TextBox();
            this.Ch6Oct8 = new System.Windows.Forms.TextBox();
            this.Ch6Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch5Note3 = new System.Windows.Forms.TextBox();
            this.Ch5Oct3 = new System.Windows.Forms.TextBox();
            this.Ch5Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch6Note2 = new System.Windows.Forms.TextBox();
            this.Ch6Oct2 = new System.Windows.Forms.TextBox();
            this.Ch6Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch4Note3 = new System.Windows.Forms.TextBox();
            this.Ch4Oct3 = new System.Windows.Forms.TextBox();
            this.Ch4Tie3 = new System.Windows.Forms.CheckBox();
            this.Ch6Note10 = new System.Windows.Forms.TextBox();
            this.Ch6Oct10 = new System.Windows.Forms.TextBox();
            this.Ch6Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch5Note11 = new System.Windows.Forms.TextBox();
            this.Ch5Oct11 = new System.Windows.Forms.TextBox();
            this.Ch5Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch6Note4 = new System.Windows.Forms.TextBox();
            this.Ch6Oct4 = new System.Windows.Forms.TextBox();
            this.Ch6Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch4Note11 = new System.Windows.Forms.TextBox();
            this.Ch4Oct11 = new System.Windows.Forms.TextBox();
            this.Ch4Tie11 = new System.Windows.Forms.CheckBox();
            this.Ch6Note7 = new System.Windows.Forms.TextBox();
            this.Ch6Oct7 = new System.Windows.Forms.TextBox();
            this.Ch6Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch6Note1 = new System.Windows.Forms.TextBox();
            this.Ch6Oct1 = new System.Windows.Forms.TextBox();
            this.Ch6Tie1 = new System.Windows.Forms.CheckBox();
            this.Ch5Note5 = new System.Windows.Forms.TextBox();
            this.Ch5Oct5 = new System.Windows.Forms.TextBox();
            this.Ch5Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch4Note5 = new System.Windows.Forms.TextBox();
            this.Ch4Oct5 = new System.Windows.Forms.TextBox();
            this.Ch4Tie5 = new System.Windows.Forms.CheckBox();
            this.Ch5Note8 = new System.Windows.Forms.TextBox();
            this.Ch5Oct8 = new System.Windows.Forms.TextBox();
            this.Ch5Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch4Note8 = new System.Windows.Forms.TextBox();
            this.Ch4Oct8 = new System.Windows.Forms.TextBox();
            this.Ch4Tie8 = new System.Windows.Forms.CheckBox();
            this.Ch5Note2 = new System.Windows.Forms.TextBox();
            this.Ch5Oct2 = new System.Windows.Forms.TextBox();
            this.Ch5Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch4Note2 = new System.Windows.Forms.TextBox();
            this.Ch4Oct2 = new System.Windows.Forms.TextBox();
            this.Ch4Tie2 = new System.Windows.Forms.CheckBox();
            this.Ch5Note10 = new System.Windows.Forms.TextBox();
            this.Ch5Oct10 = new System.Windows.Forms.TextBox();
            this.Ch5Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch4Note10 = new System.Windows.Forms.TextBox();
            this.Ch4Oct10 = new System.Windows.Forms.TextBox();
            this.Ch4Tie10 = new System.Windows.Forms.CheckBox();
            this.Ch5Note4 = new System.Windows.Forms.TextBox();
            this.Ch5Oct4 = new System.Windows.Forms.TextBox();
            this.Ch5Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch4Note4 = new System.Windows.Forms.TextBox();
            this.Ch4Oct4 = new System.Windows.Forms.TextBox();
            this.Ch4Tie4 = new System.Windows.Forms.CheckBox();
            this.Ch5Note7 = new System.Windows.Forms.TextBox();
            this.Ch5Oct7 = new System.Windows.Forms.TextBox();
            this.Ch5Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch4Note7 = new System.Windows.Forms.TextBox();
            this.Ch4Oct7 = new System.Windows.Forms.TextBox();
            this.Ch4Tie7 = new System.Windows.Forms.CheckBox();
            this.Ch5Note1 = new System.Windows.Forms.TextBox();
            this.Ch5Oct1 = new System.Windows.Forms.TextBox();
            this.Ch5Tie1 = new System.Windows.Forms.CheckBox();
            this.Ch4Note1 = new System.Windows.Forms.TextBox();
            this.Ch4Oct1 = new System.Windows.Forms.TextBox();
            this.Ch4Tie1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.groupBox55 = new System.Windows.Forms.GroupBox();
            this.groupBox56 = new System.Windows.Forms.GroupBox();
            this.groupBox57 = new System.Windows.Forms.GroupBox();
            this.groupBox58 = new System.Windows.Forms.GroupBox();
            this.groupBox59 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox60 = new System.Windows.Forms.GroupBox();
            this.groupBox61 = new System.Windows.Forms.GroupBox();
            this.groupBox62 = new System.Windows.Forms.GroupBox();
            this.groupBox63 = new System.Windows.Forms.GroupBox();
            this.groupBox64 = new System.Windows.Forms.GroupBox();
            this.groupBox65 = new System.Windows.Forms.GroupBox();
            this.groupBox66 = new System.Windows.Forms.GroupBox();
            this.groupBox67 = new System.Windows.Forms.GroupBox();
            this.groupBox68 = new System.Windows.Forms.GroupBox();
            this.groupBox69 = new System.Windows.Forms.GroupBox();
            this.groupBox70 = new System.Windows.Forms.GroupBox();
            this.groupBox71 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox72 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newButton = new System.Windows.Forms.ToolStripButton();
            this.openMusicButton = new System.Windows.Forms.ToolStripButton();
            this.saveMusicButton = new System.Windows.Forms.ToolStripButton();
            this.exportMusicButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.monoStereoDropDown = new System.Windows.Forms.ToolStripComboBox();
            this.leftRightComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.addMeasureButton = new System.Windows.Forms.ToolStripButton();
            this.deleteMeasureButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.prevMeasure = new System.Windows.Forms.ToolStripButton();
            this.currentRecordLabel = new System.Windows.Forms.ToolStripLabel();
            this.nextMeasure = new System.Windows.Forms.ToolStripButton();
            this.saveMeasureButton = new System.Windows.Forms.ToolStripButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.tickDenomTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.musicDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.songDataTable)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.groupBox55.SuspendLayout();
            this.groupBox56.SuspendLayout();
            this.groupBox57.SuspendLayout();
            this.groupBox58.SuspendLayout();
            this.groupBox59.SuspendLayout();
            this.groupBox60.SuspendLayout();
            this.groupBox61.SuspendLayout();
            this.groupBox62.SuspendLayout();
            this.groupBox63.SuspendLayout();
            this.groupBox64.SuspendLayout();
            this.groupBox65.SuspendLayout();
            this.groupBox66.SuspendLayout();
            this.groupBox67.SuspendLayout();
            this.groupBox68.SuspendLayout();
            this.groupBox69.SuspendLayout();
            this.groupBox70.SuspendLayout();
            this.groupBox71.SuspendLayout();
            this.groupBox72.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Ch1Oct1
            // 
            this.Ch1Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct1", true));
            this.Ch1Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct1.Name = "Ch1Oct1";
            this.Ch1Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct1.TabIndex = 1;
            this.toolTip1.SetToolTip(this.Ch1Oct1, "Octave");
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Song";
            this.bindingSource1.DataSource = this.musicDataSet;
            this.bindingSource1.PositionChanged += new System.EventHandler(this.bindingSource1_PositionChanged);
            // 
            // musicDataSet
            // 
            this.musicDataSet.DataSetName = "NewDataSet";
            this.musicDataSet.Tables.AddRange(new System.Data.DataTable[] {
            this.songDataTable});
            // 
            // songDataTable
            // 
            this.songDataTable.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn37,
            this.dataColumn38,
            this.dataColumn39,
            this.dataColumn73,
            this.dataColumn74,
            this.dataColumn75,
            this.dataColumn109,
            this.dataColumn110,
            this.dataColumn111,
            this.dataColumn145,
            this.dataColumn146,
            this.dataColumn147,
            this.dataColumn181,
            this.dataColumn182,
            this.dataColumn183,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn40,
            this.dataColumn41,
            this.dataColumn42,
            this.dataColumn76,
            this.dataColumn77,
            this.dataColumn78,
            this.dataColumn112,
            this.dataColumn113,
            this.dataColumn114,
            this.dataColumn148,
            this.dataColumn149,
            this.dataColumn150,
            this.dataColumn184,
            this.dataColumn185,
            this.dataColumn186,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn43,
            this.dataColumn44,
            this.dataColumn45,
            this.dataColumn79,
            this.dataColumn80,
            this.dataColumn81,
            this.dataColumn115,
            this.dataColumn116,
            this.dataColumn117,
            this.dataColumn151,
            this.dataColumn152,
            this.dataColumn153,
            this.dataColumn187,
            this.dataColumn188,
            this.dataColumn189,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn46,
            this.dataColumn47,
            this.dataColumn48,
            this.dataColumn82,
            this.dataColumn83,
            this.dataColumn84,
            this.dataColumn118,
            this.dataColumn119,
            this.dataColumn120,
            this.dataColumn154,
            this.dataColumn155,
            this.dataColumn156,
            this.dataColumn190,
            this.dataColumn191,
            this.dataColumn192,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn49,
            this.dataColumn50,
            this.dataColumn51,
            this.dataColumn85,
            this.dataColumn86,
            this.dataColumn87,
            this.dataColumn121,
            this.dataColumn122,
            this.dataColumn123,
            this.dataColumn157,
            this.dataColumn158,
            this.dataColumn159,
            this.dataColumn193,
            this.dataColumn194,
            this.dataColumn195,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn52,
            this.dataColumn53,
            this.dataColumn54,
            this.dataColumn88,
            this.dataColumn89,
            this.dataColumn90,
            this.dataColumn124,
            this.dataColumn125,
            this.dataColumn126,
            this.dataColumn160,
            this.dataColumn161,
            this.dataColumn162,
            this.dataColumn196,
            this.dataColumn197,
            this.dataColumn198,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn55,
            this.dataColumn56,
            this.dataColumn57,
            this.dataColumn91,
            this.dataColumn92,
            this.dataColumn93,
            this.dataColumn127,
            this.dataColumn128,
            this.dataColumn129,
            this.dataColumn163,
            this.dataColumn164,
            this.dataColumn165,
            this.dataColumn199,
            this.dataColumn200,
            this.dataColumn201,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn58,
            this.dataColumn59,
            this.dataColumn60,
            this.dataColumn94,
            this.dataColumn95,
            this.dataColumn96,
            this.dataColumn130,
            this.dataColumn131,
            this.dataColumn132,
            this.dataColumn166,
            this.dataColumn167,
            this.dataColumn168,
            this.dataColumn202,
            this.dataColumn203,
            this.dataColumn204,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27,
            this.dataColumn61,
            this.dataColumn62,
            this.dataColumn63,
            this.dataColumn97,
            this.dataColumn98,
            this.dataColumn99,
            this.dataColumn133,
            this.dataColumn134,
            this.dataColumn135,
            this.dataColumn169,
            this.dataColumn170,
            this.dataColumn171,
            this.dataColumn205,
            this.dataColumn206,
            this.dataColumn207,
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn64,
            this.dataColumn65,
            this.dataColumn66,
            this.dataColumn100,
            this.dataColumn101,
            this.dataColumn102,
            this.dataColumn136,
            this.dataColumn137,
            this.dataColumn138,
            this.dataColumn172,
            this.dataColumn173,
            this.dataColumn174,
            this.dataColumn208,
            this.dataColumn209,
            this.dataColumn210,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn67,
            this.dataColumn68,
            this.dataColumn69,
            this.dataColumn103,
            this.dataColumn104,
            this.dataColumn105,
            this.dataColumn139,
            this.dataColumn140,
            this.dataColumn141,
            this.dataColumn175,
            this.dataColumn176,
            this.dataColumn177,
            this.dataColumn211,
            this.dataColumn212,
            this.dataColumn213,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36,
            this.dataColumn70,
            this.dataColumn71,
            this.dataColumn72,
            this.dataColumn106,
            this.dataColumn107,
            this.dataColumn108,
            this.dataColumn142,
            this.dataColumn143,
            this.dataColumn144,
            this.dataColumn178,
            this.dataColumn179,
            this.dataColumn180,
            this.dataColumn214,
            this.dataColumn215,
            this.dataColumn216,
            this.dataColumn217});
            this.songDataTable.TableName = "Song";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "Ch1Note1";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "Ch1Oct1";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "Ch1Tie1";
            this.dataColumn3.DataType = typeof(bool);
            this.dataColumn3.DefaultValue = false;
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "Ch2Note1";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "Ch2Oct1";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "Ch2Tie1";
            this.dataColumn39.DataType = typeof(bool);
            this.dataColumn39.DefaultValue = false;
            // 
            // dataColumn73
            // 
            this.dataColumn73.ColumnName = "Ch3Note1";
            // 
            // dataColumn74
            // 
            this.dataColumn74.ColumnName = "Ch3Oct1";
            // 
            // dataColumn75
            // 
            this.dataColumn75.ColumnName = "Ch3Tie1";
            this.dataColumn75.DataType = typeof(bool);
            this.dataColumn75.DefaultValue = false;
            // 
            // dataColumn109
            // 
            this.dataColumn109.ColumnName = "Ch4Note1";
            // 
            // dataColumn110
            // 
            this.dataColumn110.ColumnName = "Ch4Oct1";
            // 
            // dataColumn111
            // 
            this.dataColumn111.ColumnName = "Ch4Tie1";
            this.dataColumn111.DataType = typeof(bool);
            this.dataColumn111.DefaultValue = false;
            // 
            // dataColumn145
            // 
            this.dataColumn145.ColumnName = "Ch5Note1";
            // 
            // dataColumn146
            // 
            this.dataColumn146.ColumnName = "Ch5Oct1";
            // 
            // dataColumn147
            // 
            this.dataColumn147.ColumnName = "Ch5Tie1";
            this.dataColumn147.DataType = typeof(bool);
            this.dataColumn147.DefaultValue = false;
            // 
            // dataColumn181
            // 
            this.dataColumn181.ColumnName = "Ch6Note1";
            // 
            // dataColumn182
            // 
            this.dataColumn182.ColumnName = "Ch6Oct1";
            // 
            // dataColumn183
            // 
            this.dataColumn183.ColumnName = "Ch6Tie1";
            this.dataColumn183.DataType = typeof(bool);
            this.dataColumn183.DefaultValue = false;
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "Ch1Note2";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "Ch1Oct2";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "Ch1Tie2";
            this.dataColumn6.DataType = typeof(bool);
            this.dataColumn6.DefaultValue = false;
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "Ch2Note2";
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "Ch2Oct2";
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "Ch2Tie2";
            this.dataColumn42.DataType = typeof(bool);
            this.dataColumn42.DefaultValue = false;
            // 
            // dataColumn76
            // 
            this.dataColumn76.ColumnName = "Ch3Note2";
            // 
            // dataColumn77
            // 
            this.dataColumn77.ColumnName = "Ch3Oct2";
            // 
            // dataColumn78
            // 
            this.dataColumn78.ColumnName = "Ch3Tie2";
            this.dataColumn78.DataType = typeof(bool);
            this.dataColumn78.DefaultValue = false;
            // 
            // dataColumn112
            // 
            this.dataColumn112.ColumnName = "Ch4Note2";
            // 
            // dataColumn113
            // 
            this.dataColumn113.ColumnName = "Ch4Oct2";
            // 
            // dataColumn114
            // 
            this.dataColumn114.ColumnName = "Ch4Tie2";
            this.dataColumn114.DataType = typeof(bool);
            this.dataColumn114.DefaultValue = false;
            // 
            // dataColumn148
            // 
            this.dataColumn148.ColumnName = "Ch5Note2";
            // 
            // dataColumn149
            // 
            this.dataColumn149.ColumnName = "Ch5Oct2";
            // 
            // dataColumn150
            // 
            this.dataColumn150.ColumnName = "Ch5Tie2";
            this.dataColumn150.DataType = typeof(bool);
            this.dataColumn150.DefaultValue = false;
            // 
            // dataColumn184
            // 
            this.dataColumn184.ColumnName = "Ch6Note2";
            // 
            // dataColumn185
            // 
            this.dataColumn185.ColumnName = "Ch6Oct2";
            // 
            // dataColumn186
            // 
            this.dataColumn186.ColumnName = "Ch6Tie2";
            this.dataColumn186.DataType = typeof(bool);
            this.dataColumn186.DefaultValue = false;
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "Ch1Note3";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "Ch1Oct3";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "Ch1Tie3";
            this.dataColumn9.DataType = typeof(bool);
            this.dataColumn9.DefaultValue = false;
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "Ch2Note3";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "Ch2Oct3";
            // 
            // dataColumn45
            // 
            this.dataColumn45.ColumnName = "Ch2Tie3";
            this.dataColumn45.DataType = typeof(bool);
            this.dataColumn45.DefaultValue = false;
            // 
            // dataColumn79
            // 
            this.dataColumn79.ColumnName = "Ch3Note3";
            // 
            // dataColumn80
            // 
            this.dataColumn80.ColumnName = "Ch3Oct3";
            // 
            // dataColumn81
            // 
            this.dataColumn81.ColumnName = "Ch3Tie3";
            this.dataColumn81.DataType = typeof(bool);
            this.dataColumn81.DefaultValue = false;
            // 
            // dataColumn115
            // 
            this.dataColumn115.ColumnName = "Ch4Note3";
            // 
            // dataColumn116
            // 
            this.dataColumn116.ColumnName = "Ch4Oct3";
            // 
            // dataColumn117
            // 
            this.dataColumn117.ColumnName = "Ch4Tie3";
            this.dataColumn117.DataType = typeof(bool);
            this.dataColumn117.DefaultValue = false;
            // 
            // dataColumn151
            // 
            this.dataColumn151.ColumnName = "Ch5Note3";
            // 
            // dataColumn152
            // 
            this.dataColumn152.ColumnName = "Ch5Oct3";
            // 
            // dataColumn153
            // 
            this.dataColumn153.ColumnName = "Ch5Tie3";
            this.dataColumn153.DataType = typeof(bool);
            this.dataColumn153.DefaultValue = false;
            // 
            // dataColumn187
            // 
            this.dataColumn187.ColumnName = "Ch6Note3";
            // 
            // dataColumn188
            // 
            this.dataColumn188.ColumnName = "Ch6Oct3";
            // 
            // dataColumn189
            // 
            this.dataColumn189.ColumnName = "Ch6Tie3";
            this.dataColumn189.DataType = typeof(bool);
            this.dataColumn189.DefaultValue = false;
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "Ch1Note4";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "Ch1Oct4";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "Ch1Tie4";
            this.dataColumn12.DataType = typeof(bool);
            this.dataColumn12.DefaultValue = false;
            // 
            // dataColumn46
            // 
            this.dataColumn46.ColumnName = "Ch2Note4";
            // 
            // dataColumn47
            // 
            this.dataColumn47.ColumnName = "Ch2Oct4";
            // 
            // dataColumn48
            // 
            this.dataColumn48.ColumnName = "Ch2Tie4";
            this.dataColumn48.DataType = typeof(bool);
            this.dataColumn48.DefaultValue = false;
            // 
            // dataColumn82
            // 
            this.dataColumn82.ColumnName = "Ch3Note4";
            // 
            // dataColumn83
            // 
            this.dataColumn83.ColumnName = "Ch3Oct4";
            // 
            // dataColumn84
            // 
            this.dataColumn84.ColumnName = "Ch3Tie4";
            this.dataColumn84.DataType = typeof(bool);
            this.dataColumn84.DefaultValue = false;
            // 
            // dataColumn118
            // 
            this.dataColumn118.ColumnName = "Ch4Note4";
            // 
            // dataColumn119
            // 
            this.dataColumn119.ColumnName = "Ch4Oct4";
            // 
            // dataColumn120
            // 
            this.dataColumn120.ColumnName = "Ch4Tie4";
            this.dataColumn120.DataType = typeof(bool);
            this.dataColumn120.DefaultValue = false;
            // 
            // dataColumn154
            // 
            this.dataColumn154.ColumnName = "Ch5Note4";
            // 
            // dataColumn155
            // 
            this.dataColumn155.ColumnName = "Ch5Oct4";
            // 
            // dataColumn156
            // 
            this.dataColumn156.ColumnName = "Ch5Tie4";
            this.dataColumn156.DataType = typeof(bool);
            this.dataColumn156.DefaultValue = false;
            // 
            // dataColumn190
            // 
            this.dataColumn190.ColumnName = "Ch6Note4";
            // 
            // dataColumn191
            // 
            this.dataColumn191.ColumnName = "Ch6Oct4";
            // 
            // dataColumn192
            // 
            this.dataColumn192.ColumnName = "Ch6Tie4";
            this.dataColumn192.DataType = typeof(bool);
            this.dataColumn192.DefaultValue = false;
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "Ch1Note5";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "Ch1Oct5";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "Ch1Tie5";
            this.dataColumn15.DataType = typeof(bool);
            this.dataColumn15.DefaultValue = false;
            // 
            // dataColumn49
            // 
            this.dataColumn49.ColumnName = "Ch2Note5";
            // 
            // dataColumn50
            // 
            this.dataColumn50.ColumnName = "Ch2Oct5";
            // 
            // dataColumn51
            // 
            this.dataColumn51.ColumnName = "Ch2Tie5";
            this.dataColumn51.DataType = typeof(bool);
            this.dataColumn51.DefaultValue = false;
            // 
            // dataColumn85
            // 
            this.dataColumn85.ColumnName = "Ch3Note5";
            // 
            // dataColumn86
            // 
            this.dataColumn86.ColumnName = "Ch3Oct5";
            // 
            // dataColumn87
            // 
            this.dataColumn87.ColumnName = "Ch3Tie5";
            this.dataColumn87.DataType = typeof(bool);
            this.dataColumn87.DefaultValue = false;
            // 
            // dataColumn121
            // 
            this.dataColumn121.ColumnName = "Ch4Note5";
            // 
            // dataColumn122
            // 
            this.dataColumn122.ColumnName = "Ch4Oct5";
            // 
            // dataColumn123
            // 
            this.dataColumn123.ColumnName = "Ch4Tie5";
            this.dataColumn123.DataType = typeof(bool);
            this.dataColumn123.DefaultValue = false;
            // 
            // dataColumn157
            // 
            this.dataColumn157.ColumnName = "Ch5Note5";
            // 
            // dataColumn158
            // 
            this.dataColumn158.ColumnName = "Ch5Oct5";
            // 
            // dataColumn159
            // 
            this.dataColumn159.ColumnName = "Ch5Tie5";
            this.dataColumn159.DataType = typeof(bool);
            this.dataColumn159.DefaultValue = false;
            // 
            // dataColumn193
            // 
            this.dataColumn193.ColumnName = "Ch6Note5";
            // 
            // dataColumn194
            // 
            this.dataColumn194.ColumnName = "Ch6Oct5";
            // 
            // dataColumn195
            // 
            this.dataColumn195.ColumnName = "Ch6Tie5";
            this.dataColumn195.DataType = typeof(bool);
            this.dataColumn195.DefaultValue = false;
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "Ch1Note6";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "Ch1Oct6";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "Ch1Tie6";
            this.dataColumn18.DataType = typeof(bool);
            this.dataColumn18.DefaultValue = false;
            // 
            // dataColumn52
            // 
            this.dataColumn52.ColumnName = "Ch2Note6";
            // 
            // dataColumn53
            // 
            this.dataColumn53.ColumnName = "Ch2Oct6";
            // 
            // dataColumn54
            // 
            this.dataColumn54.ColumnName = "Ch2Tie6";
            this.dataColumn54.DataType = typeof(bool);
            this.dataColumn54.DefaultValue = false;
            // 
            // dataColumn88
            // 
            this.dataColumn88.ColumnName = "Ch3Note6";
            // 
            // dataColumn89
            // 
            this.dataColumn89.ColumnName = "Ch3Oct6";
            // 
            // dataColumn90
            // 
            this.dataColumn90.ColumnName = "Ch3Tie6";
            this.dataColumn90.DataType = typeof(bool);
            this.dataColumn90.DefaultValue = false;
            // 
            // dataColumn124
            // 
            this.dataColumn124.ColumnName = "Ch4Note6";
            // 
            // dataColumn125
            // 
            this.dataColumn125.ColumnName = "Ch4Oct6";
            // 
            // dataColumn126
            // 
            this.dataColumn126.ColumnName = "Ch4Tie6";
            this.dataColumn126.DataType = typeof(bool);
            this.dataColumn126.DefaultValue = false;
            // 
            // dataColumn160
            // 
            this.dataColumn160.ColumnName = "Ch5Note6";
            // 
            // dataColumn161
            // 
            this.dataColumn161.ColumnName = "Ch5Oct6";
            // 
            // dataColumn162
            // 
            this.dataColumn162.ColumnName = "Ch5Tie6";
            this.dataColumn162.DataType = typeof(bool);
            this.dataColumn162.DefaultValue = false;
            // 
            // dataColumn196
            // 
            this.dataColumn196.ColumnName = "Ch6Note6";
            // 
            // dataColumn197
            // 
            this.dataColumn197.ColumnName = "Ch6Oct6";
            // 
            // dataColumn198
            // 
            this.dataColumn198.ColumnName = "Ch6Tie6";
            this.dataColumn198.DataType = typeof(bool);
            this.dataColumn198.DefaultValue = false;
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "Ch1Note7";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "Ch1Oct7";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "Ch1Tie7";
            this.dataColumn21.DataType = typeof(bool);
            this.dataColumn21.DefaultValue = false;
            // 
            // dataColumn55
            // 
            this.dataColumn55.ColumnName = "Ch2Note7";
            // 
            // dataColumn56
            // 
            this.dataColumn56.ColumnName = "Ch2Oct7";
            // 
            // dataColumn57
            // 
            this.dataColumn57.ColumnName = "Ch2Tie7";
            this.dataColumn57.DataType = typeof(bool);
            this.dataColumn57.DefaultValue = false;
            // 
            // dataColumn91
            // 
            this.dataColumn91.ColumnName = "Ch3Note7";
            // 
            // dataColumn92
            // 
            this.dataColumn92.ColumnName = "Ch3Oct7";
            // 
            // dataColumn93
            // 
            this.dataColumn93.ColumnName = "Ch3Tie7";
            this.dataColumn93.DataType = typeof(bool);
            this.dataColumn93.DefaultValue = false;
            // 
            // dataColumn127
            // 
            this.dataColumn127.ColumnName = "Ch4Note7";
            // 
            // dataColumn128
            // 
            this.dataColumn128.ColumnName = "Ch4Oct7";
            // 
            // dataColumn129
            // 
            this.dataColumn129.ColumnName = "Ch4Tie7";
            this.dataColumn129.DataType = typeof(bool);
            this.dataColumn129.DefaultValue = false;
            // 
            // dataColumn163
            // 
            this.dataColumn163.ColumnName = "Ch5Note7";
            // 
            // dataColumn164
            // 
            this.dataColumn164.ColumnName = "Ch5Oct7";
            // 
            // dataColumn165
            // 
            this.dataColumn165.ColumnName = "Ch5Tie7";
            this.dataColumn165.DataType = typeof(bool);
            this.dataColumn165.DefaultValue = false;
            // 
            // dataColumn199
            // 
            this.dataColumn199.ColumnName = "Ch6Note7";
            // 
            // dataColumn200
            // 
            this.dataColumn200.ColumnName = "Ch6Oct7";
            // 
            // dataColumn201
            // 
            this.dataColumn201.ColumnName = "Ch6Tie7";
            this.dataColumn201.DataType = typeof(bool);
            this.dataColumn201.DefaultValue = false;
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "Ch1Note8";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "Ch1Oct8";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "Ch1Tie8";
            this.dataColumn24.DataType = typeof(bool);
            this.dataColumn24.DefaultValue = false;
            // 
            // dataColumn58
            // 
            this.dataColumn58.ColumnName = "Ch2Note8";
            // 
            // dataColumn59
            // 
            this.dataColumn59.ColumnName = "Ch2Oct8";
            // 
            // dataColumn60
            // 
            this.dataColumn60.ColumnName = "Ch2Tie8";
            this.dataColumn60.DataType = typeof(bool);
            this.dataColumn60.DefaultValue = false;
            // 
            // dataColumn94
            // 
            this.dataColumn94.ColumnName = "Ch3Note8";
            // 
            // dataColumn95
            // 
            this.dataColumn95.ColumnName = "Ch3Oct8";
            // 
            // dataColumn96
            // 
            this.dataColumn96.ColumnName = "Ch3Tie8";
            this.dataColumn96.DataType = typeof(bool);
            this.dataColumn96.DefaultValue = false;
            // 
            // dataColumn130
            // 
            this.dataColumn130.ColumnName = "Ch4Note8";
            // 
            // dataColumn131
            // 
            this.dataColumn131.ColumnName = "Ch4Oct8";
            // 
            // dataColumn132
            // 
            this.dataColumn132.ColumnName = "Ch4Tie8";
            this.dataColumn132.DataType = typeof(bool);
            this.dataColumn132.DefaultValue = false;
            // 
            // dataColumn166
            // 
            this.dataColumn166.ColumnName = "Ch5Note8";
            // 
            // dataColumn167
            // 
            this.dataColumn167.ColumnName = "Ch5Oct8";
            // 
            // dataColumn168
            // 
            this.dataColumn168.ColumnName = "Ch5Tie8";
            this.dataColumn168.DataType = typeof(bool);
            this.dataColumn168.DefaultValue = false;
            // 
            // dataColumn202
            // 
            this.dataColumn202.ColumnName = "Ch6Note8";
            // 
            // dataColumn203
            // 
            this.dataColumn203.ColumnName = "Ch6Oct8";
            // 
            // dataColumn204
            // 
            this.dataColumn204.ColumnName = "Ch6Tie8";
            this.dataColumn204.DataType = typeof(bool);
            this.dataColumn204.DefaultValue = false;
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "Ch1Note9";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "Ch1Oct9";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "Ch1Tie9";
            this.dataColumn27.DataType = typeof(bool);
            this.dataColumn27.DefaultValue = false;
            // 
            // dataColumn61
            // 
            this.dataColumn61.ColumnName = "Ch2Note9";
            // 
            // dataColumn62
            // 
            this.dataColumn62.ColumnName = "Ch2Oct9";
            // 
            // dataColumn63
            // 
            this.dataColumn63.ColumnName = "Ch2Tie9";
            this.dataColumn63.DataType = typeof(bool);
            this.dataColumn63.DefaultValue = false;
            // 
            // dataColumn97
            // 
            this.dataColumn97.ColumnName = "Ch3Note9";
            // 
            // dataColumn98
            // 
            this.dataColumn98.ColumnName = "Ch3Oct9";
            // 
            // dataColumn99
            // 
            this.dataColumn99.ColumnName = "Ch3Tie9";
            this.dataColumn99.DataType = typeof(bool);
            this.dataColumn99.DefaultValue = false;
            // 
            // dataColumn133
            // 
            this.dataColumn133.ColumnName = "Ch4Note9";
            // 
            // dataColumn134
            // 
            this.dataColumn134.ColumnName = "Ch4Oct9";
            // 
            // dataColumn135
            // 
            this.dataColumn135.ColumnName = "Ch4Tie9";
            this.dataColumn135.DataType = typeof(bool);
            this.dataColumn135.DefaultValue = false;
            // 
            // dataColumn169
            // 
            this.dataColumn169.ColumnName = "Ch5Note9";
            // 
            // dataColumn170
            // 
            this.dataColumn170.ColumnName = "Ch5Oct9";
            // 
            // dataColumn171
            // 
            this.dataColumn171.ColumnName = "Ch5Tie9";
            this.dataColumn171.DataType = typeof(bool);
            this.dataColumn171.DefaultValue = false;
            // 
            // dataColumn205
            // 
            this.dataColumn205.ColumnName = "Ch6Note9";
            // 
            // dataColumn206
            // 
            this.dataColumn206.ColumnName = "Ch6Oct9";
            // 
            // dataColumn207
            // 
            this.dataColumn207.ColumnName = "Ch6Tie9";
            this.dataColumn207.DataType = typeof(bool);
            this.dataColumn207.DefaultValue = false;
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "Ch1Note10";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "Ch1Oct10";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "Ch1Tie10";
            this.dataColumn30.DataType = typeof(bool);
            this.dataColumn30.DefaultValue = false;
            // 
            // dataColumn64
            // 
            this.dataColumn64.ColumnName = "Ch2Note10";
            // 
            // dataColumn65
            // 
            this.dataColumn65.ColumnName = "Ch2Oct10";
            // 
            // dataColumn66
            // 
            this.dataColumn66.ColumnName = "Ch2Tie10";
            this.dataColumn66.DataType = typeof(bool);
            this.dataColumn66.DefaultValue = false;
            // 
            // dataColumn100
            // 
            this.dataColumn100.ColumnName = "Ch3Note10";
            // 
            // dataColumn101
            // 
            this.dataColumn101.ColumnName = "Ch3Oct10";
            // 
            // dataColumn102
            // 
            this.dataColumn102.ColumnName = "Ch3Tie10";
            this.dataColumn102.DataType = typeof(bool);
            this.dataColumn102.DefaultValue = false;
            // 
            // dataColumn136
            // 
            this.dataColumn136.ColumnName = "Ch4Note10";
            // 
            // dataColumn137
            // 
            this.dataColumn137.ColumnName = "Ch4Oct10";
            // 
            // dataColumn138
            // 
            this.dataColumn138.ColumnName = "Ch4Tie10";
            this.dataColumn138.DataType = typeof(bool);
            this.dataColumn138.DefaultValue = false;
            // 
            // dataColumn172
            // 
            this.dataColumn172.ColumnName = "Ch5Note10";
            // 
            // dataColumn173
            // 
            this.dataColumn173.ColumnName = "Ch5Oct10";
            // 
            // dataColumn174
            // 
            this.dataColumn174.ColumnName = "Ch5Tie10";
            this.dataColumn174.DataType = typeof(bool);
            this.dataColumn174.DefaultValue = false;
            // 
            // dataColumn208
            // 
            this.dataColumn208.ColumnName = "Ch6Note10";
            // 
            // dataColumn209
            // 
            this.dataColumn209.ColumnName = "Ch6Oct10";
            // 
            // dataColumn210
            // 
            this.dataColumn210.ColumnName = "Ch6Tie10";
            this.dataColumn210.DataType = typeof(bool);
            this.dataColumn210.DefaultValue = false;
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "Ch1Note11";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "Ch1Oct11";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "Ch1Tie11";
            this.dataColumn33.DataType = typeof(bool);
            this.dataColumn33.DefaultValue = false;
            // 
            // dataColumn67
            // 
            this.dataColumn67.ColumnName = "Ch2Note11";
            // 
            // dataColumn68
            // 
            this.dataColumn68.ColumnName = "Ch2Oct11";
            // 
            // dataColumn69
            // 
            this.dataColumn69.ColumnName = "Ch2Tie11";
            this.dataColumn69.DataType = typeof(bool);
            this.dataColumn69.DefaultValue = false;
            // 
            // dataColumn103
            // 
            this.dataColumn103.ColumnName = "Ch3Note11";
            // 
            // dataColumn104
            // 
            this.dataColumn104.ColumnName = "Ch3Oct11";
            // 
            // dataColumn105
            // 
            this.dataColumn105.ColumnName = "Ch3Tie11";
            this.dataColumn105.DataType = typeof(bool);
            this.dataColumn105.DefaultValue = false;
            // 
            // dataColumn139
            // 
            this.dataColumn139.ColumnName = "Ch4Note11";
            // 
            // dataColumn140
            // 
            this.dataColumn140.ColumnName = "Ch4Oct11";
            // 
            // dataColumn141
            // 
            this.dataColumn141.ColumnName = "Ch4Tie11";
            this.dataColumn141.DataType = typeof(bool);
            this.dataColumn141.DefaultValue = false;
            // 
            // dataColumn175
            // 
            this.dataColumn175.ColumnName = "Ch5Note11";
            // 
            // dataColumn176
            // 
            this.dataColumn176.ColumnName = "Ch5Oct11";
            // 
            // dataColumn177
            // 
            this.dataColumn177.ColumnName = "Ch5Tie11";
            this.dataColumn177.DataType = typeof(bool);
            this.dataColumn177.DefaultValue = false;
            // 
            // dataColumn211
            // 
            this.dataColumn211.ColumnName = "Ch6Note11";
            // 
            // dataColumn212
            // 
            this.dataColumn212.ColumnName = "Ch6Oct11";
            // 
            // dataColumn213
            // 
            this.dataColumn213.ColumnName = "Ch6Tie11";
            this.dataColumn213.DataType = typeof(bool);
            this.dataColumn213.DefaultValue = false;
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "Ch1Note12";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "Ch1Oct12";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "Ch1Tie12";
            this.dataColumn36.DataType = typeof(bool);
            this.dataColumn36.DefaultValue = false;
            // 
            // dataColumn70
            // 
            this.dataColumn70.ColumnName = "Ch2Note12";
            // 
            // dataColumn71
            // 
            this.dataColumn71.ColumnName = "Ch2Oct12";
            // 
            // dataColumn72
            // 
            this.dataColumn72.ColumnName = "Ch2Tie12";
            this.dataColumn72.DataType = typeof(bool);
            this.dataColumn72.DefaultValue = false;
            // 
            // dataColumn106
            // 
            this.dataColumn106.ColumnName = "Ch3Note12";
            // 
            // dataColumn107
            // 
            this.dataColumn107.ColumnName = "Ch3Oct12";
            // 
            // dataColumn108
            // 
            this.dataColumn108.ColumnName = "Ch3Tie12";
            this.dataColumn108.DataType = typeof(bool);
            this.dataColumn108.DefaultValue = false;
            // 
            // dataColumn142
            // 
            this.dataColumn142.ColumnName = "Ch4Note12";
            // 
            // dataColumn143
            // 
            this.dataColumn143.ColumnName = "Ch4Oct12";
            // 
            // dataColumn144
            // 
            this.dataColumn144.ColumnName = "Ch4Tie12";
            this.dataColumn144.DataType = typeof(bool);
            this.dataColumn144.DefaultValue = false;
            // 
            // dataColumn178
            // 
            this.dataColumn178.ColumnName = "Ch5Note12";
            // 
            // dataColumn179
            // 
            this.dataColumn179.ColumnName = "Ch5Oct12";
            // 
            // dataColumn180
            // 
            this.dataColumn180.ColumnName = "Ch5Tie12";
            this.dataColumn180.DataType = typeof(bool);
            this.dataColumn180.DefaultValue = false;
            // 
            // dataColumn214
            // 
            this.dataColumn214.ColumnName = "Ch6Note12";
            // 
            // dataColumn215
            // 
            this.dataColumn215.ColumnName = "Ch6Oct12";
            // 
            // dataColumn216
            // 
            this.dataColumn216.ColumnName = "Ch6Tie12";
            this.dataColumn216.DataType = typeof(bool);
            this.dataColumn216.DefaultValue = false;
            // 
            // dataColumn217
            // 
            this.dataColumn217.ColumnName = "TickDenom";
            this.dataColumn217.DefaultValue = "1";
            // 
            // Ch1Tie1
            // 
            this.Ch1Tie1.AutoSize = true;
            this.Ch1Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie1", true));
            this.Ch1Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie1.Name = "Ch1Tie1";
            this.Ch1Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie1.TabIndex = 2;
            this.toolTip1.SetToolTip(this.Ch1Tie1, "Tie to next note");
            this.Ch1Tie1.UseVisualStyleBackColor = true;
            // 
            // Ch1Note1
            // 
            this.Ch1Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note1", true));
            this.Ch1Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note1.Name = "Ch1Note1";
            this.Ch1Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.Ch1Note1, "Note");
            // 
            // Ch1Note2
            // 
            this.Ch1Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note2", true));
            this.Ch1Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note2.Name = "Ch1Note2";
            this.Ch1Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note2.TabIndex = 18;
            this.toolTip1.SetToolTip(this.Ch1Note2, "Note");
            // 
            // Ch1Oct2
            // 
            this.Ch1Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct2", true));
            this.Ch1Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct2.Name = "Ch1Oct2";
            this.Ch1Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct2.TabIndex = 19;
            this.toolTip1.SetToolTip(this.Ch1Oct2, "Octave");
            // 
            // Ch1Tie2
            // 
            this.Ch1Tie2.AutoSize = true;
            this.Ch1Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie2", true));
            this.Ch1Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie2.Name = "Ch1Tie2";
            this.Ch1Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie2.TabIndex = 20;
            this.toolTip1.SetToolTip(this.Ch1Tie2, "Tie to next note");
            this.Ch1Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch1Note3
            // 
            this.Ch1Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note3", true));
            this.Ch1Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note3.Name = "Ch1Note3";
            this.Ch1Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note3.TabIndex = 36;
            this.toolTip1.SetToolTip(this.Ch1Note3, "Note");
            // 
            // Ch1Oct3
            // 
            this.Ch1Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct3", true));
            this.Ch1Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct3.Name = "Ch1Oct3";
            this.Ch1Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct3.TabIndex = 37;
            this.toolTip1.SetToolTip(this.Ch1Oct3, "Octave");
            // 
            // Ch1Tie3
            // 
            this.Ch1Tie3.AutoSize = true;
            this.Ch1Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie3", true));
            this.Ch1Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie3.Name = "Ch1Tie3";
            this.Ch1Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie3.TabIndex = 38;
            this.toolTip1.SetToolTip(this.Ch1Tie3, "Tie to next note");
            this.Ch1Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch1Note6
            // 
            this.Ch1Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note6", true));
            this.Ch1Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note6.Name = "Ch1Note6";
            this.Ch1Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note6.TabIndex = 90;
            this.toolTip1.SetToolTip(this.Ch1Note6, "Note");
            // 
            // Ch1Oct6
            // 
            this.Ch1Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct6", true));
            this.Ch1Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct6.Name = "Ch1Oct6";
            this.Ch1Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct6.TabIndex = 91;
            this.toolTip1.SetToolTip(this.Ch1Oct6, "Octave");
            // 
            // Ch1Tie6
            // 
            this.Ch1Tie6.AutoSize = true;
            this.Ch1Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie6", true));
            this.Ch1Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie6.Name = "Ch1Tie6";
            this.Ch1Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie6.TabIndex = 92;
            this.toolTip1.SetToolTip(this.Ch1Tie6, "Tie to next note");
            this.Ch1Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch1Note5
            // 
            this.Ch1Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note5", true));
            this.Ch1Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note5.Name = "Ch1Note5";
            this.Ch1Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note5.TabIndex = 72;
            this.toolTip1.SetToolTip(this.Ch1Note5, "Note");
            // 
            // Ch1Oct5
            // 
            this.Ch1Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct5", true));
            this.Ch1Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct5.Name = "Ch1Oct5";
            this.Ch1Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct5.TabIndex = 73;
            this.toolTip1.SetToolTip(this.Ch1Oct5, "Octave");
            // 
            // Ch1Tie5
            // 
            this.Ch1Tie5.AutoSize = true;
            this.Ch1Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie5", true));
            this.Ch1Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie5.Name = "Ch1Tie5";
            this.Ch1Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie5.TabIndex = 74;
            this.toolTip1.SetToolTip(this.Ch1Tie5, "Tie to next note");
            this.Ch1Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch1Note4
            // 
            this.Ch1Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note4", true));
            this.Ch1Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note4.Name = "Ch1Note4";
            this.Ch1Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note4.TabIndex = 54;
            this.toolTip1.SetToolTip(this.Ch1Note4, "Note");
            // 
            // Ch1Oct4
            // 
            this.Ch1Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct4", true));
            this.Ch1Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct4.Name = "Ch1Oct4";
            this.Ch1Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct4.TabIndex = 55;
            this.toolTip1.SetToolTip(this.Ch1Oct4, "Octave");
            // 
            // Ch1Tie4
            // 
            this.Ch1Tie4.AutoSize = true;
            this.Ch1Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie4", true));
            this.Ch1Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie4.Name = "Ch1Tie4";
            this.Ch1Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie4.TabIndex = 56;
            this.toolTip1.SetToolTip(this.Ch1Tie4, "Tie to next note");
            this.Ch1Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch1Note12
            // 
            this.Ch1Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note12", true));
            this.Ch1Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note12.Name = "Ch1Note12";
            this.Ch1Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note12.TabIndex = 198;
            this.toolTip1.SetToolTip(this.Ch1Note12, "Note");
            // 
            // Ch1Oct12
            // 
            this.Ch1Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct12", true));
            this.Ch1Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct12.Name = "Ch1Oct12";
            this.Ch1Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct12.TabIndex = 199;
            this.toolTip1.SetToolTip(this.Ch1Oct12, "Octave");
            // 
            // Ch1Tie12
            // 
            this.Ch1Tie12.AutoSize = true;
            this.Ch1Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie12", true));
            this.Ch1Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie12.Name = "Ch1Tie12";
            this.Ch1Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie12.TabIndex = 200;
            this.toolTip1.SetToolTip(this.Ch1Tie12, "Tie to next note");
            this.Ch1Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch1Note9
            // 
            this.Ch1Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note9", true));
            this.Ch1Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note9.Name = "Ch1Note9";
            this.Ch1Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note9.TabIndex = 144;
            this.toolTip1.SetToolTip(this.Ch1Note9, "Note");
            // 
            // Ch1Oct9
            // 
            this.Ch1Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct9", true));
            this.Ch1Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct9.Name = "Ch1Oct9";
            this.Ch1Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct9.TabIndex = 145;
            this.toolTip1.SetToolTip(this.Ch1Oct9, "Octave");
            // 
            // Ch1Tie9
            // 
            this.Ch1Tie9.AutoSize = true;
            this.Ch1Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie9", true));
            this.Ch1Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie9.Name = "Ch1Tie9";
            this.Ch1Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie9.TabIndex = 146;
            this.toolTip1.SetToolTip(this.Ch1Tie9, "Tie to next note");
            this.Ch1Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch1Note11
            // 
            this.Ch1Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note11", true));
            this.Ch1Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note11.Name = "Ch1Note11";
            this.Ch1Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note11.TabIndex = 180;
            this.toolTip1.SetToolTip(this.Ch1Note11, "Note");
            // 
            // Ch1Oct11
            // 
            this.Ch1Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct11", true));
            this.Ch1Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct11.Name = "Ch1Oct11";
            this.Ch1Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct11.TabIndex = 181;
            this.toolTip1.SetToolTip(this.Ch1Oct11, "Octave");
            // 
            // Ch1Tie11
            // 
            this.Ch1Tie11.AutoSize = true;
            this.Ch1Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie11", true));
            this.Ch1Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie11.Name = "Ch1Tie11";
            this.Ch1Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie11.TabIndex = 182;
            this.toolTip1.SetToolTip(this.Ch1Tie11, "Tie to next note");
            this.Ch1Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch1Note8
            // 
            this.Ch1Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note8", true));
            this.Ch1Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note8.Name = "Ch1Note8";
            this.Ch1Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note8.TabIndex = 126;
            this.toolTip1.SetToolTip(this.Ch1Note8, "Note");
            // 
            // Ch1Oct8
            // 
            this.Ch1Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct8", true));
            this.Ch1Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct8.Name = "Ch1Oct8";
            this.Ch1Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct8.TabIndex = 127;
            this.toolTip1.SetToolTip(this.Ch1Oct8, "Octave");
            // 
            // Ch1Tie8
            // 
            this.Ch1Tie8.AutoSize = true;
            this.Ch1Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie8", true));
            this.Ch1Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie8.Name = "Ch1Tie8";
            this.Ch1Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie8.TabIndex = 128;
            this.toolTip1.SetToolTip(this.Ch1Tie8, "Tie to next note");
            this.Ch1Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch1Note10
            // 
            this.Ch1Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note10", true));
            this.Ch1Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note10.Name = "Ch1Note10";
            this.Ch1Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note10.TabIndex = 162;
            this.toolTip1.SetToolTip(this.Ch1Note10, "Note");
            // 
            // Ch1Oct10
            // 
            this.Ch1Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct10", true));
            this.Ch1Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct10.Name = "Ch1Oct10";
            this.Ch1Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct10.TabIndex = 163;
            this.toolTip1.SetToolTip(this.Ch1Oct10, "Octave");
            // 
            // Ch1Tie10
            // 
            this.Ch1Tie10.AutoSize = true;
            this.Ch1Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie10", true));
            this.Ch1Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie10.Name = "Ch1Tie10";
            this.Ch1Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie10.TabIndex = 164;
            this.toolTip1.SetToolTip(this.Ch1Tie10, "Tie to next note");
            this.Ch1Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch1Note7
            // 
            this.Ch1Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Note7", true));
            this.Ch1Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch1Note7.Name = "Ch1Note7";
            this.Ch1Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch1Note7.TabIndex = 108;
            this.toolTip1.SetToolTip(this.Ch1Note7, "Note");
            // 
            // Ch1Oct7
            // 
            this.Ch1Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch1Oct7", true));
            this.Ch1Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch1Oct7.Name = "Ch1Oct7";
            this.Ch1Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch1Oct7.TabIndex = 109;
            this.toolTip1.SetToolTip(this.Ch1Oct7, "Octave");
            // 
            // Ch1Tie7
            // 
            this.Ch1Tie7.AutoSize = true;
            this.Ch1Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch1Tie7", true));
            this.Ch1Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch1Tie7.Name = "Ch1Tie7";
            this.Ch1Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch1Tie7.TabIndex = 110;
            this.toolTip1.SetToolTip(this.Ch1Tie7, "Tie to next note");
            this.Ch1Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch2Note12
            // 
            this.Ch2Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note12", true));
            this.Ch2Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note12.Name = "Ch2Note12";
            this.Ch2Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note12.TabIndex = 201;
            this.toolTip1.SetToolTip(this.Ch2Note12, "Note");
            // 
            // Ch2Oct12
            // 
            this.Ch2Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct12", true));
            this.Ch2Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct12.Name = "Ch2Oct12";
            this.Ch2Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct12.TabIndex = 202;
            this.toolTip1.SetToolTip(this.Ch2Oct12, "Octave");
            // 
            // Ch2Tie12
            // 
            this.Ch2Tie12.AutoSize = true;
            this.Ch2Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie12", true));
            this.Ch2Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie12.Name = "Ch2Tie12";
            this.Ch2Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie12.TabIndex = 203;
            this.toolTip1.SetToolTip(this.Ch2Tie12, "Tie to next note");
            this.Ch2Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch2Note6
            // 
            this.Ch2Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note6", true));
            this.Ch2Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note6.Name = "Ch2Note6";
            this.Ch2Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note6.TabIndex = 93;
            this.toolTip1.SetToolTip(this.Ch2Note6, "Note");
            // 
            // Ch2Oct6
            // 
            this.Ch2Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct6", true));
            this.Ch2Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct6.Name = "Ch2Oct6";
            this.Ch2Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct6.TabIndex = 94;
            this.toolTip1.SetToolTip(this.Ch2Oct6, "Octave");
            // 
            // Ch2Tie6
            // 
            this.Ch2Tie6.AutoSize = true;
            this.Ch2Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie6", true));
            this.Ch2Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie6.Name = "Ch2Tie6";
            this.Ch2Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie6.TabIndex = 95;
            this.toolTip1.SetToolTip(this.Ch2Tie6, "Tie to next note");
            this.Ch2Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch2Note9
            // 
            this.Ch2Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note9", true));
            this.Ch2Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note9.Name = "Ch2Note9";
            this.Ch2Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note9.TabIndex = 147;
            this.toolTip1.SetToolTip(this.Ch2Note9, "Note");
            // 
            // Ch2Oct9
            // 
            this.Ch2Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct9", true));
            this.Ch2Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct9.Name = "Ch2Oct9";
            this.Ch2Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct9.TabIndex = 148;
            this.toolTip1.SetToolTip(this.Ch2Oct9, "Octave");
            // 
            // Ch2Tie9
            // 
            this.Ch2Tie9.AutoSize = true;
            this.Ch2Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie9", true));
            this.Ch2Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie9.Name = "Ch2Tie9";
            this.Ch2Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie9.TabIndex = 149;
            this.toolTip1.SetToolTip(this.Ch2Tie9, "Tie to next note");
            this.Ch2Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch2Note3
            // 
            this.Ch2Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note3", true));
            this.Ch2Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note3.Name = "Ch2Note3";
            this.Ch2Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note3.TabIndex = 39;
            this.toolTip1.SetToolTip(this.Ch2Note3, "Note");
            // 
            // Ch2Oct3
            // 
            this.Ch2Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct3", true));
            this.Ch2Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct3.Name = "Ch2Oct3";
            this.Ch2Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct3.TabIndex = 40;
            this.toolTip1.SetToolTip(this.Ch2Oct3, "Octave");
            // 
            // Ch2Tie3
            // 
            this.Ch2Tie3.AutoSize = true;
            this.Ch2Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie3", true));
            this.Ch2Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie3.Name = "Ch2Tie3";
            this.Ch2Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie3.TabIndex = 41;
            this.toolTip1.SetToolTip(this.Ch2Tie3, "Tie to next note");
            this.Ch2Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch2Note11
            // 
            this.Ch2Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note11", true));
            this.Ch2Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note11.Name = "Ch2Note11";
            this.Ch2Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note11.TabIndex = 183;
            this.toolTip1.SetToolTip(this.Ch2Note11, "Note");
            // 
            // Ch2Oct11
            // 
            this.Ch2Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct11", true));
            this.Ch2Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct11.Name = "Ch2Oct11";
            this.Ch2Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct11.TabIndex = 184;
            this.toolTip1.SetToolTip(this.Ch2Oct11, "Octave");
            // 
            // Ch2Tie11
            // 
            this.Ch2Tie11.AutoSize = true;
            this.Ch2Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie11", true));
            this.Ch2Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie11.Name = "Ch2Tie11";
            this.Ch2Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie11.TabIndex = 185;
            this.toolTip1.SetToolTip(this.Ch2Tie11, "Tie to next note");
            this.Ch2Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch2Note5
            // 
            this.Ch2Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note5", true));
            this.Ch2Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note5.Name = "Ch2Note5";
            this.Ch2Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note5.TabIndex = 75;
            this.toolTip1.SetToolTip(this.Ch2Note5, "Note");
            // 
            // Ch2Oct5
            // 
            this.Ch2Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct5", true));
            this.Ch2Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct5.Name = "Ch2Oct5";
            this.Ch2Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct5.TabIndex = 76;
            this.toolTip1.SetToolTip(this.Ch2Oct5, "Octave");
            // 
            // Ch2Tie5
            // 
            this.Ch2Tie5.AutoSize = true;
            this.Ch2Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie5", true));
            this.Ch2Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie5.Name = "Ch2Tie5";
            this.Ch2Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie5.TabIndex = 77;
            this.toolTip1.SetToolTip(this.Ch2Tie5, "Tie to next note");
            this.Ch2Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch2Note8
            // 
            this.Ch2Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note8", true));
            this.Ch2Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note8.Name = "Ch2Note8";
            this.Ch2Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note8.TabIndex = 129;
            this.toolTip1.SetToolTip(this.Ch2Note8, "Note");
            // 
            // Ch2Oct8
            // 
            this.Ch2Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct8", true));
            this.Ch2Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct8.Name = "Ch2Oct8";
            this.Ch2Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct8.TabIndex = 130;
            this.toolTip1.SetToolTip(this.Ch2Oct8, "Octave");
            // 
            // Ch2Tie8
            // 
            this.Ch2Tie8.AutoSize = true;
            this.Ch2Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie8", true));
            this.Ch2Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie8.Name = "Ch2Tie8";
            this.Ch2Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie8.TabIndex = 131;
            this.toolTip1.SetToolTip(this.Ch2Tie8, "Tie to next note");
            this.Ch2Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch2Note2
            // 
            this.Ch2Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note2", true));
            this.Ch2Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note2.Name = "Ch2Note2";
            this.Ch2Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note2.TabIndex = 21;
            this.toolTip1.SetToolTip(this.Ch2Note2, "Note");
            // 
            // Ch2Oct2
            // 
            this.Ch2Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct2", true));
            this.Ch2Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct2.Name = "Ch2Oct2";
            this.Ch2Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct2.TabIndex = 22;
            this.toolTip1.SetToolTip(this.Ch2Oct2, "Octave");
            // 
            // Ch2Tie2
            // 
            this.Ch2Tie2.AutoSize = true;
            this.Ch2Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie2", true));
            this.Ch2Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie2.Name = "Ch2Tie2";
            this.Ch2Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie2.TabIndex = 23;
            this.toolTip1.SetToolTip(this.Ch2Tie2, "Tie to next note");
            this.Ch2Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch2Note10
            // 
            this.Ch2Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note10", true));
            this.Ch2Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note10.Name = "Ch2Note10";
            this.Ch2Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note10.TabIndex = 165;
            this.toolTip1.SetToolTip(this.Ch2Note10, "Note");
            // 
            // Ch2Oct10
            // 
            this.Ch2Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct10", true));
            this.Ch2Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct10.Name = "Ch2Oct10";
            this.Ch2Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct10.TabIndex = 166;
            this.toolTip1.SetToolTip(this.Ch2Oct10, "Octave");
            // 
            // Ch2Tie10
            // 
            this.Ch2Tie10.AutoSize = true;
            this.Ch2Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie10", true));
            this.Ch2Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie10.Name = "Ch2Tie10";
            this.Ch2Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie10.TabIndex = 167;
            this.toolTip1.SetToolTip(this.Ch2Tie10, "Tie to next note");
            this.Ch2Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch2Note4
            // 
            this.Ch2Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note4", true));
            this.Ch2Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note4.Name = "Ch2Note4";
            this.Ch2Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note4.TabIndex = 57;
            this.toolTip1.SetToolTip(this.Ch2Note4, "Note");
            // 
            // Ch2Oct4
            // 
            this.Ch2Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct4", true));
            this.Ch2Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct4.Name = "Ch2Oct4";
            this.Ch2Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct4.TabIndex = 58;
            this.toolTip1.SetToolTip(this.Ch2Oct4, "Octave");
            // 
            // Ch2Tie4
            // 
            this.Ch2Tie4.AutoSize = true;
            this.Ch2Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie4", true));
            this.Ch2Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie4.Name = "Ch2Tie4";
            this.Ch2Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie4.TabIndex = 59;
            this.toolTip1.SetToolTip(this.Ch2Tie4, "Tie to next note");
            this.Ch2Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch2Note7
            // 
            this.Ch2Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note7", true));
            this.Ch2Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note7.Name = "Ch2Note7";
            this.Ch2Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note7.TabIndex = 111;
            this.toolTip1.SetToolTip(this.Ch2Note7, "Note");
            // 
            // Ch2Oct7
            // 
            this.Ch2Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct7", true));
            this.Ch2Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct7.Name = "Ch2Oct7";
            this.Ch2Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct7.TabIndex = 112;
            this.toolTip1.SetToolTip(this.Ch2Oct7, "Octave");
            // 
            // Ch2Tie7
            // 
            this.Ch2Tie7.AutoSize = true;
            this.Ch2Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie7", true));
            this.Ch2Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie7.Name = "Ch2Tie7";
            this.Ch2Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie7.TabIndex = 113;
            this.toolTip1.SetToolTip(this.Ch2Tie7, "Tie to next note");
            this.Ch2Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch2Note1
            // 
            this.Ch2Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Note1", true));
            this.Ch2Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch2Note1.Name = "Ch2Note1";
            this.Ch2Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch2Note1.TabIndex = 3;
            this.toolTip1.SetToolTip(this.Ch2Note1, "Note");
            // 
            // Ch2Oct1
            // 
            this.Ch2Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch2Oct1", true));
            this.Ch2Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch2Oct1.Name = "Ch2Oct1";
            this.Ch2Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch2Oct1.TabIndex = 4;
            this.toolTip1.SetToolTip(this.Ch2Oct1, "Octave");
            // 
            // Ch2Tie1
            // 
            this.Ch2Tie1.AutoSize = true;
            this.Ch2Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch2Tie1", true));
            this.Ch2Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch2Tie1.Name = "Ch2Tie1";
            this.Ch2Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch2Tie1.TabIndex = 5;
            this.toolTip1.SetToolTip(this.Ch2Tie1, "Tie to next note");
            this.Ch2Tie1.UseVisualStyleBackColor = true;
            // 
            // Ch3Note12
            // 
            this.Ch3Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note12", true));
            this.Ch3Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note12.Name = "Ch3Note12";
            this.Ch3Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note12.TabIndex = 204;
            this.toolTip1.SetToolTip(this.Ch3Note12, "Note");
            // 
            // Ch3Oct12
            // 
            this.Ch3Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct12", true));
            this.Ch3Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct12.Name = "Ch3Oct12";
            this.Ch3Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct12.TabIndex = 205;
            this.toolTip1.SetToolTip(this.Ch3Oct12, "Octave");
            // 
            // Ch3Tie12
            // 
            this.Ch3Tie12.AutoSize = true;
            this.Ch3Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie12", true));
            this.Ch3Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie12.Name = "Ch3Tie12";
            this.Ch3Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie12.TabIndex = 206;
            this.toolTip1.SetToolTip(this.Ch3Tie12, "Tie to next note");
            this.Ch3Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch3Note6
            // 
            this.Ch3Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note6", true));
            this.Ch3Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note6.Name = "Ch3Note6";
            this.Ch3Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note6.TabIndex = 96;
            this.toolTip1.SetToolTip(this.Ch3Note6, "Note");
            // 
            // Ch3Oct6
            // 
            this.Ch3Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct6", true));
            this.Ch3Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct6.Name = "Ch3Oct6";
            this.Ch3Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct6.TabIndex = 97;
            this.toolTip1.SetToolTip(this.Ch3Oct6, "Octave");
            // 
            // Ch3Tie6
            // 
            this.Ch3Tie6.AutoSize = true;
            this.Ch3Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie6", true));
            this.Ch3Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie6.Name = "Ch3Tie6";
            this.Ch3Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie6.TabIndex = 98;
            this.toolTip1.SetToolTip(this.Ch3Tie6, "Tie to next note");
            this.Ch3Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch3Note9
            // 
            this.Ch3Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note9", true));
            this.Ch3Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note9.Name = "Ch3Note9";
            this.Ch3Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note9.TabIndex = 150;
            this.toolTip1.SetToolTip(this.Ch3Note9, "Note");
            // 
            // Ch3Oct9
            // 
            this.Ch3Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct9", true));
            this.Ch3Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct9.Name = "Ch3Oct9";
            this.Ch3Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct9.TabIndex = 151;
            this.toolTip1.SetToolTip(this.Ch3Oct9, "Octave");
            // 
            // Ch3Tie9
            // 
            this.Ch3Tie9.AutoSize = true;
            this.Ch3Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie9", true));
            this.Ch3Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie9.Name = "Ch3Tie9";
            this.Ch3Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie9.TabIndex = 152;
            this.toolTip1.SetToolTip(this.Ch3Tie9, "Tie to next note");
            this.Ch3Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch3Note3
            // 
            this.Ch3Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note3", true));
            this.Ch3Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note3.Name = "Ch3Note3";
            this.Ch3Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note3.TabIndex = 42;
            this.toolTip1.SetToolTip(this.Ch3Note3, "Note");
            // 
            // Ch3Oct3
            // 
            this.Ch3Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct3", true));
            this.Ch3Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct3.Name = "Ch3Oct3";
            this.Ch3Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct3.TabIndex = 43;
            this.toolTip1.SetToolTip(this.Ch3Oct3, "Octave");
            // 
            // Ch3Tie3
            // 
            this.Ch3Tie3.AutoSize = true;
            this.Ch3Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie3", true));
            this.Ch3Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie3.Name = "Ch3Tie3";
            this.Ch3Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie3.TabIndex = 44;
            this.toolTip1.SetToolTip(this.Ch3Tie3, "Tie to next note");
            this.Ch3Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch3Note11
            // 
            this.Ch3Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note11", true));
            this.Ch3Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note11.Name = "Ch3Note11";
            this.Ch3Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note11.TabIndex = 186;
            this.toolTip1.SetToolTip(this.Ch3Note11, "Note");
            // 
            // Ch3Oct11
            // 
            this.Ch3Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct11", true));
            this.Ch3Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct11.Name = "Ch3Oct11";
            this.Ch3Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct11.TabIndex = 187;
            this.toolTip1.SetToolTip(this.Ch3Oct11, "Octave");
            // 
            // Ch3Tie11
            // 
            this.Ch3Tie11.AutoSize = true;
            this.Ch3Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie11", true));
            this.Ch3Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie11.Name = "Ch3Tie11";
            this.Ch3Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie11.TabIndex = 188;
            this.toolTip1.SetToolTip(this.Ch3Tie11, "Tie to next note");
            this.Ch3Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch3Note5
            // 
            this.Ch3Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note5", true));
            this.Ch3Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note5.Name = "Ch3Note5";
            this.Ch3Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note5.TabIndex = 78;
            this.toolTip1.SetToolTip(this.Ch3Note5, "Note");
            // 
            // Ch3Oct5
            // 
            this.Ch3Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct5", true));
            this.Ch3Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct5.Name = "Ch3Oct5";
            this.Ch3Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct5.TabIndex = 79;
            this.toolTip1.SetToolTip(this.Ch3Oct5, "Octave");
            // 
            // Ch3Tie5
            // 
            this.Ch3Tie5.AutoSize = true;
            this.Ch3Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie5", true));
            this.Ch3Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie5.Name = "Ch3Tie5";
            this.Ch3Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie5.TabIndex = 80;
            this.toolTip1.SetToolTip(this.Ch3Tie5, "Tie to next note");
            this.Ch3Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch3Note8
            // 
            this.Ch3Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note8", true));
            this.Ch3Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note8.Name = "Ch3Note8";
            this.Ch3Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note8.TabIndex = 132;
            this.toolTip1.SetToolTip(this.Ch3Note8, "Note");
            // 
            // Ch3Oct8
            // 
            this.Ch3Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct8", true));
            this.Ch3Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct8.Name = "Ch3Oct8";
            this.Ch3Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct8.TabIndex = 133;
            this.toolTip1.SetToolTip(this.Ch3Oct8, "Octave");
            // 
            // Ch3Tie8
            // 
            this.Ch3Tie8.AutoSize = true;
            this.Ch3Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie8", true));
            this.Ch3Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie8.Name = "Ch3Tie8";
            this.Ch3Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie8.TabIndex = 134;
            this.toolTip1.SetToolTip(this.Ch3Tie8, "Tie to next note");
            this.Ch3Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch3Note2
            // 
            this.Ch3Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note2", true));
            this.Ch3Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note2.Name = "Ch3Note2";
            this.Ch3Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note2.TabIndex = 24;
            this.toolTip1.SetToolTip(this.Ch3Note2, "Note");
            // 
            // Ch3Oct2
            // 
            this.Ch3Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct2", true));
            this.Ch3Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct2.Name = "Ch3Oct2";
            this.Ch3Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct2.TabIndex = 25;
            this.toolTip1.SetToolTip(this.Ch3Oct2, "Octave");
            // 
            // Ch3Tie2
            // 
            this.Ch3Tie2.AutoSize = true;
            this.Ch3Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie2", true));
            this.Ch3Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie2.Name = "Ch3Tie2";
            this.Ch3Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie2.TabIndex = 26;
            this.toolTip1.SetToolTip(this.Ch3Tie2, "Tie to next note");
            this.Ch3Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch3Note10
            // 
            this.Ch3Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note10", true));
            this.Ch3Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note10.Name = "Ch3Note10";
            this.Ch3Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note10.TabIndex = 168;
            this.toolTip1.SetToolTip(this.Ch3Note10, "Note");
            // 
            // Ch3Oct10
            // 
            this.Ch3Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct10", true));
            this.Ch3Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct10.Name = "Ch3Oct10";
            this.Ch3Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct10.TabIndex = 169;
            this.toolTip1.SetToolTip(this.Ch3Oct10, "Octave");
            // 
            // Ch3Tie10
            // 
            this.Ch3Tie10.AutoSize = true;
            this.Ch3Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie10", true));
            this.Ch3Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie10.Name = "Ch3Tie10";
            this.Ch3Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie10.TabIndex = 170;
            this.toolTip1.SetToolTip(this.Ch3Tie10, "Tie to next note");
            this.Ch3Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch3Note4
            // 
            this.Ch3Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note4", true));
            this.Ch3Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note4.Name = "Ch3Note4";
            this.Ch3Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note4.TabIndex = 60;
            this.toolTip1.SetToolTip(this.Ch3Note4, "Note");
            // 
            // Ch3Oct4
            // 
            this.Ch3Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct4", true));
            this.Ch3Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct4.Name = "Ch3Oct4";
            this.Ch3Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct4.TabIndex = 61;
            this.toolTip1.SetToolTip(this.Ch3Oct4, "Octave");
            // 
            // Ch3Tie4
            // 
            this.Ch3Tie4.AutoSize = true;
            this.Ch3Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie4", true));
            this.Ch3Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie4.Name = "Ch3Tie4";
            this.Ch3Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie4.TabIndex = 62;
            this.toolTip1.SetToolTip(this.Ch3Tie4, "Tie to next note");
            this.Ch3Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch3Note7
            // 
            this.Ch3Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note7", true));
            this.Ch3Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note7.Name = "Ch3Note7";
            this.Ch3Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note7.TabIndex = 114;
            this.toolTip1.SetToolTip(this.Ch3Note7, "Note");
            // 
            // Ch3Oct7
            // 
            this.Ch3Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct7", true));
            this.Ch3Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct7.Name = "Ch3Oct7";
            this.Ch3Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct7.TabIndex = 115;
            this.toolTip1.SetToolTip(this.Ch3Oct7, "Octave");
            // 
            // Ch3Tie7
            // 
            this.Ch3Tie7.AutoSize = true;
            this.Ch3Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie7", true));
            this.Ch3Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie7.Name = "Ch3Tie7";
            this.Ch3Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie7.TabIndex = 116;
            this.toolTip1.SetToolTip(this.Ch3Tie7, "Tie to next note");
            this.Ch3Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch3Note1
            // 
            this.Ch3Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Note1", true));
            this.Ch3Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch3Note1.Name = "Ch3Note1";
            this.Ch3Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch3Note1.TabIndex = 6;
            this.toolTip1.SetToolTip(this.Ch3Note1, "Note");
            // 
            // Ch3Oct1
            // 
            this.Ch3Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch3Oct1", true));
            this.Ch3Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch3Oct1.Name = "Ch3Oct1";
            this.Ch3Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch3Oct1.TabIndex = 7;
            this.toolTip1.SetToolTip(this.Ch3Oct1, "Octave");
            // 
            // Ch3Tie1
            // 
            this.Ch3Tie1.AutoSize = true;
            this.Ch3Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch3Tie1", true));
            this.Ch3Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch3Tie1.Name = "Ch3Tie1";
            this.Ch3Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch3Tie1.TabIndex = 8;
            this.toolTip1.SetToolTip(this.Ch3Tie1, "Tie to next note");
            this.Ch3Tie1.UseVisualStyleBackColor = true;
            // 
            // Ch6Note12
            // 
            this.Ch6Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note12", true));
            this.Ch6Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note12.Name = "Ch6Note12";
            this.Ch6Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note12.TabIndex = 213;
            this.toolTip1.SetToolTip(this.Ch6Note12, "Note");
            // 
            // Ch6Oct12
            // 
            this.Ch6Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct12", true));
            this.Ch6Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct12.Name = "Ch6Oct12";
            this.Ch6Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct12.TabIndex = 214;
            this.toolTip1.SetToolTip(this.Ch6Oct12, "Octave");
            // 
            // Ch6Tie12
            // 
            this.Ch6Tie12.AutoSize = true;
            this.Ch6Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie12", true));
            this.Ch6Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie12.Name = "Ch6Tie12";
            this.Ch6Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie12.TabIndex = 215;
            this.toolTip1.SetToolTip(this.Ch6Tie12, "Tie to next note");
            this.Ch6Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch5Note12
            // 
            this.Ch5Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note12", true));
            this.Ch5Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note12.Name = "Ch5Note12";
            this.Ch5Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note12.TabIndex = 210;
            this.toolTip1.SetToolTip(this.Ch5Note12, "Note");
            // 
            // Ch5Oct12
            // 
            this.Ch5Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct12", true));
            this.Ch5Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct12.Name = "Ch5Oct12";
            this.Ch5Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct12.TabIndex = 211;
            this.toolTip1.SetToolTip(this.Ch5Oct12, "Octave");
            // 
            // Ch5Tie12
            // 
            this.Ch5Tie12.AutoSize = true;
            this.Ch5Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie12", true));
            this.Ch5Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie12.Name = "Ch5Tie12";
            this.Ch5Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie12.TabIndex = 212;
            this.toolTip1.SetToolTip(this.Ch5Tie12, "Tie to next note");
            this.Ch5Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch6Note6
            // 
            this.Ch6Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note6", true));
            this.Ch6Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note6.Name = "Ch6Note6";
            this.Ch6Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note6.TabIndex = 105;
            this.toolTip1.SetToolTip(this.Ch6Note6, "Note");
            // 
            // Ch6Oct6
            // 
            this.Ch6Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct6", true));
            this.Ch6Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct6.Name = "Ch6Oct6";
            this.Ch6Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct6.TabIndex = 106;
            this.toolTip1.SetToolTip(this.Ch6Oct6, "Octave");
            // 
            // Ch6Tie6
            // 
            this.Ch6Tie6.AutoSize = true;
            this.Ch6Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie6", true));
            this.Ch6Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie6.Name = "Ch6Tie6";
            this.Ch6Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie6.TabIndex = 107;
            this.toolTip1.SetToolTip(this.Ch6Tie6, "Tie to next note");
            this.Ch6Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch4Note12
            // 
            this.Ch4Note12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note12", true));
            this.Ch4Note12.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note12.Name = "Ch4Note12";
            this.Ch4Note12.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note12.TabIndex = 207;
            this.toolTip1.SetToolTip(this.Ch4Note12, "Note");
            // 
            // Ch4Oct12
            // 
            this.Ch4Oct12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct12", true));
            this.Ch4Oct12.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct12.Name = "Ch4Oct12";
            this.Ch4Oct12.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct12.TabIndex = 208;
            this.toolTip1.SetToolTip(this.Ch4Oct12, "Octave");
            // 
            // Ch4Tie12
            // 
            this.Ch4Tie12.AutoSize = true;
            this.Ch4Tie12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie12", true));
            this.Ch4Tie12.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie12.Name = "Ch4Tie12";
            this.Ch4Tie12.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie12.TabIndex = 209;
            this.toolTip1.SetToolTip(this.Ch4Tie12, "Tie to next note");
            this.Ch4Tie12.UseVisualStyleBackColor = true;
            // 
            // Ch6Note9
            // 
            this.Ch6Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note9", true));
            this.Ch6Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note9.Name = "Ch6Note9";
            this.Ch6Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note9.TabIndex = 159;
            this.toolTip1.SetToolTip(this.Ch6Note9, "Note");
            // 
            // Ch6Oct9
            // 
            this.Ch6Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct9", true));
            this.Ch6Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct9.Name = "Ch6Oct9";
            this.Ch6Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct9.TabIndex = 160;
            this.toolTip1.SetToolTip(this.Ch6Oct9, "Octave");
            // 
            // Ch6Tie9
            // 
            this.Ch6Tie9.AutoSize = true;
            this.Ch6Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie9", true));
            this.Ch6Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie9.Name = "Ch6Tie9";
            this.Ch6Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie9.TabIndex = 161;
            this.toolTip1.SetToolTip(this.Ch6Tie9, "Tie to next note");
            this.Ch6Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch5Note6
            // 
            this.Ch5Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note6", true));
            this.Ch5Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note6.Name = "Ch5Note6";
            this.Ch5Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note6.TabIndex = 102;
            this.toolTip1.SetToolTip(this.Ch5Note6, "Note");
            // 
            // Ch5Oct6
            // 
            this.Ch5Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct6", true));
            this.Ch5Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct6.Name = "Ch5Oct6";
            this.Ch5Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct6.TabIndex = 103;
            this.toolTip1.SetToolTip(this.Ch5Oct6, "Octave");
            // 
            // Ch5Tie6
            // 
            this.Ch5Tie6.AutoSize = true;
            this.Ch5Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie6", true));
            this.Ch5Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie6.Name = "Ch5Tie6";
            this.Ch5Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie6.TabIndex = 104;
            this.toolTip1.SetToolTip(this.Ch5Tie6, "Tie to next note");
            this.Ch5Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch6Note3
            // 
            this.Ch6Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note3", true));
            this.Ch6Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note3.Name = "Ch6Note3";
            this.Ch6Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note3.TabIndex = 51;
            this.toolTip1.SetToolTip(this.Ch6Note3, "Note");
            // 
            // Ch6Oct3
            // 
            this.Ch6Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct3", true));
            this.Ch6Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct3.Name = "Ch6Oct3";
            this.Ch6Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct3.TabIndex = 52;
            this.toolTip1.SetToolTip(this.Ch6Oct3, "Octave");
            // 
            // Ch6Tie3
            // 
            this.Ch6Tie3.AutoSize = true;
            this.Ch6Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie3", true));
            this.Ch6Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie3.Name = "Ch6Tie3";
            this.Ch6Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie3.TabIndex = 53;
            this.toolTip1.SetToolTip(this.Ch6Tie3, "Tie to next note");
            this.Ch6Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch4Note6
            // 
            this.Ch4Note6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note6", true));
            this.Ch4Note6.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note6.Name = "Ch4Note6";
            this.Ch4Note6.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note6.TabIndex = 99;
            this.toolTip1.SetToolTip(this.Ch4Note6, "Note");
            // 
            // Ch4Oct6
            // 
            this.Ch4Oct6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct6", true));
            this.Ch4Oct6.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct6.Name = "Ch4Oct6";
            this.Ch4Oct6.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct6.TabIndex = 100;
            this.toolTip1.SetToolTip(this.Ch4Oct6, "Octave");
            // 
            // Ch4Tie6
            // 
            this.Ch4Tie6.AutoSize = true;
            this.Ch4Tie6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie6", true));
            this.Ch4Tie6.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie6.Name = "Ch4Tie6";
            this.Ch4Tie6.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie6.TabIndex = 101;
            this.toolTip1.SetToolTip(this.Ch4Tie6, "Tie to next note");
            this.Ch4Tie6.UseVisualStyleBackColor = true;
            // 
            // Ch6Note11
            // 
            this.Ch6Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note11", true));
            this.Ch6Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note11.Name = "Ch6Note11";
            this.Ch6Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note11.TabIndex = 195;
            this.toolTip1.SetToolTip(this.Ch6Note11, "Note");
            // 
            // Ch6Oct11
            // 
            this.Ch6Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct11", true));
            this.Ch6Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct11.Name = "Ch6Oct11";
            this.Ch6Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct11.TabIndex = 196;
            this.toolTip1.SetToolTip(this.Ch6Oct11, "Octave");
            // 
            // Ch6Tie11
            // 
            this.Ch6Tie11.AutoSize = true;
            this.Ch6Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie11", true));
            this.Ch6Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie11.Name = "Ch6Tie11";
            this.Ch6Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie11.TabIndex = 197;
            this.toolTip1.SetToolTip(this.Ch6Tie11, "Tie to next note");
            this.Ch6Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch5Note9
            // 
            this.Ch5Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note9", true));
            this.Ch5Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note9.Name = "Ch5Note9";
            this.Ch5Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note9.TabIndex = 156;
            this.toolTip1.SetToolTip(this.Ch5Note9, "Note");
            // 
            // Ch5Oct9
            // 
            this.Ch5Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct9", true));
            this.Ch5Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct9.Name = "Ch5Oct9";
            this.Ch5Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct9.TabIndex = 157;
            this.toolTip1.SetToolTip(this.Ch5Oct9, "Octave");
            // 
            // Ch5Tie9
            // 
            this.Ch5Tie9.AutoSize = true;
            this.Ch5Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie9", true));
            this.Ch5Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie9.Name = "Ch5Tie9";
            this.Ch5Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie9.TabIndex = 158;
            this.toolTip1.SetToolTip(this.Ch5Tie9, "Tie to next note");
            this.Ch5Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch6Note5
            // 
            this.Ch6Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note5", true));
            this.Ch6Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note5.Name = "Ch6Note5";
            this.Ch6Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note5.TabIndex = 87;
            this.toolTip1.SetToolTip(this.Ch6Note5, "Note");
            // 
            // Ch6Oct5
            // 
            this.Ch6Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct5", true));
            this.Ch6Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct5.Name = "Ch6Oct5";
            this.Ch6Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct5.TabIndex = 88;
            this.toolTip1.SetToolTip(this.Ch6Oct5, "Octave");
            // 
            // Ch6Tie5
            // 
            this.Ch6Tie5.AutoSize = true;
            this.Ch6Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie5", true));
            this.Ch6Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie5.Name = "Ch6Tie5";
            this.Ch6Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie5.TabIndex = 89;
            this.toolTip1.SetToolTip(this.Ch6Tie5, "Tie to next note");
            this.Ch6Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch4Note9
            // 
            this.Ch4Note9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note9", true));
            this.Ch4Note9.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note9.Name = "Ch4Note9";
            this.Ch4Note9.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note9.TabIndex = 153;
            this.toolTip1.SetToolTip(this.Ch4Note9, "Note");
            // 
            // Ch4Oct9
            // 
            this.Ch4Oct9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct9", true));
            this.Ch4Oct9.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct9.Name = "Ch4Oct9";
            this.Ch4Oct9.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct9.TabIndex = 154;
            this.toolTip1.SetToolTip(this.Ch4Oct9, "Octave");
            // 
            // Ch4Tie9
            // 
            this.Ch4Tie9.AutoSize = true;
            this.Ch4Tie9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie9", true));
            this.Ch4Tie9.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie9.Name = "Ch4Tie9";
            this.Ch4Tie9.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie9.TabIndex = 155;
            this.toolTip1.SetToolTip(this.Ch4Tie9, "Tie to next note");
            this.Ch4Tie9.UseVisualStyleBackColor = true;
            // 
            // Ch6Note8
            // 
            this.Ch6Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note8", true));
            this.Ch6Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note8.Name = "Ch6Note8";
            this.Ch6Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note8.TabIndex = 141;
            this.toolTip1.SetToolTip(this.Ch6Note8, "Note");
            // 
            // Ch6Oct8
            // 
            this.Ch6Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct8", true));
            this.Ch6Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct8.Name = "Ch6Oct8";
            this.Ch6Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct8.TabIndex = 142;
            this.toolTip1.SetToolTip(this.Ch6Oct8, "Octave");
            // 
            // Ch6Tie8
            // 
            this.Ch6Tie8.AutoSize = true;
            this.Ch6Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie8", true));
            this.Ch6Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie8.Name = "Ch6Tie8";
            this.Ch6Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie8.TabIndex = 143;
            this.toolTip1.SetToolTip(this.Ch6Tie8, "Tie to next note");
            this.Ch6Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch5Note3
            // 
            this.Ch5Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note3", true));
            this.Ch5Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note3.Name = "Ch5Note3";
            this.Ch5Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note3.TabIndex = 48;
            this.toolTip1.SetToolTip(this.Ch5Note3, "Note");
            // 
            // Ch5Oct3
            // 
            this.Ch5Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct3", true));
            this.Ch5Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct3.Name = "Ch5Oct3";
            this.Ch5Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct3.TabIndex = 49;
            this.toolTip1.SetToolTip(this.Ch5Oct3, "Octave");
            // 
            // Ch5Tie3
            // 
            this.Ch5Tie3.AutoSize = true;
            this.Ch5Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie3", true));
            this.Ch5Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie3.Name = "Ch5Tie3";
            this.Ch5Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie3.TabIndex = 50;
            this.toolTip1.SetToolTip(this.Ch5Tie3, "Tie to next note");
            this.Ch5Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch6Note2
            // 
            this.Ch6Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note2", true));
            this.Ch6Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note2.Name = "Ch6Note2";
            this.Ch6Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note2.TabIndex = 33;
            this.toolTip1.SetToolTip(this.Ch6Note2, "Note");
            // 
            // Ch6Oct2
            // 
            this.Ch6Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct2", true));
            this.Ch6Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct2.Name = "Ch6Oct2";
            this.Ch6Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct2.TabIndex = 34;
            this.toolTip1.SetToolTip(this.Ch6Oct2, "Octave");
            // 
            // Ch6Tie2
            // 
            this.Ch6Tie2.AutoSize = true;
            this.Ch6Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie2", true));
            this.Ch6Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie2.Name = "Ch6Tie2";
            this.Ch6Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie2.TabIndex = 35;
            this.toolTip1.SetToolTip(this.Ch6Tie2, "Tie to next note");
            this.Ch6Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch4Note3
            // 
            this.Ch4Note3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note3", true));
            this.Ch4Note3.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note3.Name = "Ch4Note3";
            this.Ch4Note3.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note3.TabIndex = 45;
            this.toolTip1.SetToolTip(this.Ch4Note3, "Note");
            // 
            // Ch4Oct3
            // 
            this.Ch4Oct3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct3", true));
            this.Ch4Oct3.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct3.Name = "Ch4Oct3";
            this.Ch4Oct3.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct3.TabIndex = 56;
            this.toolTip1.SetToolTip(this.Ch4Oct3, "Octave");
            // 
            // Ch4Tie3
            // 
            this.Ch4Tie3.AutoSize = true;
            this.Ch4Tie3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie3", true));
            this.Ch4Tie3.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie3.Name = "Ch4Tie3";
            this.Ch4Tie3.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie3.TabIndex = 57;
            this.toolTip1.SetToolTip(this.Ch4Tie3, "Tie to next note");
            this.Ch4Tie3.UseVisualStyleBackColor = true;
            // 
            // Ch6Note10
            // 
            this.Ch6Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note10", true));
            this.Ch6Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note10.Name = "Ch6Note10";
            this.Ch6Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note10.TabIndex = 177;
            this.toolTip1.SetToolTip(this.Ch6Note10, "Note");
            // 
            // Ch6Oct10
            // 
            this.Ch6Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct10", true));
            this.Ch6Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct10.Name = "Ch6Oct10";
            this.Ch6Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct10.TabIndex = 178;
            this.toolTip1.SetToolTip(this.Ch6Oct10, "Octave");
            // 
            // Ch6Tie10
            // 
            this.Ch6Tie10.AutoSize = true;
            this.Ch6Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie10", true));
            this.Ch6Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie10.Name = "Ch6Tie10";
            this.Ch6Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie10.TabIndex = 179;
            this.toolTip1.SetToolTip(this.Ch6Tie10, "Tie to next note");
            this.Ch6Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch5Note11
            // 
            this.Ch5Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note11", true));
            this.Ch5Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note11.Name = "Ch5Note11";
            this.Ch5Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note11.TabIndex = 192;
            this.toolTip1.SetToolTip(this.Ch5Note11, "Note");
            // 
            // Ch5Oct11
            // 
            this.Ch5Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct11", true));
            this.Ch5Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct11.Name = "Ch5Oct11";
            this.Ch5Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct11.TabIndex = 193;
            this.toolTip1.SetToolTip(this.Ch5Oct11, "Octave");
            // 
            // Ch5Tie11
            // 
            this.Ch5Tie11.AutoSize = true;
            this.Ch5Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie11", true));
            this.Ch5Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie11.Name = "Ch5Tie11";
            this.Ch5Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie11.TabIndex = 194;
            this.toolTip1.SetToolTip(this.Ch5Tie11, "Tie to next note");
            this.Ch5Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch6Note4
            // 
            this.Ch6Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note4", true));
            this.Ch6Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note4.Name = "Ch6Note4";
            this.Ch6Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note4.TabIndex = 69;
            this.toolTip1.SetToolTip(this.Ch6Note4, "Note");
            // 
            // Ch6Oct4
            // 
            this.Ch6Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct4", true));
            this.Ch6Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct4.Name = "Ch6Oct4";
            this.Ch6Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct4.TabIndex = 70;
            this.toolTip1.SetToolTip(this.Ch6Oct4, "Octave");
            // 
            // Ch6Tie4
            // 
            this.Ch6Tie4.AutoSize = true;
            this.Ch6Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie4", true));
            this.Ch6Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie4.Name = "Ch6Tie4";
            this.Ch6Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie4.TabIndex = 71;
            this.toolTip1.SetToolTip(this.Ch6Tie4, "Tie to next note");
            this.Ch6Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch4Note11
            // 
            this.Ch4Note11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note11", true));
            this.Ch4Note11.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note11.Name = "Ch4Note11";
            this.Ch4Note11.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note11.TabIndex = 189;
            this.toolTip1.SetToolTip(this.Ch4Note11, "Note");
            // 
            // Ch4Oct11
            // 
            this.Ch4Oct11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct11", true));
            this.Ch4Oct11.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct11.Name = "Ch4Oct11";
            this.Ch4Oct11.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct11.TabIndex = 190;
            this.toolTip1.SetToolTip(this.Ch4Oct11, "Octave");
            // 
            // Ch4Tie11
            // 
            this.Ch4Tie11.AutoSize = true;
            this.Ch4Tie11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie11", true));
            this.Ch4Tie11.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie11.Name = "Ch4Tie11";
            this.Ch4Tie11.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie11.TabIndex = 191;
            this.toolTip1.SetToolTip(this.Ch4Tie11, "Tie to next note");
            this.Ch4Tie11.UseVisualStyleBackColor = true;
            // 
            // Ch6Note7
            // 
            this.Ch6Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note7", true));
            this.Ch6Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note7.Name = "Ch6Note7";
            this.Ch6Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note7.TabIndex = 123;
            this.toolTip1.SetToolTip(this.Ch6Note7, "Note");
            // 
            // Ch6Oct7
            // 
            this.Ch6Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct7", true));
            this.Ch6Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct7.Name = "Ch6Oct7";
            this.Ch6Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct7.TabIndex = 124;
            this.toolTip1.SetToolTip(this.Ch6Oct7, "Octave");
            // 
            // Ch6Tie7
            // 
            this.Ch6Tie7.AutoSize = true;
            this.Ch6Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie7", true));
            this.Ch6Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie7.Name = "Ch6Tie7";
            this.Ch6Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie7.TabIndex = 125;
            this.toolTip1.SetToolTip(this.Ch6Tie7, "Tie to next note");
            this.Ch6Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch6Note1
            // 
            this.Ch6Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Note1", true));
            this.Ch6Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch6Note1.Name = "Ch6Note1";
            this.Ch6Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch6Note1.TabIndex = 15;
            this.toolTip1.SetToolTip(this.Ch6Note1, "Note");
            // 
            // Ch6Oct1
            // 
            this.Ch6Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch6Oct1", true));
            this.Ch6Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch6Oct1.Name = "Ch6Oct1";
            this.Ch6Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch6Oct1.TabIndex = 16;
            this.toolTip1.SetToolTip(this.Ch6Oct1, "Octave");
            // 
            // Ch6Tie1
            // 
            this.Ch6Tie1.AutoSize = true;
            this.Ch6Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch6Tie1", true));
            this.Ch6Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch6Tie1.Name = "Ch6Tie1";
            this.Ch6Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch6Tie1.TabIndex = 17;
            this.toolTip1.SetToolTip(this.Ch6Tie1, "Tie to next note");
            this.Ch6Tie1.UseVisualStyleBackColor = true;
            // 
            // Ch5Note5
            // 
            this.Ch5Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note5", true));
            this.Ch5Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note5.Name = "Ch5Note5";
            this.Ch5Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note5.TabIndex = 84;
            this.toolTip1.SetToolTip(this.Ch5Note5, "Note");
            // 
            // Ch5Oct5
            // 
            this.Ch5Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct5", true));
            this.Ch5Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct5.Name = "Ch5Oct5";
            this.Ch5Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct5.TabIndex = 85;
            this.toolTip1.SetToolTip(this.Ch5Oct5, "Octave");
            // 
            // Ch5Tie5
            // 
            this.Ch5Tie5.AutoSize = true;
            this.Ch5Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie5", true));
            this.Ch5Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie5.Name = "Ch5Tie5";
            this.Ch5Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie5.TabIndex = 86;
            this.toolTip1.SetToolTip(this.Ch5Tie5, "Tie to next note");
            this.Ch5Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch4Note5
            // 
            this.Ch4Note5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note5", true));
            this.Ch4Note5.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note5.Name = "Ch4Note5";
            this.Ch4Note5.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note5.TabIndex = 81;
            this.toolTip1.SetToolTip(this.Ch4Note5, "Note");
            // 
            // Ch4Oct5
            // 
            this.Ch4Oct5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct5", true));
            this.Ch4Oct5.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct5.Name = "Ch4Oct5";
            this.Ch4Oct5.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct5.TabIndex = 82;
            this.toolTip1.SetToolTip(this.Ch4Oct5, "Octave");
            // 
            // Ch4Tie5
            // 
            this.Ch4Tie5.AutoSize = true;
            this.Ch4Tie5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie5", true));
            this.Ch4Tie5.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie5.Name = "Ch4Tie5";
            this.Ch4Tie5.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie5.TabIndex = 83;
            this.toolTip1.SetToolTip(this.Ch4Tie5, "Tie to next note");
            this.Ch4Tie5.UseVisualStyleBackColor = true;
            // 
            // Ch5Note8
            // 
            this.Ch5Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note8", true));
            this.Ch5Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note8.Name = "Ch5Note8";
            this.Ch5Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note8.TabIndex = 138;
            this.toolTip1.SetToolTip(this.Ch5Note8, "Note");
            // 
            // Ch5Oct8
            // 
            this.Ch5Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct8", true));
            this.Ch5Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct8.Name = "Ch5Oct8";
            this.Ch5Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct8.TabIndex = 139;
            this.toolTip1.SetToolTip(this.Ch5Oct8, "Octave");
            // 
            // Ch5Tie8
            // 
            this.Ch5Tie8.AutoSize = true;
            this.Ch5Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie8", true));
            this.Ch5Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie8.Name = "Ch5Tie8";
            this.Ch5Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie8.TabIndex = 140;
            this.toolTip1.SetToolTip(this.Ch5Tie8, "Tie to next note");
            this.Ch5Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch4Note8
            // 
            this.Ch4Note8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note8", true));
            this.Ch4Note8.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note8.Name = "Ch4Note8";
            this.Ch4Note8.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note8.TabIndex = 135;
            this.toolTip1.SetToolTip(this.Ch4Note8, "Note");
            // 
            // Ch4Oct8
            // 
            this.Ch4Oct8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct8", true));
            this.Ch4Oct8.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct8.Name = "Ch4Oct8";
            this.Ch4Oct8.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct8.TabIndex = 146;
            this.toolTip1.SetToolTip(this.Ch4Oct8, "Octave");
            // 
            // Ch4Tie8
            // 
            this.Ch4Tie8.AutoSize = true;
            this.Ch4Tie8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie8", true));
            this.Ch4Tie8.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie8.Name = "Ch4Tie8";
            this.Ch4Tie8.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie8.TabIndex = 137;
            this.toolTip1.SetToolTip(this.Ch4Tie8, "Tie to next note");
            this.Ch4Tie8.UseVisualStyleBackColor = true;
            // 
            // Ch5Note2
            // 
            this.Ch5Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note2", true));
            this.Ch5Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note2.Name = "Ch5Note2";
            this.Ch5Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note2.TabIndex = 30;
            this.toolTip1.SetToolTip(this.Ch5Note2, "Note");
            // 
            // Ch5Oct2
            // 
            this.Ch5Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct2", true));
            this.Ch5Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct2.Name = "Ch5Oct2";
            this.Ch5Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct2.TabIndex = 31;
            this.toolTip1.SetToolTip(this.Ch5Oct2, "Octave");
            // 
            // Ch5Tie2
            // 
            this.Ch5Tie2.AutoSize = true;
            this.Ch5Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie2", true));
            this.Ch5Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie2.Name = "Ch5Tie2";
            this.Ch5Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie2.TabIndex = 32;
            this.toolTip1.SetToolTip(this.Ch5Tie2, "Tie to next note");
            this.Ch5Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch4Note2
            // 
            this.Ch4Note2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note2", true));
            this.Ch4Note2.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note2.Name = "Ch4Note2";
            this.Ch4Note2.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note2.TabIndex = 27;
            this.toolTip1.SetToolTip(this.Ch4Note2, "Note");
            // 
            // Ch4Oct2
            // 
            this.Ch4Oct2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct2", true));
            this.Ch4Oct2.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct2.Name = "Ch4Oct2";
            this.Ch4Oct2.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct2.TabIndex = 28;
            this.toolTip1.SetToolTip(this.Ch4Oct2, "Octave");
            // 
            // Ch4Tie2
            // 
            this.Ch4Tie2.AutoSize = true;
            this.Ch4Tie2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie2", true));
            this.Ch4Tie2.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie2.Name = "Ch4Tie2";
            this.Ch4Tie2.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie2.TabIndex = 29;
            this.toolTip1.SetToolTip(this.Ch4Tie2, "Tie to next note");
            this.Ch4Tie2.UseVisualStyleBackColor = true;
            // 
            // Ch5Note10
            // 
            this.Ch5Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note10", true));
            this.Ch5Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note10.Name = "Ch5Note10";
            this.Ch5Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note10.TabIndex = 174;
            this.toolTip1.SetToolTip(this.Ch5Note10, "Note");
            // 
            // Ch5Oct10
            // 
            this.Ch5Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct10", true));
            this.Ch5Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct10.Name = "Ch5Oct10";
            this.Ch5Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct10.TabIndex = 175;
            this.toolTip1.SetToolTip(this.Ch5Oct10, "Octave");
            // 
            // Ch5Tie10
            // 
            this.Ch5Tie10.AutoSize = true;
            this.Ch5Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie10", true));
            this.Ch5Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie10.Name = "Ch5Tie10";
            this.Ch5Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie10.TabIndex = 176;
            this.toolTip1.SetToolTip(this.Ch5Tie10, "Tie to next note");
            this.Ch5Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch4Note10
            // 
            this.Ch4Note10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note10", true));
            this.Ch4Note10.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note10.Name = "Ch4Note10";
            this.Ch4Note10.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note10.TabIndex = 171;
            this.toolTip1.SetToolTip(this.Ch4Note10, "Note");
            // 
            // Ch4Oct10
            // 
            this.Ch4Oct10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct10", true));
            this.Ch4Oct10.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct10.Name = "Ch4Oct10";
            this.Ch4Oct10.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct10.TabIndex = 172;
            this.toolTip1.SetToolTip(this.Ch4Oct10, "Octave");
            // 
            // Ch4Tie10
            // 
            this.Ch4Tie10.AutoSize = true;
            this.Ch4Tie10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie10", true));
            this.Ch4Tie10.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie10.Name = "Ch4Tie10";
            this.Ch4Tie10.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie10.TabIndex = 173;
            this.toolTip1.SetToolTip(this.Ch4Tie10, "Tie to next note");
            this.Ch4Tie10.UseVisualStyleBackColor = true;
            // 
            // Ch5Note4
            // 
            this.Ch5Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note4", true));
            this.Ch5Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note4.Name = "Ch5Note4";
            this.Ch5Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note4.TabIndex = 66;
            this.toolTip1.SetToolTip(this.Ch5Note4, "Note");
            // 
            // Ch5Oct4
            // 
            this.Ch5Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct4", true));
            this.Ch5Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct4.Name = "Ch5Oct4";
            this.Ch5Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct4.TabIndex = 67;
            this.toolTip1.SetToolTip(this.Ch5Oct4, "Octave");
            // 
            // Ch5Tie4
            // 
            this.Ch5Tie4.AutoSize = true;
            this.Ch5Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie4", true));
            this.Ch5Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie4.Name = "Ch5Tie4";
            this.Ch5Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie4.TabIndex = 68;
            this.toolTip1.SetToolTip(this.Ch5Tie4, "Tie to next note");
            this.Ch5Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch4Note4
            // 
            this.Ch4Note4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note4", true));
            this.Ch4Note4.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note4.Name = "Ch4Note4";
            this.Ch4Note4.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note4.TabIndex = 63;
            this.toolTip1.SetToolTip(this.Ch4Note4, "Note");
            // 
            // Ch4Oct4
            // 
            this.Ch4Oct4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct4", true));
            this.Ch4Oct4.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct4.Name = "Ch4Oct4";
            this.Ch4Oct4.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct4.TabIndex = 64;
            this.toolTip1.SetToolTip(this.Ch4Oct4, "Octave");
            // 
            // Ch4Tie4
            // 
            this.Ch4Tie4.AutoSize = true;
            this.Ch4Tie4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie4", true));
            this.Ch4Tie4.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie4.Name = "Ch4Tie4";
            this.Ch4Tie4.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie4.TabIndex = 65;
            this.toolTip1.SetToolTip(this.Ch4Tie4, "Tie to next note");
            this.Ch4Tie4.UseVisualStyleBackColor = true;
            // 
            // Ch5Note7
            // 
            this.Ch5Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note7", true));
            this.Ch5Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note7.Name = "Ch5Note7";
            this.Ch5Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note7.TabIndex = 120;
            this.toolTip1.SetToolTip(this.Ch5Note7, "Note");
            // 
            // Ch5Oct7
            // 
            this.Ch5Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct7", true));
            this.Ch5Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct7.Name = "Ch5Oct7";
            this.Ch5Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct7.TabIndex = 121;
            this.toolTip1.SetToolTip(this.Ch5Oct7, "Octave");
            // 
            // Ch5Tie7
            // 
            this.Ch5Tie7.AutoSize = true;
            this.Ch5Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie7", true));
            this.Ch5Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie7.Name = "Ch5Tie7";
            this.Ch5Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie7.TabIndex = 122;
            this.toolTip1.SetToolTip(this.Ch5Tie7, "Tie to next note");
            this.Ch5Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch4Note7
            // 
            this.Ch4Note7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note7", true));
            this.Ch4Note7.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note7.Name = "Ch4Note7";
            this.Ch4Note7.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note7.TabIndex = 117;
            this.toolTip1.SetToolTip(this.Ch4Note7, "Note");
            // 
            // Ch4Oct7
            // 
            this.Ch4Oct7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct7", true));
            this.Ch4Oct7.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct7.Name = "Ch4Oct7";
            this.Ch4Oct7.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct7.TabIndex = 118;
            this.toolTip1.SetToolTip(this.Ch4Oct7, "Octave");
            // 
            // Ch4Tie7
            // 
            this.Ch4Tie7.AutoSize = true;
            this.Ch4Tie7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie7", true));
            this.Ch4Tie7.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie7.Name = "Ch4Tie7";
            this.Ch4Tie7.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie7.TabIndex = 119;
            this.toolTip1.SetToolTip(this.Ch4Tie7, "Tie to next note");
            this.Ch4Tie7.UseVisualStyleBackColor = true;
            // 
            // Ch5Note1
            // 
            this.Ch5Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Note1", true));
            this.Ch5Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch5Note1.Name = "Ch5Note1";
            this.Ch5Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch5Note1.TabIndex = 12;
            this.toolTip1.SetToolTip(this.Ch5Note1, "Note");
            // 
            // Ch5Oct1
            // 
            this.Ch5Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch5Oct1", true));
            this.Ch5Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch5Oct1.Name = "Ch5Oct1";
            this.Ch5Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch5Oct1.TabIndex = 13;
            this.toolTip1.SetToolTip(this.Ch5Oct1, "Octave");
            // 
            // Ch5Tie1
            // 
            this.Ch5Tie1.AutoSize = true;
            this.Ch5Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch5Tie1", true));
            this.Ch5Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch5Tie1.Name = "Ch5Tie1";
            this.Ch5Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch5Tie1.TabIndex = 14;
            this.toolTip1.SetToolTip(this.Ch5Tie1, "Tie to next note");
            this.Ch5Tie1.UseVisualStyleBackColor = true;
            // 
            // Ch4Note1
            // 
            this.Ch4Note1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Note1", true));
            this.Ch4Note1.Location = new System.Drawing.Point(19, 44);
            this.Ch4Note1.Name = "Ch4Note1";
            this.Ch4Note1.Size = new System.Drawing.Size(69, 38);
            this.Ch4Note1.TabIndex = 9;
            this.toolTip1.SetToolTip(this.Ch4Note1, "Note");
            // 
            // Ch4Oct1
            // 
            this.Ch4Oct1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "Ch4Oct1", true));
            this.Ch4Oct1.Location = new System.Drawing.Point(94, 44);
            this.Ch4Oct1.Name = "Ch4Oct1";
            this.Ch4Oct1.Size = new System.Drawing.Size(49, 38);
            this.Ch4Oct1.TabIndex = 10;
            this.toolTip1.SetToolTip(this.Ch4Oct1, "Octave");
            // 
            // Ch4Tie1
            // 
            this.Ch4Tie1.AutoSize = true;
            this.Ch4Tie1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bindingSource1, "Ch4Tie1", true));
            this.Ch4Tie1.Location = new System.Drawing.Point(149, 49);
            this.Ch4Tie1.Name = "Ch4Tie1";
            this.Ch4Tie1.Size = new System.Drawing.Size(34, 33);
            this.Ch4Tie1.TabIndex = 11;
            this.toolTip1.SetToolTip(this.Ch4Tie1, "Tie to next note");
            this.Ch4Tie1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "CH1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Ch1Note1);
            this.groupBox1.Controls.Add(this.Ch1Oct1);
            this.groupBox1.Controls.Add(this.Ch1Tie1);
            this.groupBox1.Location = new System.Drawing.Point(132, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(193, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "1/12";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Ch1Note2);
            this.groupBox2.Controls.Add(this.Ch1Oct2);
            this.groupBox2.Controls.Add(this.Ch1Tie2);
            this.groupBox2.Location = new System.Drawing.Point(331, 109);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(193, 100);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "2/12";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Ch1Note3);
            this.groupBox3.Controls.Add(this.Ch1Oct3);
            this.groupBox3.Controls.Add(this.Ch1Tie3);
            this.groupBox3.Location = new System.Drawing.Point(530, 109);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(193, 100);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "3/12";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Ch1Note6);
            this.groupBox4.Controls.Add(this.Ch1Oct6);
            this.groupBox4.Controls.Add(this.Ch1Tie6);
            this.groupBox4.Location = new System.Drawing.Point(1127, 109);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(193, 100);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "6/12";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Ch1Note5);
            this.groupBox5.Controls.Add(this.Ch1Oct5);
            this.groupBox5.Controls.Add(this.Ch1Tie5);
            this.groupBox5.Location = new System.Drawing.Point(928, 109);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(193, 100);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "5/12";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Ch1Note4);
            this.groupBox6.Controls.Add(this.Ch1Oct4);
            this.groupBox6.Controls.Add(this.Ch1Tie4);
            this.groupBox6.Location = new System.Drawing.Point(729, 109);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(193, 100);
            this.groupBox6.TabIndex = 18;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "4/12";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Ch1Note12);
            this.groupBox7.Controls.Add(this.Ch1Oct12);
            this.groupBox7.Controls.Add(this.Ch1Tie12);
            this.groupBox7.Location = new System.Drawing.Point(2321, 109);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(193, 100);
            this.groupBox7.TabIndex = 66;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "12/12";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.Ch1Note9);
            this.groupBox8.Controls.Add(this.Ch1Oct9);
            this.groupBox8.Controls.Add(this.Ch1Tie9);
            this.groupBox8.Location = new System.Drawing.Point(1724, 109);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(193, 100);
            this.groupBox8.TabIndex = 48;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "9/12";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.Ch1Note11);
            this.groupBox9.Controls.Add(this.Ch1Oct11);
            this.groupBox9.Controls.Add(this.Ch1Tie11);
            this.groupBox9.Location = new System.Drawing.Point(2122, 109);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(193, 100);
            this.groupBox9.TabIndex = 60;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "11/12";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.Ch1Note8);
            this.groupBox10.Controls.Add(this.Ch1Oct8);
            this.groupBox10.Controls.Add(this.Ch1Tie8);
            this.groupBox10.Location = new System.Drawing.Point(1525, 109);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(193, 100);
            this.groupBox10.TabIndex = 42;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "8/12";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.Ch1Note10);
            this.groupBox11.Controls.Add(this.Ch1Oct10);
            this.groupBox11.Controls.Add(this.Ch1Tie10);
            this.groupBox11.Location = new System.Drawing.Point(1923, 109);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(193, 100);
            this.groupBox11.TabIndex = 54;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "10/12";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.Ch1Note7);
            this.groupBox12.Controls.Add(this.Ch1Oct7);
            this.groupBox12.Controls.Add(this.Ch1Tie7);
            this.groupBox12.Location = new System.Drawing.Point(1326, 109);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(193, 100);
            this.groupBox12.TabIndex = 36;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "7/12";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Ch2Note12);
            this.groupBox13.Controls.Add(this.Ch2Oct12);
            this.groupBox13.Controls.Add(this.Ch2Tie12);
            this.groupBox13.Location = new System.Drawing.Point(2321, 235);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(193, 100);
            this.groupBox13.TabIndex = 67;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "12/12";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.Ch2Note6);
            this.groupBox14.Controls.Add(this.Ch2Oct6);
            this.groupBox14.Controls.Add(this.Ch2Tie6);
            this.groupBox14.Location = new System.Drawing.Point(1127, 235);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(193, 100);
            this.groupBox14.TabIndex = 31;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "6/12";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Ch2Note9);
            this.groupBox15.Controls.Add(this.Ch2Oct9);
            this.groupBox15.Controls.Add(this.Ch2Tie9);
            this.groupBox15.Location = new System.Drawing.Point(1724, 235);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(193, 100);
            this.groupBox15.TabIndex = 49;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "9/12";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Ch2Note3);
            this.groupBox16.Controls.Add(this.Ch2Oct3);
            this.groupBox16.Controls.Add(this.Ch2Tie3);
            this.groupBox16.Location = new System.Drawing.Point(530, 235);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(193, 100);
            this.groupBox16.TabIndex = 13;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "3/12";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.Ch2Note11);
            this.groupBox17.Controls.Add(this.Ch2Oct11);
            this.groupBox17.Controls.Add(this.Ch2Tie11);
            this.groupBox17.Location = new System.Drawing.Point(2122, 235);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(193, 100);
            this.groupBox17.TabIndex = 61;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "11/12";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Ch2Note5);
            this.groupBox18.Controls.Add(this.Ch2Oct5);
            this.groupBox18.Controls.Add(this.Ch2Tie5);
            this.groupBox18.Location = new System.Drawing.Point(928, 235);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(193, 100);
            this.groupBox18.TabIndex = 25;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "5/12";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.Ch2Note8);
            this.groupBox19.Controls.Add(this.Ch2Oct8);
            this.groupBox19.Controls.Add(this.Ch2Tie8);
            this.groupBox19.Location = new System.Drawing.Point(1525, 235);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(193, 100);
            this.groupBox19.TabIndex = 43;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "8/12";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.Ch2Note2);
            this.groupBox20.Controls.Add(this.Ch2Oct2);
            this.groupBox20.Controls.Add(this.Ch2Tie2);
            this.groupBox20.Location = new System.Drawing.Point(331, 235);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(193, 100);
            this.groupBox20.TabIndex = 7;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "2/12";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.Ch2Note10);
            this.groupBox21.Controls.Add(this.Ch2Oct10);
            this.groupBox21.Controls.Add(this.Ch2Tie10);
            this.groupBox21.Location = new System.Drawing.Point(1923, 235);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(193, 100);
            this.groupBox21.TabIndex = 55;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "10/12";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.Ch2Note4);
            this.groupBox22.Controls.Add(this.Ch2Oct4);
            this.groupBox22.Controls.Add(this.Ch2Tie4);
            this.groupBox22.Location = new System.Drawing.Point(729, 235);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(193, 100);
            this.groupBox22.TabIndex = 19;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "4/12";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.Ch2Note7);
            this.groupBox23.Controls.Add(this.Ch2Oct7);
            this.groupBox23.Controls.Add(this.Ch2Tie7);
            this.groupBox23.Location = new System.Drawing.Point(1326, 235);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(193, 100);
            this.groupBox23.TabIndex = 37;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "7/12";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.Ch2Note1);
            this.groupBox24.Controls.Add(this.Ch2Oct1);
            this.groupBox24.Controls.Add(this.Ch2Tie1);
            this.groupBox24.Location = new System.Drawing.Point(132, 235);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(193, 100);
            this.groupBox24.TabIndex = 1;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "1/12";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 32);
            this.label2.TabIndex = 16;
            this.label2.Text = "CH2";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.Ch3Note12);
            this.groupBox25.Controls.Add(this.Ch3Oct12);
            this.groupBox25.Controls.Add(this.Ch3Tie12);
            this.groupBox25.Location = new System.Drawing.Point(2321, 365);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(193, 100);
            this.groupBox25.TabIndex = 68;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "12/12";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.Ch3Note6);
            this.groupBox26.Controls.Add(this.Ch3Oct6);
            this.groupBox26.Controls.Add(this.Ch3Tie6);
            this.groupBox26.Location = new System.Drawing.Point(1127, 365);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(193, 100);
            this.groupBox26.TabIndex = 32;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "6/12";
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.Ch3Note9);
            this.groupBox27.Controls.Add(this.Ch3Oct9);
            this.groupBox27.Controls.Add(this.Ch3Tie9);
            this.groupBox27.Location = new System.Drawing.Point(1724, 365);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(193, 100);
            this.groupBox27.TabIndex = 50;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "9/12";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.Ch3Note3);
            this.groupBox28.Controls.Add(this.Ch3Oct3);
            this.groupBox28.Controls.Add(this.Ch3Tie3);
            this.groupBox28.Location = new System.Drawing.Point(530, 365);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(193, 100);
            this.groupBox28.TabIndex = 14;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "3/12";
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.Ch3Note11);
            this.groupBox29.Controls.Add(this.Ch3Oct11);
            this.groupBox29.Controls.Add(this.Ch3Tie11);
            this.groupBox29.Location = new System.Drawing.Point(2122, 365);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(193, 100);
            this.groupBox29.TabIndex = 62;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "11/12";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.Ch3Note5);
            this.groupBox30.Controls.Add(this.Ch3Oct5);
            this.groupBox30.Controls.Add(this.Ch3Tie5);
            this.groupBox30.Location = new System.Drawing.Point(928, 365);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(193, 100);
            this.groupBox30.TabIndex = 26;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "5/12";
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.Ch3Note8);
            this.groupBox31.Controls.Add(this.Ch3Oct8);
            this.groupBox31.Controls.Add(this.Ch3Tie8);
            this.groupBox31.Location = new System.Drawing.Point(1525, 365);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(193, 100);
            this.groupBox31.TabIndex = 44;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "8/12";
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.Ch3Note2);
            this.groupBox32.Controls.Add(this.Ch3Oct2);
            this.groupBox32.Controls.Add(this.Ch3Tie2);
            this.groupBox32.Location = new System.Drawing.Point(331, 365);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(193, 100);
            this.groupBox32.TabIndex = 8;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "2/12";
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.Ch3Note10);
            this.groupBox33.Controls.Add(this.Ch3Oct10);
            this.groupBox33.Controls.Add(this.Ch3Tie10);
            this.groupBox33.Location = new System.Drawing.Point(1923, 365);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(193, 100);
            this.groupBox33.TabIndex = 56;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "10/12";
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.Ch3Note4);
            this.groupBox34.Controls.Add(this.Ch3Oct4);
            this.groupBox34.Controls.Add(this.Ch3Tie4);
            this.groupBox34.Location = new System.Drawing.Point(729, 365);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(193, 100);
            this.groupBox34.TabIndex = 20;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "4/12";
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.Ch3Note7);
            this.groupBox35.Controls.Add(this.Ch3Oct7);
            this.groupBox35.Controls.Add(this.Ch3Tie7);
            this.groupBox35.Location = new System.Drawing.Point(1326, 365);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(193, 100);
            this.groupBox35.TabIndex = 38;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "7/12";
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.Ch3Note1);
            this.groupBox36.Controls.Add(this.Ch3Oct1);
            this.groupBox36.Controls.Add(this.Ch3Tie1);
            this.groupBox36.Location = new System.Drawing.Point(132, 365);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(193, 100);
            this.groupBox36.TabIndex = 2;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "1/12";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 32);
            this.label3.TabIndex = 16;
            this.label3.Text = "CH3";
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.Ch6Note12);
            this.groupBox37.Controls.Add(this.Ch6Oct12);
            this.groupBox37.Controls.Add(this.Ch6Tie12);
            this.groupBox37.Location = new System.Drawing.Point(2321, 759);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(193, 100);
            this.groupBox37.TabIndex = 71;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "12/12";
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.Ch5Note12);
            this.groupBox38.Controls.Add(this.Ch5Oct12);
            this.groupBox38.Controls.Add(this.Ch5Tie12);
            this.groupBox38.Location = new System.Drawing.Point(2321, 629);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(193, 100);
            this.groupBox38.TabIndex = 70;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "12/12";
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.Ch6Note6);
            this.groupBox39.Controls.Add(this.Ch6Oct6);
            this.groupBox39.Controls.Add(this.Ch6Tie6);
            this.groupBox39.Location = new System.Drawing.Point(1127, 759);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(193, 100);
            this.groupBox39.TabIndex = 35;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "6/12";
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.Ch4Note12);
            this.groupBox40.Controls.Add(this.Ch4Oct12);
            this.groupBox40.Controls.Add(this.Ch4Tie12);
            this.groupBox40.Location = new System.Drawing.Point(2321, 503);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(193, 100);
            this.groupBox40.TabIndex = 69;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "12/12";
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.Ch6Note9);
            this.groupBox41.Controls.Add(this.Ch6Oct9);
            this.groupBox41.Controls.Add(this.Ch6Tie9);
            this.groupBox41.Location = new System.Drawing.Point(1724, 759);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(193, 100);
            this.groupBox41.TabIndex = 53;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "9/12";
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.Ch5Note6);
            this.groupBox42.Controls.Add(this.Ch5Oct6);
            this.groupBox42.Controls.Add(this.Ch5Tie6);
            this.groupBox42.Location = new System.Drawing.Point(1127, 629);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(193, 100);
            this.groupBox42.TabIndex = 34;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "6/12";
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.Ch6Note3);
            this.groupBox43.Controls.Add(this.Ch6Oct3);
            this.groupBox43.Controls.Add(this.Ch6Tie3);
            this.groupBox43.Location = new System.Drawing.Point(530, 759);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(193, 100);
            this.groupBox43.TabIndex = 17;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "3/12";
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.Ch4Note6);
            this.groupBox44.Controls.Add(this.Ch4Oct6);
            this.groupBox44.Controls.Add(this.Ch4Tie6);
            this.groupBox44.Location = new System.Drawing.Point(1127, 503);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(193, 100);
            this.groupBox44.TabIndex = 33;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "6/12";
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.Ch6Note11);
            this.groupBox45.Controls.Add(this.Ch6Oct11);
            this.groupBox45.Controls.Add(this.Ch6Tie11);
            this.groupBox45.Location = new System.Drawing.Point(2122, 759);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(193, 100);
            this.groupBox45.TabIndex = 65;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "11/12";
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.Ch5Note9);
            this.groupBox46.Controls.Add(this.Ch5Oct9);
            this.groupBox46.Controls.Add(this.Ch5Tie9);
            this.groupBox46.Location = new System.Drawing.Point(1724, 629);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(193, 100);
            this.groupBox46.TabIndex = 52;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "9/12";
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.Ch6Note5);
            this.groupBox47.Controls.Add(this.Ch6Oct5);
            this.groupBox47.Controls.Add(this.Ch6Tie5);
            this.groupBox47.Location = new System.Drawing.Point(928, 759);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(193, 100);
            this.groupBox47.TabIndex = 29;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "5/12";
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.Ch4Note9);
            this.groupBox48.Controls.Add(this.Ch4Oct9);
            this.groupBox48.Controls.Add(this.Ch4Tie9);
            this.groupBox48.Location = new System.Drawing.Point(1724, 503);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(193, 100);
            this.groupBox48.TabIndex = 51;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "9/12";
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.Ch6Note8);
            this.groupBox49.Controls.Add(this.Ch6Oct8);
            this.groupBox49.Controls.Add(this.Ch6Tie8);
            this.groupBox49.Location = new System.Drawing.Point(1525, 759);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(193, 100);
            this.groupBox49.TabIndex = 47;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "8/12";
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.Ch5Note3);
            this.groupBox50.Controls.Add(this.Ch5Oct3);
            this.groupBox50.Controls.Add(this.Ch5Tie3);
            this.groupBox50.Location = new System.Drawing.Point(530, 629);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(193, 100);
            this.groupBox50.TabIndex = 16;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "3/12";
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.Ch6Note2);
            this.groupBox51.Controls.Add(this.Ch6Oct2);
            this.groupBox51.Controls.Add(this.Ch6Tie2);
            this.groupBox51.Location = new System.Drawing.Point(331, 759);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(193, 100);
            this.groupBox51.TabIndex = 11;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "2/12";
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.Ch4Note3);
            this.groupBox52.Controls.Add(this.Ch4Oct3);
            this.groupBox52.Controls.Add(this.Ch4Tie3);
            this.groupBox52.Location = new System.Drawing.Point(530, 503);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(193, 100);
            this.groupBox52.TabIndex = 15;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "3/12";
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.Ch6Note10);
            this.groupBox53.Controls.Add(this.Ch6Oct10);
            this.groupBox53.Controls.Add(this.Ch6Tie10);
            this.groupBox53.Location = new System.Drawing.Point(1923, 759);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(193, 100);
            this.groupBox53.TabIndex = 59;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "10/12";
            // 
            // groupBox54
            // 
            this.groupBox54.Controls.Add(this.Ch5Note11);
            this.groupBox54.Controls.Add(this.Ch5Oct11);
            this.groupBox54.Controls.Add(this.Ch5Tie11);
            this.groupBox54.Location = new System.Drawing.Point(2122, 629);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Size = new System.Drawing.Size(193, 100);
            this.groupBox54.TabIndex = 64;
            this.groupBox54.TabStop = false;
            this.groupBox54.Text = "11/12";
            // 
            // groupBox55
            // 
            this.groupBox55.Controls.Add(this.Ch6Note4);
            this.groupBox55.Controls.Add(this.Ch6Oct4);
            this.groupBox55.Controls.Add(this.Ch6Tie4);
            this.groupBox55.Location = new System.Drawing.Point(729, 759);
            this.groupBox55.Name = "groupBox55";
            this.groupBox55.Size = new System.Drawing.Size(193, 100);
            this.groupBox55.TabIndex = 23;
            this.groupBox55.TabStop = false;
            this.groupBox55.Text = "4/12";
            // 
            // groupBox56
            // 
            this.groupBox56.Controls.Add(this.Ch4Note11);
            this.groupBox56.Controls.Add(this.Ch4Oct11);
            this.groupBox56.Controls.Add(this.Ch4Tie11);
            this.groupBox56.Location = new System.Drawing.Point(2122, 503);
            this.groupBox56.Name = "groupBox56";
            this.groupBox56.Size = new System.Drawing.Size(193, 100);
            this.groupBox56.TabIndex = 63;
            this.groupBox56.TabStop = false;
            this.groupBox56.Text = "11/12";
            // 
            // groupBox57
            // 
            this.groupBox57.Controls.Add(this.Ch6Note7);
            this.groupBox57.Controls.Add(this.Ch6Oct7);
            this.groupBox57.Controls.Add(this.Ch6Tie7);
            this.groupBox57.Location = new System.Drawing.Point(1326, 759);
            this.groupBox57.Name = "groupBox57";
            this.groupBox57.Size = new System.Drawing.Size(193, 100);
            this.groupBox57.TabIndex = 41;
            this.groupBox57.TabStop = false;
            this.groupBox57.Text = "7/12";
            // 
            // groupBox58
            // 
            this.groupBox58.Controls.Add(this.Ch6Note1);
            this.groupBox58.Controls.Add(this.Ch6Oct1);
            this.groupBox58.Controls.Add(this.Ch6Tie1);
            this.groupBox58.Location = new System.Drawing.Point(132, 759);
            this.groupBox58.Name = "groupBox58";
            this.groupBox58.Size = new System.Drawing.Size(193, 100);
            this.groupBox58.TabIndex = 5;
            this.groupBox58.TabStop = false;
            this.groupBox58.Text = "1/12";
            // 
            // groupBox59
            // 
            this.groupBox59.Controls.Add(this.Ch5Note5);
            this.groupBox59.Controls.Add(this.Ch5Oct5);
            this.groupBox59.Controls.Add(this.Ch5Tie5);
            this.groupBox59.Location = new System.Drawing.Point(928, 629);
            this.groupBox59.Name = "groupBox59";
            this.groupBox59.Size = new System.Drawing.Size(193, 100);
            this.groupBox59.TabIndex = 28;
            this.groupBox59.TabStop = false;
            this.groupBox59.Text = "5/12";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 808);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 32);
            this.label4.TabIndex = 43;
            this.label4.Text = "CH6";
            // 
            // groupBox60
            // 
            this.groupBox60.Controls.Add(this.Ch4Note5);
            this.groupBox60.Controls.Add(this.Ch4Oct5);
            this.groupBox60.Controls.Add(this.Ch4Tie5);
            this.groupBox60.Location = new System.Drawing.Point(928, 503);
            this.groupBox60.Name = "groupBox60";
            this.groupBox60.Size = new System.Drawing.Size(193, 100);
            this.groupBox60.TabIndex = 27;
            this.groupBox60.TabStop = false;
            this.groupBox60.Text = "5/12";
            // 
            // groupBox61
            // 
            this.groupBox61.Controls.Add(this.Ch5Note8);
            this.groupBox61.Controls.Add(this.Ch5Oct8);
            this.groupBox61.Controls.Add(this.Ch5Tie8);
            this.groupBox61.Location = new System.Drawing.Point(1525, 629);
            this.groupBox61.Name = "groupBox61";
            this.groupBox61.Size = new System.Drawing.Size(193, 100);
            this.groupBox61.TabIndex = 46;
            this.groupBox61.TabStop = false;
            this.groupBox61.Text = "8/12";
            // 
            // groupBox62
            // 
            this.groupBox62.Controls.Add(this.Ch4Note8);
            this.groupBox62.Controls.Add(this.Ch4Oct8);
            this.groupBox62.Controls.Add(this.Ch4Tie8);
            this.groupBox62.Location = new System.Drawing.Point(1525, 503);
            this.groupBox62.Name = "groupBox62";
            this.groupBox62.Size = new System.Drawing.Size(193, 100);
            this.groupBox62.TabIndex = 45;
            this.groupBox62.TabStop = false;
            this.groupBox62.Text = "8/12";
            // 
            // groupBox63
            // 
            this.groupBox63.Controls.Add(this.Ch5Note2);
            this.groupBox63.Controls.Add(this.Ch5Oct2);
            this.groupBox63.Controls.Add(this.Ch5Tie2);
            this.groupBox63.Location = new System.Drawing.Point(331, 629);
            this.groupBox63.Name = "groupBox63";
            this.groupBox63.Size = new System.Drawing.Size(193, 100);
            this.groupBox63.TabIndex = 10;
            this.groupBox63.TabStop = false;
            this.groupBox63.Text = "2/12";
            // 
            // groupBox64
            // 
            this.groupBox64.Controls.Add(this.Ch4Note2);
            this.groupBox64.Controls.Add(this.Ch4Oct2);
            this.groupBox64.Controls.Add(this.Ch4Tie2);
            this.groupBox64.Location = new System.Drawing.Point(331, 503);
            this.groupBox64.Name = "groupBox64";
            this.groupBox64.Size = new System.Drawing.Size(193, 100);
            this.groupBox64.TabIndex = 9;
            this.groupBox64.TabStop = false;
            this.groupBox64.Text = "2/12";
            // 
            // groupBox65
            // 
            this.groupBox65.Controls.Add(this.Ch5Note10);
            this.groupBox65.Controls.Add(this.Ch5Oct10);
            this.groupBox65.Controls.Add(this.Ch5Tie10);
            this.groupBox65.Location = new System.Drawing.Point(1923, 629);
            this.groupBox65.Name = "groupBox65";
            this.groupBox65.Size = new System.Drawing.Size(193, 100);
            this.groupBox65.TabIndex = 58;
            this.groupBox65.TabStop = false;
            this.groupBox65.Text = "10/12";
            // 
            // groupBox66
            // 
            this.groupBox66.Controls.Add(this.Ch4Note10);
            this.groupBox66.Controls.Add(this.Ch4Oct10);
            this.groupBox66.Controls.Add(this.Ch4Tie10);
            this.groupBox66.Location = new System.Drawing.Point(1923, 503);
            this.groupBox66.Name = "groupBox66";
            this.groupBox66.Size = new System.Drawing.Size(193, 100);
            this.groupBox66.TabIndex = 57;
            this.groupBox66.TabStop = false;
            this.groupBox66.Text = "10/12";
            // 
            // groupBox67
            // 
            this.groupBox67.Controls.Add(this.Ch5Note4);
            this.groupBox67.Controls.Add(this.Ch5Oct4);
            this.groupBox67.Controls.Add(this.Ch5Tie4);
            this.groupBox67.Location = new System.Drawing.Point(729, 629);
            this.groupBox67.Name = "groupBox67";
            this.groupBox67.Size = new System.Drawing.Size(193, 100);
            this.groupBox67.TabIndex = 22;
            this.groupBox67.TabStop = false;
            this.groupBox67.Text = "4/12";
            // 
            // groupBox68
            // 
            this.groupBox68.Controls.Add(this.Ch4Note4);
            this.groupBox68.Controls.Add(this.Ch4Oct4);
            this.groupBox68.Controls.Add(this.Ch4Tie4);
            this.groupBox68.Location = new System.Drawing.Point(729, 503);
            this.groupBox68.Name = "groupBox68";
            this.groupBox68.Size = new System.Drawing.Size(193, 100);
            this.groupBox68.TabIndex = 21;
            this.groupBox68.TabStop = false;
            this.groupBox68.Text = "4/12";
            // 
            // groupBox69
            // 
            this.groupBox69.Controls.Add(this.Ch5Note7);
            this.groupBox69.Controls.Add(this.Ch5Oct7);
            this.groupBox69.Controls.Add(this.Ch5Tie7);
            this.groupBox69.Location = new System.Drawing.Point(1326, 629);
            this.groupBox69.Name = "groupBox69";
            this.groupBox69.Size = new System.Drawing.Size(193, 100);
            this.groupBox69.TabIndex = 40;
            this.groupBox69.TabStop = false;
            this.groupBox69.Text = "7/12";
            // 
            // groupBox70
            // 
            this.groupBox70.Controls.Add(this.Ch4Note7);
            this.groupBox70.Controls.Add(this.Ch4Oct7);
            this.groupBox70.Controls.Add(this.Ch4Tie7);
            this.groupBox70.Location = new System.Drawing.Point(1326, 503);
            this.groupBox70.Name = "groupBox70";
            this.groupBox70.Size = new System.Drawing.Size(193, 100);
            this.groupBox70.TabIndex = 39;
            this.groupBox70.TabStop = false;
            this.groupBox70.Text = "7/12";
            // 
            // groupBox71
            // 
            this.groupBox71.Controls.Add(this.Ch5Note1);
            this.groupBox71.Controls.Add(this.Ch5Oct1);
            this.groupBox71.Controls.Add(this.Ch5Tie1);
            this.groupBox71.Location = new System.Drawing.Point(132, 629);
            this.groupBox71.Name = "groupBox71";
            this.groupBox71.Size = new System.Drawing.Size(193, 100);
            this.groupBox71.TabIndex = 4;
            this.groupBox71.TabStop = false;
            this.groupBox71.Text = "1/12";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 678);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 32);
            this.label5.TabIndex = 42;
            this.label5.Text = "CH5";
            // 
            // groupBox72
            // 
            this.groupBox72.Controls.Add(this.Ch4Note1);
            this.groupBox72.Controls.Add(this.Ch4Oct1);
            this.groupBox72.Controls.Add(this.Ch4Tie1);
            this.groupBox72.Location = new System.Drawing.Point(132, 503);
            this.groupBox72.Name = "groupBox72";
            this.groupBox72.Size = new System.Drawing.Size(193, 100);
            this.groupBox72.TabIndex = 3;
            this.groupBox72.TabStop = false;
            this.groupBox72.Text = "1/12";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 552);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 32);
            this.label6.TabIndex = 29;
            this.label6.Text = "CH4";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newButton,
            this.openMusicButton,
            this.saveMusicButton,
            this.exportMusicButton,
            this.toolStripSeparator1,
            this.monoStereoDropDown,
            this.leftRightComboBox,
            this.addMeasureButton,
            this.deleteMeasureButton,
            this.toolStripSeparator2,
            this.prevMeasure,
            this.currentRecordLabel,
            this.nextMeasure,
            this.saveMeasureButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(2548, 62);
            this.toolStrip1.TabIndex = 69;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newButton
            // 
            this.newButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.newButton.Image = ((System.Drawing.Image)(resources.GetObject("newButton.Image")));
            this.newButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(168, 55);
            this.newButton.Text = "&New Music";
            this.newButton.ToolTipText = "New Music";
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // openMusicButton
            // 
            this.openMusicButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.openMusicButton.Image = ((System.Drawing.Image)(resources.GetObject("openMusicButton.Image")));
            this.openMusicButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openMusicButton.Name = "openMusicButton";
            this.openMusicButton.Size = new System.Drawing.Size(182, 55);
            this.openMusicButton.Text = "&Open Music";
            this.openMusicButton.Click += new System.EventHandler(this.openMusicButton_Click);
            // 
            // saveMusicButton
            // 
            this.saveMusicButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveMusicButton.Image = ((System.Drawing.Image)(resources.GetObject("saveMusicButton.Image")));
            this.saveMusicButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveMusicButton.Name = "saveMusicButton";
            this.saveMusicButton.Size = new System.Drawing.Size(169, 55);
            this.saveMusicButton.Text = "&Save Music";
            this.saveMusicButton.Click += new System.EventHandler(this.saveMusicButton_Click);
            // 
            // exportMusicButton
            // 
            this.exportMusicButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.exportMusicButton.Image = ((System.Drawing.Image)(resources.GetObject("exportMusicButton.Image")));
            this.exportMusicButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exportMusicButton.Name = "exportMusicButton";
            this.exportMusicButton.Size = new System.Drawing.Size(193, 55);
            this.exportMusicButton.Text = "E&xport Music";
            this.exportMusicButton.Click += new System.EventHandler(this.exportMusicButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 62);
            // 
            // monoStereoDropDown
            // 
            this.monoStereoDropDown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.monoStereoDropDown.Items.AddRange(new object[] {
            "Mono",
            "Stereo"});
            this.monoStereoDropDown.Name = "monoStereoDropDown";
            this.monoStereoDropDown.Size = new System.Drawing.Size(150, 62);
            // 
            // leftRightComboBox
            // 
            this.leftRightComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.leftRightComboBox.Items.AddRange(new object[] {
            "Left",
            "Right"});
            this.leftRightComboBox.Name = "leftRightComboBox";
            this.leftRightComboBox.Size = new System.Drawing.Size(120, 62);
            // 
            // addMeasureButton
            // 
            this.addMeasureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.addMeasureButton.Image = ((System.Drawing.Image)(resources.GetObject("addMeasureButton.Image")));
            this.addMeasureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.addMeasureButton.Name = "addMeasureButton";
            this.addMeasureButton.Size = new System.Drawing.Size(199, 55);
            this.addMeasureButton.Text = "&Add Measure";
            this.addMeasureButton.ToolTipText = "Add Measure";
            this.addMeasureButton.Click += new System.EventHandler(this.addMeasureButton_Click);
            // 
            // deleteMeasureButton
            // 
            this.deleteMeasureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.deleteMeasureButton.Image = ((System.Drawing.Image)(resources.GetObject("deleteMeasureButton.Image")));
            this.deleteMeasureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.deleteMeasureButton.Name = "deleteMeasureButton";
            this.deleteMeasureButton.Size = new System.Drawing.Size(230, 55);
            this.deleteMeasureButton.Text = "&Delete Measure";
            this.deleteMeasureButton.Click += new System.EventHandler(this.deleteMeasureButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 62);
            // 
            // prevMeasure
            // 
            this.prevMeasure.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.prevMeasure.Image = ((System.Drawing.Image)(resources.GetObject("prevMeasure.Image")));
            this.prevMeasure.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.prevMeasure.Name = "prevMeasure";
            this.prevMeasure.Size = new System.Drawing.Size(58, 55);
            this.prevMeasure.Text = "<";
            this.prevMeasure.ToolTipText = "Previous Measure";
            this.prevMeasure.Click += new System.EventHandler(this.prevMeasure_Click);
            // 
            // currentRecordLabel
            // 
            this.currentRecordLabel.AutoSize = false;
            this.currentRecordLabel.Name = "currentRecordLabel";
            this.currentRecordLabel.Size = new System.Drawing.Size(150, 55);
            this.currentRecordLabel.Text = "- of -";
            this.currentRecordLabel.ToolTipText = "Current Record";
            // 
            // nextMeasure
            // 
            this.nextMeasure.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.nextMeasure.Image = ((System.Drawing.Image)(resources.GetObject("nextMeasure.Image")));
            this.nextMeasure.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.nextMeasure.Name = "nextMeasure";
            this.nextMeasure.Size = new System.Drawing.Size(58, 55);
            this.nextMeasure.Text = ">";
            this.nextMeasure.ToolTipText = "Next Measure";
            this.nextMeasure.Click += new System.EventHandler(this.nextMeasure_Click);
            // 
            // saveMeasureButton
            // 
            this.saveMeasureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveMeasureButton.Image = ((System.Drawing.Image)(resources.GetObject("saveMeasureButton.Image")));
            this.saveMeasureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveMeasureButton.Name = "saveMeasureButton";
            this.saveMeasureButton.Size = new System.Drawing.Size(205, 55);
            this.saveMeasureButton.Text = "Save Measure";
            this.saveMeasureButton.Click += new System.EventHandler(this.saveMeasureButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "music";
            this.openFileDialog1.FileName = "MySong";
            this.openFileDialog1.Filter = "Music files|*.music";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "music";
            this.saveFileDialog1.FileName = "MySong";
            this.saveFileDialog1.Filter = "Music files|*.music";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(2080, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(353, 32);
            this.label7.TabIndex = 72;
            this.label7.Text = "Measure Tick Denominator";
            // 
            // tickDenomTextBox
            // 
            this.tickDenomTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "TickDenom", true));
            this.tickDenomTextBox.Location = new System.Drawing.Point(2453, 12);
            this.tickDenomTextBox.Name = "tickDenomTextBox";
            this.tickDenomTextBox.Size = new System.Drawing.Size(61, 38);
            this.tickDenomTextBox.TabIndex = 73;
            this.tickDenomTextBox.Text = "1";
            // 
            // editorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(240F, 240F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(2548, 1052);
            this.Controls.Add(this.tickDenomTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox37);
            this.Controls.Add(this.groupBox25);
            this.Controls.Add(this.groupBox38);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox39);
            this.Controls.Add(this.groupBox26);
            this.Controls.Add(this.groupBox40);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox41);
            this.Controls.Add(this.groupBox27);
            this.Controls.Add(this.groupBox42);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox43);
            this.Controls.Add(this.groupBox28);
            this.Controls.Add(this.groupBox44);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox45);
            this.Controls.Add(this.groupBox29);
            this.Controls.Add(this.groupBox46);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox47);
            this.Controls.Add(this.groupBox30);
            this.Controls.Add(this.groupBox48);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox49);
            this.Controls.Add(this.groupBox31);
            this.Controls.Add(this.groupBox50);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox51);
            this.Controls.Add(this.groupBox32);
            this.Controls.Add(this.groupBox52);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox53);
            this.Controls.Add(this.groupBox33);
            this.Controls.Add(this.groupBox54);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox55);
            this.Controls.Add(this.groupBox34);
            this.Controls.Add(this.groupBox56);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox57);
            this.Controls.Add(this.groupBox35);
            this.Controls.Add(this.groupBox58);
            this.Controls.Add(this.groupBox36);
            this.Controls.Add(this.groupBox59);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox60);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox61);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.groupBox62);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox63);
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox64);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox65);
            this.Controls.Add(this.groupBox21);
            this.Controls.Add(this.groupBox66);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox67);
            this.Controls.Add(this.groupBox22);
            this.Controls.Add(this.groupBox68);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox69);
            this.Controls.Add(this.groupBox23);
            this.Controls.Add(this.groupBox70);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox71);
            this.Controls.Add(this.groupBox24);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox72);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "editorForm";
            this.Text = "Music Measure Editor";
            this.Load += new System.EventHandler(this.editorForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.musicDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.songDataTable)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox38.ResumeLayout(false);
            this.groupBox38.PerformLayout();
            this.groupBox39.ResumeLayout(false);
            this.groupBox39.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.groupBox49.PerformLayout();
            this.groupBox50.ResumeLayout(false);
            this.groupBox50.PerformLayout();
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox53.ResumeLayout(false);
            this.groupBox53.PerformLayout();
            this.groupBox54.ResumeLayout(false);
            this.groupBox54.PerformLayout();
            this.groupBox55.ResumeLayout(false);
            this.groupBox55.PerformLayout();
            this.groupBox56.ResumeLayout(false);
            this.groupBox56.PerformLayout();
            this.groupBox57.ResumeLayout(false);
            this.groupBox57.PerformLayout();
            this.groupBox58.ResumeLayout(false);
            this.groupBox58.PerformLayout();
            this.groupBox59.ResumeLayout(false);
            this.groupBox59.PerformLayout();
            this.groupBox60.ResumeLayout(false);
            this.groupBox60.PerformLayout();
            this.groupBox61.ResumeLayout(false);
            this.groupBox61.PerformLayout();
            this.groupBox62.ResumeLayout(false);
            this.groupBox62.PerformLayout();
            this.groupBox63.ResumeLayout(false);
            this.groupBox63.PerformLayout();
            this.groupBox64.ResumeLayout(false);
            this.groupBox64.PerformLayout();
            this.groupBox65.ResumeLayout(false);
            this.groupBox65.PerformLayout();
            this.groupBox66.ResumeLayout(false);
            this.groupBox66.PerformLayout();
            this.groupBox67.ResumeLayout(false);
            this.groupBox67.PerformLayout();
            this.groupBox68.ResumeLayout(false);
            this.groupBox68.PerformLayout();
            this.groupBox69.ResumeLayout(false);
            this.groupBox69.PerformLayout();
            this.groupBox70.ResumeLayout(false);
            this.groupBox70.PerformLayout();
            this.groupBox71.ResumeLayout(false);
            this.groupBox71.PerformLayout();
            this.groupBox72.ResumeLayout(false);
            this.groupBox72.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Ch1Oct1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox Ch1Tie1;
        private System.Windows.Forms.TextBox Ch1Note1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Ch1Note2;
        private System.Windows.Forms.TextBox Ch1Oct2;
        private System.Windows.Forms.CheckBox Ch1Tie2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Ch1Note3;
        private System.Windows.Forms.TextBox Ch1Oct3;
        private System.Windows.Forms.CheckBox Ch1Tie3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox Ch1Note6;
        private System.Windows.Forms.TextBox Ch1Oct6;
        private System.Windows.Forms.CheckBox Ch1Tie6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox Ch1Note5;
        private System.Windows.Forms.TextBox Ch1Oct5;
        private System.Windows.Forms.CheckBox Ch1Tie5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox Ch1Note4;
        private System.Windows.Forms.TextBox Ch1Oct4;
        private System.Windows.Forms.CheckBox Ch1Tie4;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox Ch1Note12;
        private System.Windows.Forms.TextBox Ch1Oct12;
        private System.Windows.Forms.CheckBox Ch1Tie12;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox Ch1Note9;
        private System.Windows.Forms.TextBox Ch1Oct9;
        private System.Windows.Forms.CheckBox Ch1Tie9;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox Ch1Note11;
        private System.Windows.Forms.TextBox Ch1Oct11;
        private System.Windows.Forms.CheckBox Ch1Tie11;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox Ch1Note8;
        private System.Windows.Forms.TextBox Ch1Oct8;
        private System.Windows.Forms.CheckBox Ch1Tie8;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox Ch1Note10;
        private System.Windows.Forms.TextBox Ch1Oct10;
        private System.Windows.Forms.CheckBox Ch1Tie10;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox Ch1Note7;
        private System.Windows.Forms.TextBox Ch1Oct7;
        private System.Windows.Forms.CheckBox Ch1Tie7;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox Ch2Note12;
        private System.Windows.Forms.TextBox Ch2Oct12;
        private System.Windows.Forms.CheckBox Ch2Tie12;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox Ch2Note6;
        private System.Windows.Forms.TextBox Ch2Oct6;
        private System.Windows.Forms.CheckBox Ch2Tie6;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox Ch2Note9;
        private System.Windows.Forms.TextBox Ch2Oct9;
        private System.Windows.Forms.CheckBox Ch2Tie9;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox Ch2Note3;
        private System.Windows.Forms.TextBox Ch2Oct3;
        private System.Windows.Forms.CheckBox Ch2Tie3;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox Ch2Note11;
        private System.Windows.Forms.TextBox Ch2Oct11;
        private System.Windows.Forms.CheckBox Ch2Tie11;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox Ch2Note5;
        private System.Windows.Forms.TextBox Ch2Oct5;
        private System.Windows.Forms.CheckBox Ch2Tie5;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox Ch2Note8;
        private System.Windows.Forms.TextBox Ch2Oct8;
        private System.Windows.Forms.CheckBox Ch2Tie8;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox Ch2Note2;
        private System.Windows.Forms.TextBox Ch2Oct2;
        private System.Windows.Forms.CheckBox Ch2Tie2;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox Ch2Note10;
        private System.Windows.Forms.TextBox Ch2Oct10;
        private System.Windows.Forms.CheckBox Ch2Tie10;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox Ch2Note4;
        private System.Windows.Forms.TextBox Ch2Oct4;
        private System.Windows.Forms.CheckBox Ch2Tie4;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox Ch2Note7;
        private System.Windows.Forms.TextBox Ch2Oct7;
        private System.Windows.Forms.CheckBox Ch2Tie7;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TextBox Ch2Note1;
        private System.Windows.Forms.TextBox Ch2Oct1;
        private System.Windows.Forms.CheckBox Ch2Tie1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.TextBox Ch3Note12;
        private System.Windows.Forms.TextBox Ch3Oct12;
        private System.Windows.Forms.CheckBox Ch3Tie12;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.TextBox Ch3Note6;
        private System.Windows.Forms.TextBox Ch3Oct6;
        private System.Windows.Forms.CheckBox Ch3Tie6;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TextBox Ch3Note9;
        private System.Windows.Forms.TextBox Ch3Oct9;
        private System.Windows.Forms.CheckBox Ch3Tie9;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.TextBox Ch3Note3;
        private System.Windows.Forms.TextBox Ch3Oct3;
        private System.Windows.Forms.CheckBox Ch3Tie3;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.TextBox Ch3Note11;
        private System.Windows.Forms.TextBox Ch3Oct11;
        private System.Windows.Forms.CheckBox Ch3Tie11;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.TextBox Ch3Note5;
        private System.Windows.Forms.TextBox Ch3Oct5;
        private System.Windows.Forms.CheckBox Ch3Tie5;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TextBox Ch3Note8;
        private System.Windows.Forms.TextBox Ch3Oct8;
        private System.Windows.Forms.CheckBox Ch3Tie8;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.TextBox Ch3Note2;
        private System.Windows.Forms.TextBox Ch3Oct2;
        private System.Windows.Forms.CheckBox Ch3Tie2;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.TextBox Ch3Note10;
        private System.Windows.Forms.TextBox Ch3Oct10;
        private System.Windows.Forms.CheckBox Ch3Tie10;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.TextBox Ch3Note4;
        private System.Windows.Forms.TextBox Ch3Oct4;
        private System.Windows.Forms.CheckBox Ch3Tie4;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.TextBox Ch3Note7;
        private System.Windows.Forms.TextBox Ch3Oct7;
        private System.Windows.Forms.CheckBox Ch3Tie7;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.TextBox Ch3Note1;
        private System.Windows.Forms.TextBox Ch3Oct1;
        private System.Windows.Forms.CheckBox Ch3Tie1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.TextBox Ch6Note12;
        private System.Windows.Forms.TextBox Ch6Oct12;
        private System.Windows.Forms.CheckBox Ch6Tie12;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.TextBox Ch5Note12;
        private System.Windows.Forms.TextBox Ch5Oct12;
        private System.Windows.Forms.CheckBox Ch5Tie12;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.TextBox Ch6Note6;
        private System.Windows.Forms.TextBox Ch6Oct6;
        private System.Windows.Forms.CheckBox Ch6Tie6;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.TextBox Ch4Note12;
        private System.Windows.Forms.TextBox Ch4Oct12;
        private System.Windows.Forms.CheckBox Ch4Tie12;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.TextBox Ch6Note9;
        private System.Windows.Forms.TextBox Ch6Oct9;
        private System.Windows.Forms.CheckBox Ch6Tie9;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.TextBox Ch5Note6;
        private System.Windows.Forms.TextBox Ch5Oct6;
        private System.Windows.Forms.CheckBox Ch5Tie6;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.TextBox Ch6Note3;
        private System.Windows.Forms.TextBox Ch6Oct3;
        private System.Windows.Forms.CheckBox Ch6Tie3;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.TextBox Ch4Note6;
        private System.Windows.Forms.TextBox Ch4Oct6;
        private System.Windows.Forms.CheckBox Ch4Tie6;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.TextBox Ch6Note11;
        private System.Windows.Forms.TextBox Ch6Oct11;
        private System.Windows.Forms.CheckBox Ch6Tie11;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TextBox Ch5Note9;
        private System.Windows.Forms.TextBox Ch5Oct9;
        private System.Windows.Forms.CheckBox Ch5Tie9;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TextBox Ch6Note5;
        private System.Windows.Forms.TextBox Ch6Oct5;
        private System.Windows.Forms.CheckBox Ch6Tie5;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.TextBox Ch4Note9;
        private System.Windows.Forms.TextBox Ch4Oct9;
        private System.Windows.Forms.CheckBox Ch4Tie9;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TextBox Ch6Note8;
        private System.Windows.Forms.TextBox Ch6Oct8;
        private System.Windows.Forms.CheckBox Ch6Tie8;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.TextBox Ch5Note3;
        private System.Windows.Forms.TextBox Ch5Oct3;
        private System.Windows.Forms.CheckBox Ch5Tie3;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.TextBox Ch6Note2;
        private System.Windows.Forms.TextBox Ch6Oct2;
        private System.Windows.Forms.CheckBox Ch6Tie2;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.TextBox Ch4Note3;
        private System.Windows.Forms.TextBox Ch4Oct3;
        private System.Windows.Forms.CheckBox Ch4Tie3;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.TextBox Ch6Note10;
        private System.Windows.Forms.TextBox Ch6Oct10;
        private System.Windows.Forms.CheckBox Ch6Tie10;
        private System.Windows.Forms.GroupBox groupBox54;
        private System.Windows.Forms.TextBox Ch5Note11;
        private System.Windows.Forms.TextBox Ch5Oct11;
        private System.Windows.Forms.CheckBox Ch5Tie11;
        private System.Windows.Forms.GroupBox groupBox55;
        private System.Windows.Forms.TextBox Ch6Note4;
        private System.Windows.Forms.TextBox Ch6Oct4;
        private System.Windows.Forms.CheckBox Ch6Tie4;
        private System.Windows.Forms.GroupBox groupBox56;
        private System.Windows.Forms.TextBox Ch4Note11;
        private System.Windows.Forms.TextBox Ch4Oct11;
        private System.Windows.Forms.CheckBox Ch4Tie11;
        private System.Windows.Forms.GroupBox groupBox57;
        private System.Windows.Forms.TextBox Ch6Note7;
        private System.Windows.Forms.TextBox Ch6Oct7;
        private System.Windows.Forms.CheckBox Ch6Tie7;
        private System.Windows.Forms.GroupBox groupBox58;
        private System.Windows.Forms.TextBox Ch6Note1;
        private System.Windows.Forms.TextBox Ch6Oct1;
        private System.Windows.Forms.CheckBox Ch6Tie1;
        private System.Windows.Forms.GroupBox groupBox59;
        private System.Windows.Forms.TextBox Ch5Note5;
        private System.Windows.Forms.TextBox Ch5Oct5;
        private System.Windows.Forms.CheckBox Ch5Tie5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox60;
        private System.Windows.Forms.TextBox Ch4Note5;
        private System.Windows.Forms.TextBox Ch4Oct5;
        private System.Windows.Forms.CheckBox Ch4Tie5;
        private System.Windows.Forms.GroupBox groupBox61;
        private System.Windows.Forms.TextBox Ch5Note8;
        private System.Windows.Forms.TextBox Ch5Oct8;
        private System.Windows.Forms.CheckBox Ch5Tie8;
        private System.Windows.Forms.GroupBox groupBox62;
        private System.Windows.Forms.TextBox Ch4Note8;
        private System.Windows.Forms.TextBox Ch4Oct8;
        private System.Windows.Forms.CheckBox Ch4Tie8;
        private System.Windows.Forms.GroupBox groupBox63;
        private System.Windows.Forms.TextBox Ch5Note2;
        private System.Windows.Forms.TextBox Ch5Oct2;
        private System.Windows.Forms.CheckBox Ch5Tie2;
        private System.Windows.Forms.GroupBox groupBox64;
        private System.Windows.Forms.TextBox Ch4Note2;
        private System.Windows.Forms.TextBox Ch4Oct2;
        private System.Windows.Forms.CheckBox Ch4Tie2;
        private System.Windows.Forms.GroupBox groupBox65;
        private System.Windows.Forms.TextBox Ch5Note10;
        private System.Windows.Forms.TextBox Ch5Oct10;
        private System.Windows.Forms.CheckBox Ch5Tie10;
        private System.Windows.Forms.GroupBox groupBox66;
        private System.Windows.Forms.TextBox Ch4Note10;
        private System.Windows.Forms.TextBox Ch4Oct10;
        private System.Windows.Forms.CheckBox Ch4Tie10;
        private System.Windows.Forms.GroupBox groupBox67;
        private System.Windows.Forms.TextBox Ch5Note4;
        private System.Windows.Forms.TextBox Ch5Oct4;
        private System.Windows.Forms.CheckBox Ch5Tie4;
        private System.Windows.Forms.GroupBox groupBox68;
        private System.Windows.Forms.TextBox Ch4Note4;
        private System.Windows.Forms.TextBox Ch4Oct4;
        private System.Windows.Forms.CheckBox Ch4Tie4;
        private System.Windows.Forms.GroupBox groupBox69;
        private System.Windows.Forms.TextBox Ch5Note7;
        private System.Windows.Forms.TextBox Ch5Oct7;
        private System.Windows.Forms.CheckBox Ch5Tie7;
        private System.Windows.Forms.GroupBox groupBox70;
        private System.Windows.Forms.TextBox Ch4Note7;
        private System.Windows.Forms.TextBox Ch4Oct7;
        private System.Windows.Forms.CheckBox Ch4Tie7;
        private System.Windows.Forms.GroupBox groupBox71;
        private System.Windows.Forms.TextBox Ch5Note1;
        private System.Windows.Forms.TextBox Ch5Oct1;
        private System.Windows.Forms.CheckBox Ch5Tie1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox72;
        private System.Windows.Forms.TextBox Ch4Note1;
        private System.Windows.Forms.TextBox Ch4Oct1;
        private System.Windows.Forms.CheckBox Ch4Tie1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton prevMeasure;
        private System.Windows.Forms.ToolStripButton nextMeasure;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton openMusicButton;
        private System.Windows.Forms.ToolStripButton saveMusicButton;
        private System.Windows.Forms.ToolStripButton exportMusicButton;
        private System.Windows.Forms.ToolStripLabel currentRecordLabel;
        private System.Data.DataSet musicDataSet;
        private System.Data.DataTable songDataTable;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataColumn dataColumn44;
        private System.Data.DataColumn dataColumn45;
        private System.Data.DataColumn dataColumn46;
        private System.Data.DataColumn dataColumn47;
        private System.Data.DataColumn dataColumn48;
        private System.Data.DataColumn dataColumn49;
        private System.Data.DataColumn dataColumn50;
        private System.Data.DataColumn dataColumn51;
        private System.Data.DataColumn dataColumn52;
        private System.Data.DataColumn dataColumn53;
        private System.Data.DataColumn dataColumn54;
        private System.Data.DataColumn dataColumn55;
        private System.Data.DataColumn dataColumn56;
        private System.Data.DataColumn dataColumn57;
        private System.Data.DataColumn dataColumn58;
        private System.Data.DataColumn dataColumn59;
        private System.Data.DataColumn dataColumn60;
        private System.Data.DataColumn dataColumn61;
        private System.Data.DataColumn dataColumn62;
        private System.Data.DataColumn dataColumn63;
        private System.Data.DataColumn dataColumn64;
        private System.Data.DataColumn dataColumn65;
        private System.Data.DataColumn dataColumn66;
        private System.Data.DataColumn dataColumn67;
        private System.Data.DataColumn dataColumn68;
        private System.Data.DataColumn dataColumn69;
        private System.Data.DataColumn dataColumn70;
        private System.Data.DataColumn dataColumn71;
        private System.Data.DataColumn dataColumn72;
        private System.Data.DataColumn dataColumn73;
        private System.Data.DataColumn dataColumn74;
        private System.Data.DataColumn dataColumn75;
        private System.Data.DataColumn dataColumn76;
        private System.Data.DataColumn dataColumn77;
        private System.Data.DataColumn dataColumn78;
        private System.Data.DataColumn dataColumn79;
        private System.Data.DataColumn dataColumn80;
        private System.Data.DataColumn dataColumn81;
        private System.Data.DataColumn dataColumn82;
        private System.Data.DataColumn dataColumn83;
        private System.Data.DataColumn dataColumn84;
        private System.Data.DataColumn dataColumn85;
        private System.Data.DataColumn dataColumn86;
        private System.Data.DataColumn dataColumn87;
        private System.Data.DataColumn dataColumn88;
        private System.Data.DataColumn dataColumn89;
        private System.Data.DataColumn dataColumn90;
        private System.Data.DataColumn dataColumn91;
        private System.Data.DataColumn dataColumn92;
        private System.Data.DataColumn dataColumn93;
        private System.Data.DataColumn dataColumn94;
        private System.Data.DataColumn dataColumn95;
        private System.Data.DataColumn dataColumn96;
        private System.Data.DataColumn dataColumn97;
        private System.Data.DataColumn dataColumn98;
        private System.Data.DataColumn dataColumn99;
        private System.Data.DataColumn dataColumn100;
        private System.Data.DataColumn dataColumn101;
        private System.Data.DataColumn dataColumn102;
        private System.Data.DataColumn dataColumn103;
        private System.Data.DataColumn dataColumn104;
        private System.Data.DataColumn dataColumn105;
        private System.Data.DataColumn dataColumn106;
        private System.Data.DataColumn dataColumn107;
        private System.Data.DataColumn dataColumn108;
        private System.Data.DataColumn dataColumn109;
        private System.Data.DataColumn dataColumn110;
        private System.Data.DataColumn dataColumn111;
        private System.Data.DataColumn dataColumn112;
        private System.Data.DataColumn dataColumn113;
        private System.Data.DataColumn dataColumn114;
        private System.Data.DataColumn dataColumn115;
        private System.Data.DataColumn dataColumn116;
        private System.Data.DataColumn dataColumn117;
        private System.Data.DataColumn dataColumn118;
        private System.Data.DataColumn dataColumn119;
        private System.Data.DataColumn dataColumn120;
        private System.Data.DataColumn dataColumn121;
        private System.Data.DataColumn dataColumn122;
        private System.Data.DataColumn dataColumn123;
        private System.Data.DataColumn dataColumn124;
        private System.Data.DataColumn dataColumn125;
        private System.Data.DataColumn dataColumn126;
        private System.Data.DataColumn dataColumn127;
        private System.Data.DataColumn dataColumn128;
        private System.Data.DataColumn dataColumn129;
        private System.Data.DataColumn dataColumn130;
        private System.Data.DataColumn dataColumn131;
        private System.Data.DataColumn dataColumn132;
        private System.Data.DataColumn dataColumn133;
        private System.Data.DataColumn dataColumn134;
        private System.Data.DataColumn dataColumn135;
        private System.Data.DataColumn dataColumn136;
        private System.Data.DataColumn dataColumn137;
        private System.Data.DataColumn dataColumn138;
        private System.Data.DataColumn dataColumn139;
        private System.Data.DataColumn dataColumn140;
        private System.Data.DataColumn dataColumn141;
        private System.Data.DataColumn dataColumn142;
        private System.Data.DataColumn dataColumn143;
        private System.Data.DataColumn dataColumn144;
        private System.Data.DataColumn dataColumn145;
        private System.Data.DataColumn dataColumn146;
        private System.Data.DataColumn dataColumn147;
        private System.Data.DataColumn dataColumn148;
        private System.Data.DataColumn dataColumn149;
        private System.Data.DataColumn dataColumn150;
        private System.Data.DataColumn dataColumn151;
        private System.Data.DataColumn dataColumn152;
        private System.Data.DataColumn dataColumn153;
        private System.Data.DataColumn dataColumn154;
        private System.Data.DataColumn dataColumn155;
        private System.Data.DataColumn dataColumn156;
        private System.Data.DataColumn dataColumn157;
        private System.Data.DataColumn dataColumn158;
        private System.Data.DataColumn dataColumn159;
        private System.Data.DataColumn dataColumn160;
        private System.Data.DataColumn dataColumn161;
        private System.Data.DataColumn dataColumn162;
        private System.Data.DataColumn dataColumn163;
        private System.Data.DataColumn dataColumn164;
        private System.Data.DataColumn dataColumn165;
        private System.Data.DataColumn dataColumn166;
        private System.Data.DataColumn dataColumn167;
        private System.Data.DataColumn dataColumn168;
        private System.Data.DataColumn dataColumn169;
        private System.Data.DataColumn dataColumn170;
        private System.Data.DataColumn dataColumn171;
        private System.Data.DataColumn dataColumn172;
        private System.Data.DataColumn dataColumn173;
        private System.Data.DataColumn dataColumn174;
        private System.Data.DataColumn dataColumn175;
        private System.Data.DataColumn dataColumn176;
        private System.Data.DataColumn dataColumn177;
        private System.Data.DataColumn dataColumn178;
        private System.Data.DataColumn dataColumn179;
        private System.Data.DataColumn dataColumn180;
        private System.Data.DataColumn dataColumn181;
        private System.Data.DataColumn dataColumn182;
        private System.Data.DataColumn dataColumn183;
        private System.Data.DataColumn dataColumn184;
        private System.Data.DataColumn dataColumn185;
        private System.Data.DataColumn dataColumn186;
        private System.Data.DataColumn dataColumn187;
        private System.Data.DataColumn dataColumn188;
        private System.Data.DataColumn dataColumn189;
        private System.Data.DataColumn dataColumn190;
        private System.Data.DataColumn dataColumn191;
        private System.Data.DataColumn dataColumn192;
        private System.Data.DataColumn dataColumn193;
        private System.Data.DataColumn dataColumn194;
        private System.Data.DataColumn dataColumn195;
        private System.Data.DataColumn dataColumn196;
        private System.Data.DataColumn dataColumn197;
        private System.Data.DataColumn dataColumn198;
        private System.Data.DataColumn dataColumn199;
        private System.Data.DataColumn dataColumn200;
        private System.Data.DataColumn dataColumn201;
        private System.Data.DataColumn dataColumn202;
        private System.Data.DataColumn dataColumn203;
        private System.Data.DataColumn dataColumn204;
        private System.Data.DataColumn dataColumn205;
        private System.Data.DataColumn dataColumn206;
        private System.Data.DataColumn dataColumn207;
        private System.Data.DataColumn dataColumn208;
        private System.Data.DataColumn dataColumn209;
        private System.Data.DataColumn dataColumn210;
        private System.Data.DataColumn dataColumn211;
        private System.Data.DataColumn dataColumn212;
        private System.Data.DataColumn dataColumn213;
        private System.Data.DataColumn dataColumn214;
        private System.Data.DataColumn dataColumn215;
        private System.Data.DataColumn dataColumn216;
        private System.Windows.Forms.ToolStripButton addMeasureButton;
        private System.Windows.Forms.ToolStripButton deleteMeasureButton;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label7;
        private System.Data.DataColumn dataColumn217;
        private System.Windows.Forms.TextBox tickDenomTextBox;
        private System.Windows.Forms.ToolStripButton newButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripComboBox monoStereoDropDown;
        private System.Windows.Forms.ToolStripComboBox leftRightComboBox;
        private System.Windows.Forms.ToolStripButton saveMeasureButton;
    }
}

