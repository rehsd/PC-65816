﻿/* 
 * Purpose: Create "music" and export binary data for saving on SD Card and playback with dynamic routines on 6502
 * 
 * Based on rehsd sound card.
 * 
 * Special command characters to be interpreted accordingly by 6502 assembly:
 *      0x00-0x0F                       : Reserved for AY commands (register numbers). Immediately followed by value for the command. See https://f.rdw.se/AY-3-8910-datasheet.pdf, page 9. Note, reference table uses octal for register numbers.
 *      0x11 (ASCII Device Control 1)   : Delay command. Next byte is delay duration.    1=normal tick, 2=half tick, 3=quarter tick, 0=minimal for note ups (no tie)
 *      0x1C (ASCII File Separator)     : End of the file on the SD Card
 *      0x1D (ASCII Group Separator)    : AY# command. Next byte is which AY is being configured. 1=Left A,B,C. 3=Left D,E,F. 2=Right A,B,C. 4=Right D,E,F.
 *      0x1E (ASCII Record Separator)   : Use between measures.
 *      0x1F (ASCII Unit Separator)     : Use between columns in a measure.
 *      0xFF                            : End of music
 *      
 * To do:
 *      -Exception handling
 *      
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MusicEditor
{
    public partial class editorForm : Form
    {
        struct NoteTones
        {
            private readonly string note;
            private readonly short octave;
            private readonly short course;
            private readonly short fine;

            public NoteTones(string note, short octave, short course, short fine)
            {
                this.note = note;
                this.octave = octave;
                this.course = course;
                this.fine = fine;
            }

            public string Note { get { return note; } }
            public short Octave { get { return octave; } }
            public short Course { get { return course; } }
            public short Fine { get { return fine; } }

        }
        readonly NoteTones[]  nt = {
            new NoteTones ("C", 11, 0x0, 0x3),
            new NoteTones ("B", 10, 0x0, 0x3),
            new NoteTones ("A#", 10, 0x0, 0x4),
            new NoteTones ("A", 10, 0x0, 0x4),
            new NoteTones ("G#", 10, 0x0, 0x4),
            new NoteTones ("G", 10, 0x0, 0x4),
            new NoteTones ("F#", 10, 0x0, 0x5),
            new NoteTones ("F", 10, 0x0, 0x5),
            new NoteTones ("E", 10, 0x0, 0x5),
            new NoteTones ("D#", 10, 0x0, 0x6),
            new NoteTones ("D", 10, 0x0, 0x6),
            new NoteTones ("C#", 10, 0x0, 0x7),
            new NoteTones ("C", 10, 0x0, 0x7),
            new NoteTones ("B", 9, 0x0, 0x7),
            new NoteTones ("A#", 9, 0x0, 0x8),
            new NoteTones ("A", 9, 0x0, 0x8),
            new NoteTones ("G#", 9, 0x0, 0x9),
            new NoteTones ("G", 9, 0x0, 0x9),
            new NoteTones ("F#", 9, 0x0, 0xA),
            new NoteTones ("F", 9, 0x0, 0xB),
            new NoteTones ("E", 9, 0x0, 0xB),
            new NoteTones ("D#", 9, 0x0, 0xC),
            new NoteTones ("D", 9, 0x0, 0xD),
            new NoteTones ("C#", 9, 0x0, 0xE),
            new NoteTones ("C", 9, 0x0, 0xE),
            new NoteTones ("B", 8, 0x0, 0xF),
            new NoteTones ("A#", 8, 0x0, 0x10),
            new NoteTones ("A", 8, 0x0, 0x11),
            new NoteTones ("G#", 8, 0x0, 0x12),
            new NoteTones ("G", 8, 0x0, 0x13),
            new NoteTones ("F#", 8, 0x0, 0x15),
            new NoteTones ("F", 8, 0x0, 0x16),
            new NoteTones ("E", 8, 0x0, 0x17),
            new NoteTones ("D#", 8, 0x0, 0x19),
            new NoteTones ("D", 8, 0x0, 0x1A),
            new NoteTones ("C#", 8, 0x0, 0x1C),
            new NoteTones ("C", 8, 0x0, 0x1D),
            new NoteTones ("B", 7, 0x0, 0x1F),
            new NoteTones ("A#", 7, 0x0, 0x21),
            new NoteTones ("A", 7, 0x0, 0x23),
            new NoteTones ("G#", 7, 0x0, 0x25),
            new NoteTones ("G", 7, 0x0, 0x27),
            new NoteTones ("F#", 7, 0x0, 0x2A),
            new NoteTones ("F", 7, 0x0, 0x2C),
            new NoteTones ("E", 7, 0x0, 0x2F),
            new NoteTones ("D#", 7, 0x0, 0x32),
            new NoteTones ("D", 7, 0x0, 0x35),
            new NoteTones ("C#", 7, 0x0, 0x38),
            new NoteTones ("C", 7, 0x0, 0x3B),
            new NoteTones ("B", 6, 0x0, 0x3F),
            new NoteTones ("A#", 6, 0x0, 0x43),
            new NoteTones ("A", 6, 0x0, 0x47),
            new NoteTones ("G#", 6, 0x0, 0x4B),
            new NoteTones ("G", 6, 0x0, 0x4F),
            new NoteTones ("F#", 6, 0x0, 0x54),
            new NoteTones ("F", 6, 0x0, 0x59),
            new NoteTones ("E", 6, 0x0, 0x5E),
            new NoteTones ("D#", 6, 0x0, 0x64),
            new NoteTones ("D", 6, 0x0, 0x6A),
            new NoteTones ("C#", 6, 0x0, 0x70),
            new NoteTones ("C", 6, 0x0, 0x77),
            new NoteTones ("B", 5, 0x0, 0x7E),
            new NoteTones ("A#", 5, 0x0, 0x86),
            new NoteTones ("A", 5, 0x0, 0x8E),
            new NoteTones ("G#", 5, 0x0, 0x96),
            new NoteTones ("G", 5, 0x0, 0x9F),
            new NoteTones ("F#", 5, 0x0, 0xA8),
            new NoteTones ("F", 5, 0x0, 0xB2),
            new NoteTones ("E", 5, 0x0, 0xBD),
            new NoteTones ("D#", 5, 0x0, 0xC8),
            new NoteTones ("D", 5, 0x0, 0xD4),
            new NoteTones ("C#", 5, 0x0, 0xE1),
            new NoteTones ("C", 5, 0x0, 0xEE),
            new NoteTones ("B", 4, 0x0, 0xFD),
            new NoteTones ("A#", 4, 0x1, 0xC),
            new NoteTones ("A", 4, 0x1, 0x1C),
            new NoteTones ("G#", 4, 0x1, 0x2C),
            new NoteTones ("G", 4, 0x1, 0x3E),
            new NoteTones ("F#", 4, 0x1, 0x51),
            new NoteTones ("F", 4, 0x1, 0x65),
            new NoteTones ("E", 4, 0x1, 0x7B),
            new NoteTones ("D#", 4, 0x1, 0x91),
            new NoteTones ("D", 4, 0x1, 0xA9),
            new NoteTones ("C#", 4, 0x1, 0xC2),
            new NoteTones ("C", 4, 0x1, 0xDD),
            new NoteTones ("B", 3, 0x1, 0xFA),
            new NoteTones ("A#", 3, 0x2, 0x18),
            new NoteTones ("A", 3, 0x2, 0x38),
            new NoteTones ("G#", 3, 0x2, 0x59),
            new NoteTones ("G", 3, 0x2, 0x7D),
            new NoteTones ("F#", 3, 0x2, 0xA3),
            new NoteTones ("F", 3, 0x2, 0xCB),
            new NoteTones ("E", 3, 0x2, 0xF6),
            new NoteTones ("D#", 3, 0x3, 0x23),
            new NoteTones ("D", 3, 0x3, 0x53),
            new NoteTones ("C#", 3, 0x3, 0x85),
            new NoteTones ("C", 3, 0x3, 0xBB),
            new NoteTones ("B", 2, 0x3, 0xF4),
            new NoteTones ("A#", 2, 0x4, 0x30),
            new NoteTones ("A", 2, 0x4, 0x70),
            new NoteTones ("G#", 2, 0x4, 0xB3),
            new NoteTones ("G", 2, 0x4, 0xFB),
            new NoteTones ("F#", 2, 0x5, 0x47),
            new NoteTones ("F", 2, 0x5, 0x97),
            new NoteTones ("E", 2, 0x5, 0xEC),
            new NoteTones ("D#", 2, 0x6, 0x47),
            new NoteTones ("D", 2, 0x6, 0xA6),
            new NoteTones ("C#", 2, 0x7, 0xB),
            new NoteTones ("C", 2, 0x7, 0x77),
            new NoteTones ("B", 1, 0x7, 0xE8),
            new NoteTones ("A#", 1, 0x8, 0x61),
            new NoteTones ("A", 1, 0x8, 0xE0),
            new NoteTones ("G#", 1, 0x9, 0x67),
            new NoteTones ("G", 1, 0x9, 0xF7),
            new NoteTones ("F#", 1, 0xA, 0x8E),
            new NoteTones ("F", 1, 0xB, 0x2F),
            new NoteTones ("E", 1, 0xB, 0xD9),
            new NoteTones ("D#", 1, 0xC, 0x8E),
            new NoteTones ("D", 1, 0xD, 0x4D),
            new NoteTones ("C#", 1, 0xE, 0x17),
            new NoteTones ("C", 1, 0xE, 0xEE),
            new NoteTones ("B", 0, 0xF, 0xD1),
            new NoteTones ("A#", 0, 0x10, 0xC2),
            new NoteTones ("A", 0, 0x11, 0xC1),
            new NoteTones ("G#", 0, 0x12, 0xCF),
            new NoteTones ("G", 0, 0x13, 0xEE),
            new NoteTones ("F#", 0, 0x15, 0x1D),
            new NoteTones ("F", 0, 0x16, 0x5E),
            new NoteTones ("E", 0, 0x17, 0xB3),
            new NoteTones ("D#", 0, 0x19, 0x1C),
            new NoteTones ("D", 0, 0x1A, 0x9A),
            new NoteTones ("C#", 0, 0x1C, 0x2F),
            new NoteTones ("C", 0, 0x1D, 0xDC),
                };

        public editorForm()
        {
            InitializeComponent();
        }

        private void editorForm_Load(object sender, EventArgs e)
        {
            bindingSource1.AddNew();
            monoStereoDropDown.SelectedIndex= 0;
            leftRightComboBox.SelectedIndex= 0;
            monoStereoDropDown.Enabled = false;
            leftRightComboBox.Enabled = false;
        }

        private void addMeasureButton_Click(object sender, EventArgs e)
        {
            bindingSource1.AddNew();
        }

        private void nextMeasure_Click(object sender, EventArgs e)
        {
            bindingSource1.MoveNext();
        }

        private void prevMeasure_Click(object sender, EventArgs e)
        {
            bindingSource1.MovePrevious();
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            updatePosition();
        }

        void updatePosition()
        {
            currentRecordLabel.Text = (bindingSource1.Position + 1).ToString() + " of " + bindingSource1.Count.ToString();
        }

        private void saveMusicButton_Click(object sender, EventArgs e)
        {
            DialogResult r = saveFileDialog1.ShowDialog();
            if(r==DialogResult.OK)
            {
                musicDataSet.WriteXml(saveFileDialog1.FileName);
            }
        }

        private void openMusicButton_Click(object sender, EventArgs e)
        {
            DialogResult r = openFileDialog1.ShowDialog();
            if (r == DialogResult.OK)
            {
                songDataTable.Clear();
                musicDataSet.ReadXml(openFileDialog1.FileName);
                bindingSource1.ResetCurrentItem();
                ; updatePosition();
            }
        }

        private void deleteMeasureButton_Click(object sender, EventArgs e)
        {
            bindingSource1.RemoveCurrent();
            updatePosition();
        }

        private void exportMusicButton_Click(object sender, EventArgs e)
        {
            short tC, tF;
            bool noTieCh1 = false, noTieCh2 = false, noTieCh3 = false, noTieCh4 = false, noTieCh5 = false, noTieCh6 = false;
            MemoryStream stream = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stream);
            DataRow row;

            for (int i = 0; i < songDataTable.Rows.Count; i++)
            {
                //store row as raw byte data - a row is a full measure
                row = songDataTable.Rows[i];

                for (int j = 0; j < row.Table.Columns.Count - 1; j++)     //ignore the last column (TickDenom)
                {
                    //see if there is data to write, otherwise skip
                    if (row[j].ToString() != "")        //to do: better validation here. Both note and octave need to be specified, or skip it.
                    {
                        switch (j % 18)
                        {
                            case 0:         //note for AY1 ChA      //for now, supporting mono only - mirroring right to left channel
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x00);    //ChA fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x01);    //ChA course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x08);    //ChA amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh1 = false;
                                }
                                else
                                {
                                    noTieCh1 = true;
                                }
                                break;
                            case 3:         //note for AY1 ChB
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x02);    //ChB fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x03);    //ChB course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x09);    //ChB amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh2 = false;
                                }
                                else
                                {
                                    noTieCh2 = true;
                                }
                                break;
                            case 6:         //note for AY1 ChC
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x04);    //ChC fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x05);    //ChC course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x0A);    //ChC amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh3 = false;
                                }
                                else
                                {
                                    noTieCh3 = true;
                                }
                                break;
                            case 9:         //note for AY3 ChA
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x00);    //ChA fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x01);    //ChA course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x08);    //ChA amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh4 = false;
                                }
                                else
                                {
                                    noTieCh4 = true;
                                }
                                break;
                            case 12:        //note for AY3 ChB
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x02);    //ChB fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x03);    //ChB course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x09);    //ChB amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh5 = false;
                                }
                                else
                                {
                                    noTieCh5 = true;
                                }
                                break;
                            case 15:        //note for AY3 ChC
                                tC = getToneCourse(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                tF = getToneFine(row[j].ToString(), short.Parse(row[j + 1].ToString()));
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x04);    //ChC fine
                                writer.Write((byte)tF);
                                writer.Write((byte)0x05);    //ChC course
                                writer.Write((byte)tC);
                                writer.Write((byte)0x0A);    //ChC amplitude
                                writer.Write((byte)0x0F);
                                if (bool.Parse(row[j + 2].ToString()) == true)
                                {
                                    noTieCh6 = false;
                                }
                                else
                                {
                                    noTieCh6 = true;
                                }

                                break;
                        }
                    }
                    else
                    {
                        //Turn off the channel
                        switch (j%18)
                        {
                            case 0:
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x08);    //ChA amplitude
                                writer.Write((byte)0x00);
                                break;
                            case 3:
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x09);    //ChB amplitude
                                writer.Write((byte)0x00);
                                break;
                            case 6:
                                writer.Write((byte)0x1D);    //Select AY1
                                writer.Write((byte)1);
                                writer.Write((byte)0x0A);    //ChC amplitude
                                writer.Write((byte)0x00);
                                break;
                            case 9:
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x08);    //ChA amplitude
                                writer.Write((byte)0x00);
                                break;
                            case 12:
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x09);    //ChB amplitude
                                writer.Write((byte)0x00);
                                break;
                            case 15:
                                writer.Write((byte)0x1D);    //Select AY3
                                writer.Write((byte)3);
                                writer.Write((byte)0x0A);    //ChC amplitude
                                writer.Write((byte)0x00);

                                break;
                        }
                    }

                    //use 0x1F (unit separator) between notes
                    //use 0x1D (group separator) with AY# immediately following to select which AY is used for output
                    //use 0x1E (record separator) between measures
                    //0x1C (file separator) will close out entire song

                    if ((j + 1) % 18 == 0)    //last item in the column
                    {
                        //As the last notes for the column within the measure, add delay here
                        writer.Write((byte)0x11);   //Delay (hold note) (using ASCII device control 1)
                        writer.Write(byte.Parse(row["TickDenom"].ToString()));

                        //Check if Tie was not set for any notes. If so, need to turn it off tone momentarily before moving to next column in measure.
                        //See if previous note on this channel had Tie set. If so, stop the sound briefly before continuing.
                        if (noTieCh1)
                        {
                            writer.Write((byte)0x1D);    //Select AY1
                            writer.Write((byte)1);
                            writer.Write((byte)0x08);    //ChA amplitude
                            writer.Write((byte)0x00);
                        }
                        if (noTieCh2)
                        {
                            writer.Write((byte)0x1D);    //Select AY1
                            writer.Write((byte)1);
                            writer.Write((byte)0x09);    //ChB amplitude
                            writer.Write((byte)0x00);
                        }
                        if (noTieCh3)
                        {
                            writer.Write((byte)0x1D);    //Select AY1
                            writer.Write((byte)1);
                            writer.Write((byte)0x0A);    //ChC amplitude
                            writer.Write((byte)0x00);
                        }
                        if (noTieCh4)
                        {
                            writer.Write((byte)0x1D);    //Select AY3
                            writer.Write((byte)3);
                            writer.Write((byte)0x08);    //ChA amplitude
                            writer.Write((byte)0x00);
                        }
                        if (noTieCh5)
                        {
                            writer.Write((byte)0x1D);    //Select AY3
                            writer.Write((byte)3);
                            writer.Write((byte)0x09);    //ChB amplitude
                            writer.Write((byte)0x00);
                        }
                        if (noTieCh6)
                        {
                            writer.Write((byte)0x1D);    //Select AY3
                            writer.Write((byte)3);
                            writer.Write((byte)0x0A);    //ChC amplitude
                            writer.Write((byte)0x00);
                        }
                        writer.Write((byte)0x11);   //Delay (hold note) (using ASCII device control 1)
                        writer.Write((byte)0);      //1=normal tick, 2=half, 3=quarter, 0=minimal for note ups

                        writer.Write((byte)0x1F);

                    }

                }

                //to do: write out 0x1E at end of measure? - not needed right now


                if (i == songDataTable.Rows.Count - 1)  //last row
                {
                    //Use "FF" to mark end
                    //writer.Write((byte)255);
                    
                    //Use 0x1C to mark end of file
                    writer.Write((byte)0x1C);
                }
            }
            exportForm exF = new exportForm();

            exF.bytes = stream.ToArray();
            string tmp = BitConverter.ToString(exF.bytes);
            exF.assemblyRichText.Text = Regex.Replace(tmp, "(.{48})", "$1\n");      //insert new line every 16 bytes for easy reading
            exF.Show(this);

        }
    
        Int16 getToneCourse(string note, Int16 octave)
        {
            foreach(NoteTones ntX in nt)
            {
                if (ntX.Note == note && ntX.Octave == octave)
                {
                    return ntX.Course;
                }
            }
            return 0;
        }
        Int16 getToneFine(string note, Int16 octave)
        {
            foreach (NoteTones ntX in nt)
            {
                if (ntX.Note == note && ntX.Octave == octave)
                {
                    return ntX.Fine;
                }
            }
            return 0;
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            songDataTable.Clear();
            bindingSource1.AddNew();
        }

        private void saveMeasureButton_Click(object sender, EventArgs e)
        {
            bindingSource1.EndEdit();
        }
    }
}
