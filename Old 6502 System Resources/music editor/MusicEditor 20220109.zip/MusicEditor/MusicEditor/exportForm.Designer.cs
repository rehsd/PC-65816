﻿namespace MusicEditor
{
    partial class exportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveButton = new System.Windows.Forms.Button();
            this.assemblyRichText = new System.Windows.Forms.RichTextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(24, 22);
            this.saveButton.Margin = new System.Windows.Forms.Padding(2);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(312, 72);
            this.saveButton.TabIndex = 3;
            this.saveButton.Text = "&Save as ROM Image";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // assemblyRichText
            // 
            this.assemblyRichText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.assemblyRichText.Location = new System.Drawing.Point(24, 115);
            this.assemblyRichText.Margin = new System.Windows.Forms.Padding(2);
            this.assemblyRichText.Name = "assemblyRichText";
            this.assemblyRichText.Size = new System.Drawing.Size(1329, 741);
            this.assemblyRichText.TabIndex = 2;
            this.assemblyRichText.Text = "";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "mrom";
            this.saveFileDialog1.FileName = "MyMusic.mrom";
            // 
            // exportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1381, 879);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.assemblyRichText);
            this.Name = "exportForm";
            this.Text = "Binary Storage";
            this.Load += new System.EventHandler(this.exportForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button saveButton;
        public System.Windows.Forms.RichTextBox assemblyRichText;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}