﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MusicEditor
{
    public partial class exportForm : Form
    {

        public byte[] bytes;

        public exportForm()
        {
            InitializeComponent();
        }

        private void exportForm_Load(object sender, EventArgs e)
        {

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = saveFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                //byte[] bytes = Encoding.ASCII.GetBytes(assemblyRichText.Text);
                System.IO.FileStream fs = new System.IO.FileStream(saveFileDialog1.FileName, System.IO.FileMode.Create);
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
            }
        }
    }
}
