﻿namespace PureMidi.CoreMmSystem.MidiIO.Definitions
{
    public enum EMidiEventType
    {
        Empty,
        Short,
        Sysex,
        Meta
    }
}