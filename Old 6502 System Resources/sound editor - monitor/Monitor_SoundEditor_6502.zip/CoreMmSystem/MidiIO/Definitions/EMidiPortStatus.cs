﻿namespace PureMidi.CoreMmSystem.MidiIO.Definitions
{
    public enum EMidiPortStatus
    {
        Uninitialised,
        Closed,
        Opened,
        Error
    }
}