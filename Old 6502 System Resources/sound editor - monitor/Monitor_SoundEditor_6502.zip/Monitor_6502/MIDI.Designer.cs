﻿
namespace Monitor_6502
{
    partial class MIDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputDevicesComboBox = new System.Windows.Forms.ComboBox();
            this.outputDevicesComboBox = new System.Windows.Forms.ComboBox();
            this.openButton = new System.Windows.Forms.Button();
            this.eventsListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // inputDevicesComboBox
            // 
            this.inputDevicesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.inputDevicesComboBox.FormattingEnabled = true;
            this.inputDevicesComboBox.Location = new System.Drawing.Point(14, 10);
            this.inputDevicesComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.inputDevicesComboBox.Name = "inputDevicesComboBox";
            this.inputDevicesComboBox.Size = new System.Drawing.Size(84, 21);
            this.inputDevicesComboBox.TabIndex = 0;
            // 
            // outputDevicesComboBox
            // 
            this.outputDevicesComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.outputDevicesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.outputDevicesComboBox.FormattingEnabled = true;
            this.outputDevicesComboBox.Location = new System.Drawing.Point(99, 10);
            this.outputDevicesComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.outputDevicesComboBox.Name = "outputDevicesComboBox";
            this.outputDevicesComboBox.Size = new System.Drawing.Size(110, 21);
            this.outputDevicesComboBox.TabIndex = 1;
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(219, 7);
            this.openButton.Margin = new System.Windows.Forms.Padding(2);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(60, 27);
            this.openButton.TabIndex = 2;
            this.openButton.Text = "&Open";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // eventsListBox
            // 
            this.eventsListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.eventsListBox.FormattingEnabled = true;
            this.eventsListBox.Location = new System.Drawing.Point(14, 37);
            this.eventsListBox.Margin = new System.Windows.Forms.Padding(2);
            this.eventsListBox.Name = "eventsListBox";
            this.eventsListBox.Size = new System.Drawing.Size(266, 173);
            this.eventsListBox.TabIndex = 3;
            // 
            // MIDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 215);
            this.Controls.Add(this.eventsListBox);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.outputDevicesComboBox);
            this.Controls.Add(this.inputDevicesComboBox);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MIDI";
            this.Text = "MIDI";
            this.Load += new System.EventHandler(this.MIDI_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox inputDevicesComboBox;
        private System.Windows.Forms.ComboBox outputDevicesComboBox;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.ListBox eventsListBox;
    }
}