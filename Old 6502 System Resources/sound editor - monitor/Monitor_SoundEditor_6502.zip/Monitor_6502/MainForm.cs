﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Configuration;
using System.Management;

namespace Monitor_6502
{
    public partial class mainForm : Form
    {
        const Int16 PIXELSIZE = 4;
        const int PIXELSTART_X = 20;
        const int PIXELSTART_Y = 70;

        SerialPort myPort;
        //const int CONNECTION_RATE = 115200;
        const int CONNECTION_RATE = 345600;

        int totalBytesReceived = 0;
        int x_current=0;
        int y_current=0;

        void PopulateSerialPorts()
        {
            try
            {
                ManagementObjectCollection mbsList = null;
                ManagementObjectSearcher mbs = new ManagementObjectSearcher("Select DeviceID, Description From Win32_SerialPort");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                }

                mbs = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM%' AND Name LIKE '%USB%'");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["Name"].ToString() + ": " + mo["Description"].ToString());
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        public mainForm()
        {
            InitializeComponent();
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (Int16 y = 0; y < 64; y++)
            {
                for (Int16 x = 0; x < 100; x++)
                {
                    //Int16 receivedColor = 0;
                    //SolidBrush sb = new SolidBrush(ConvertColor(receivedColor));
                    SolidBrush sb = new SolidBrush(Color.Black);
                    Graphics g = this.CreateGraphics();
                    g.FillRectangle(sb, PIXELSTART_X + x * PIXELSIZE, PIXELSTART_Y + y * PIXELSIZE, PIXELSIZE, PIXELSIZE);
                }
            }

        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateSerialPorts();
                this.Width = 460;
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void ConnectButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButton.Text == "&Connect")
                {
                    string s = PortsCombo.SelectedItem.ToString();
                    s = s.Substring(s.IndexOf("COM"),4);
                    myPort = new SerialPort(s, CONNECTION_RATE);
                    myPort.ReadTimeout = 5000;
                    myPort.WriteTimeout = 5000;
                    myPort.Open();
                    connectionStatusPictureBox.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPort.DataReceived += new SerialDataReceivedEventHandler(MyPort_DataReceived);
                    myPort.DiscardInBuffer();
                    connectionSpeedLabel.Text = s + " @ " + myPort.BaudRate.ToString();
                    myPort.DiscardInBuffer();
                    ConnectButton.Text = "&Disconnect";
                }
                else
                {
                    if (myPort.IsOpen)
                    {
                        myPort.Close();
                    }
                    connectionStatusPictureBox.BackColor = Color.Red;
                    ConnectButton.Text = "&Connect";
                    connectionSpeedLabel.Text = "";
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        totalBytesReceived++;
                        //if (totalBytesReceived < 2)    //need to figure out what this extra garbage at the beginning is -- some from old data in the buffer, now clearing on connection
                        //{
                        //    myPort.ReadByte();
                        //    return;
                        //}
                        int red, green, blue;

                        Byte inByte = (Byte)myPort.ReadByte();
                        if (showDebugToolStripMenuItem.Checked)
                        {
                            OutputRichtext.Text += inByte.ToString() + " ";
                        }

                        if (x_current < 0 || x_current >96)
                        {
                            red = 240;
                            green = 240;
                            blue = 240;
                        }
                        else
                        {
                            red = inByte & 3;      //00000011
                            green = inByte & 12;    //00001100
                            green = green >> 2;
                            blue = inByte & 48;    //00110000
                            blue = blue >> 4;
                            red *= 85;
                            blue *= 85;
                            green *= 85;
                            if (red > 255) { red = 255; }       //likely not necessary
                            if (blue > 255) { blue = 255; }     //likely not necessary
                            if (green > 255) { green = 255; }   //likely not necessary
                        }

                        SolidBrush sb = new SolidBrush(Color.FromArgb(red,green,blue));
                        Graphics g = this.CreateGraphics();
                        g.FillRectangle(sb, PIXELSTART_X + x_current * PIXELSIZE, PIXELSTART_Y + y_current * PIXELSIZE, PIXELSIZE, PIXELSIZE);
                        x_current++;
                        if(x_current==98)
                        {
                            y_current++;
                            x_current = 0;
                            if(y_current==64)
                            {
                                y_current = 0;
                                //**stop processing sceen image
                            }
                        }

                    }));
                }
                else
                {
                    //
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void mainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (myPort != null && myPort.IsOpen)
                {
                    myPort.Close();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }


        }


        private void PortsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButton.Enabled = true;

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (Int16 y = 0; y < 64; y++)
            {
                for (Int16 x = 0; x < 100; x++)
                {
                    SolidBrush sb = new SolidBrush(DefaultBackColor);
                    Graphics g = this.CreateGraphics();
                    g.FillRectangle(sb, PIXELSTART_X + x * PIXELSIZE, PIXELSTART_Y + y * PIXELSIZE, PIXELSIZE, PIXELSIZE);
                }
            }
            x_current = 0;
            y_current = 0;
            totalBytesReceived = 0;
            myPort.DiscardInBuffer();
        }

        private void showDebugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)sender;
            m.Checked = !m.Checked;
            if(m.Checked)
            {
                this.Width = 735;
            }
            else
            {
                this.Width = 460;
            }
        }

        private void editorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SoundForm sf = new SoundForm();
            sf.Show(this);
        }
    }

}
