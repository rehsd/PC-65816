﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Configuration;
using System.Management;
using System.Text.RegularExpressions;

namespace Monitor_6502
{
    public partial class SoundForm : Form
    {
        SerialPort myPort;
        // const int CONNECTION_RATE = 115200;
        //const int CONNECTION_RATE = 230400;
        //const int CONNECTION_RATE = 503316480;     // 460 Mbps * 1024 kbps * 1024 bps
        const int CONNECTION_RATE = 268435456;     // 256 Mbps * 1024 kbps * 1024 bps
        //int DELAY_SMALLEST_UNIT = 1;        // Adjust based on your system's performance (serial, SPI, etc.) ...
        bool stop = false;

        void PopulateSerialPorts()
        {
            PortsCombo.Items.Clear();
            try
            {
                ManagementObjectCollection mbsList = null;
                ManagementObjectSearcher mbs = new ManagementObjectSearcher("Select DeviceID, Description From Win32_SerialPort");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                }

                mbs = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM%' AND Name LIKE '%USB%'");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["Name"].ToString() + ": " + mo["Description"].ToString());
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        public SoundForm()
        {
            InitializeComponent();
        }


        private void ConnectButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButton.Text == "&Connect")
                {
                    string s = PortsCombo.SelectedItem.ToString();
                    s = s.Substring(s.IndexOf("COM"), 5);
                    //if(s.Substring(s.Length-1))
                    myPort = new SerialPort(s, CONNECTION_RATE);
                    myPort.ReadTimeout = 5000;
                    myPort.WriteTimeout = 5000;
                    myPort.Open();
                    connectionStatusPictureBox.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPort.DataReceived += new SerialDataReceivedEventHandler(MyPort_DataReceived);
                    myPort.DiscardInBuffer();
                    connectionSpeedLabel.Text = s + " @ " + myPort.BaudRate.ToString() + " bps";
                    myPort.DiscardInBuffer();
                    ConnectButton.Text = "&Disconnect";
                    nudTonePeriodCourseLA.Focus();
                    startButton.Enabled = false;
                    stopButton.Enabled = false;
                    enableUpdateButtonTimer.Enabled = true;
                    pbConnect.Value = 0;
                    pbConnect.Maximum = enableUpdateButtonTimer.Interval;
                    pbConnect.Visible = true;
                    progressBarTimer.Enabled = true;
                }
                else
                {
                    if (myPort.IsOpen)
                    {
                        myPort.Close();
                    }
                    connectionStatusPictureBox.BackColor = Color.Red;
                    ConnectButton.Text = "&Connect";
                    connectionSpeedLabel.Text = "";
                    startButton.Enabled = false;
                    stopButton.Enabled = false;
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void SoundForm_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateSerialPorts();
                //this.Width = 980;
                nudTonePeriodCourseLA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodFineLA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudVolumeLA.Enter += new EventHandler(nud_Enter);
                nudVolumeLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLB.Enter += new EventHandler(nud_Enter);
                nudVolumeLB.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLC.Enter += new EventHandler(nud_Enter);
                nudVolumeLC.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLD.Enter += new EventHandler(nud_Enter);
                nudVolumeLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLE.Enter += new EventHandler(nud_Enter);
                nudVolumeLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLF.Enter += new EventHandler(nud_Enter);
                nudVolumeLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodCourseRA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodFineRA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudVolumeRA.Enter += new EventHandler(nud_Enter);
                nudVolumeRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRB.Enter += new EventHandler(nud_Enter);
                nudVolumeRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRC.Enter += new EventHandler(nud_Enter);
                nudVolumeRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRD.Enter += new EventHandler(nud_Enter);
                nudVolumeRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRE.Enter += new EventHandler(nud_Enter);
                nudVolumeRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRF.Enter += new EventHandler(nud_Enter);
                nudVolumeRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudNoisePeriodL1.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodL1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseL1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseL1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineL1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineL1.MouseClick += new MouseEventHandler(nud_Enter);

                cboVolFixedVarLA.SelectedIndex = 0;
                cboVolFixedVarLB.SelectedIndex = 0;
                cboVolFixedVarLC.SelectedIndex = 0;
                cboVolFixedVarLD.SelectedIndex = 0;
                cboVolFixedVarLE.SelectedIndex = 0;
                cboVolFixedVarLF.SelectedIndex = 0;

                cboVolFixedVarRA.SelectedIndex = 0;
                cboVolFixedVarRB.SelectedIndex = 0;
                cboVolFixedVarRC.SelectedIndex = 0;
                cboVolFixedVarRD.SelectedIndex = 0;
                cboVolFixedVarRE.SelectedIndex = 0;
                cboVolFixedVarRF.SelectedIndex = 0;


                nudNoisePeriodR1.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR1.MouseClick += new MouseEventHandler(nud_Enter);
                nudNoisePeriodL2.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR2.MouseClick += new MouseEventHandler(nud_Enter);
                nudNoisePeriodR2.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseR1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseR1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineR1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineR1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseL2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseL2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineL2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineL2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseR2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseR2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineR2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineR2.MouseClick += new MouseEventHandler(nud_Enter);

                chkHex.Checked = true;

                foreach (DataGridViewColumn col in dgvSequence.Columns)
                {
                    col.Width = 30;
                    col.SortMode = DataGridViewColumnSortMode.NotSortable;
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        Byte inByte = (Byte)myPort.ReadByte();

                        //do something here...

                    }));
                }
                else
                {
                    //
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void PortsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButton.Enabled = true;

        }

        private void SoundForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (myPort != null && myPort.IsOpen)
                {
                    myPort.Close();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (!myPort.IsOpen)
            {
                MessageBox.Show("Port not open!");
                return;
            }
            //raise interrupt on VIA4 CB1
            //start trigger by sending serial data to Nano
            //Nano will then pull CB1 low

            Byte envelopeShapeCycleL1 = 0;
            if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
            if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
            if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
            if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

            Byte envelopeShapeCycleR1 = 0;
            if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
            if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
            if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
            if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

            Byte envelopeShapeCycleL2 = 0;
            if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
            if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
            if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
            if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

            Byte envelopeShapeCycleR2 = 0;
            if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
            if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
            if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
            if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }

            Byte enableLeft1 = 0;
            Byte enableLeft2 = 0;
            Byte enableRight1 = 0;
            Byte enableRight2 = 0;

            //AY1
            if (!toneLA.Checked) { enableLeft1 |= 1; }
            if (!toneLB.Checked) { enableLeft1 |= 2; }
            if (!toneLC.Checked) { enableLeft1 |= 4; }
            if (!noiseLA.Checked) { enableLeft1 |= 8; }
            if (!noiseLB.Checked) { enableLeft1 |= 16; }
            if (!noiseLC.Checked) { enableLeft1 |= 32; }

            //AY2
            if (!toneRA.Checked) { enableRight1 |= 1; }
            if (!toneRB.Checked) { enableRight1 |= 2; }
            if (!toneRC.Checked) { enableRight1 |= 4; }
            if (!noiseRA.Checked) { enableRight1 |= 8; }
            if (!noiseRB.Checked) { enableRight1 |= 16; }
            if (!noiseRC.Checked) { enableRight1 |= 32; }

            //AY3
            if (!toneLD.Checked) { enableLeft2 |= 1; }
            if (!toneLE.Checked) { enableLeft2 |= 2; }
            if (!toneLF.Checked) { enableLeft2 |= 4; }
            if (!noiseLD.Checked) { enableLeft2 |= 8; }
            if (!noiseLE.Checked) { enableLeft2 |= 16; }
            if (!noiseLF.Checked) { enableLeft2 |= 32; }

            //AY4
            if (!toneRD.Checked) { enableRight2 |= 1; }
            if (!toneRE.Checked) { enableRight2 |= 2; }
            if (!toneRF.Checked) { enableRight2 |= 4; }
            if (!noiseRD.Checked) { enableRight2 |= 8; }
            if (!noiseRE.Checked) { enableRight2 |= 16; }
            if (!noiseRF.Checked) { enableRight2 |= 32; }

            byte[] buffer = new byte[60];

            buffer[0] = (byte)'C';
            buffer[1] = (byte)'B';
            buffer[2] = (byte)'1';
            buffer[3] = (byte)':';
            buffer[4] = (byte)nudTonePeriodCourseLA.Value;
            buffer[5] = (byte)nudTonePeriodCourseLB.Value;
            buffer[6] = (byte)nudTonePeriodCourseLC.Value;
            buffer[7] = (byte)nudTonePeriodCourseLD.Value;
            buffer[8] = (byte)nudTonePeriodCourseLE.Value;
            buffer[9] = (byte)nudTonePeriodCourseLF.Value;
            buffer[10] = (byte)nudTonePeriodFineLA.Value;
            buffer[11] = (byte)nudTonePeriodFineLB.Value;
            buffer[12] = (byte)nudTonePeriodFineLC.Value;
            buffer[13] = (byte)nudTonePeriodFineLD.Value;
            buffer[14] = (byte)nudTonePeriodFineLE.Value;
            buffer[15] = (byte)nudTonePeriodFineLF.Value;
            buffer[16] = (byte)((byte)nudVolumeLA.Value | (byte)cboVolFixedVarLA.SelectedIndex << 4);
            buffer[17] = (byte)((byte)nudVolumeLB.Value | (byte)cboVolFixedVarLB.SelectedIndex << 4);
            buffer[18] = (byte)((byte)nudVolumeLC.Value | (byte)cboVolFixedVarLC.SelectedIndex << 4);
            buffer[19] = (byte)((byte)nudVolumeLD.Value | (byte)cboVolFixedVarLD.SelectedIndex << 4);
            buffer[20] = (byte)((byte)nudVolumeLE.Value | (byte)cboVolFixedVarLE.SelectedIndex << 4);
            buffer[21] = (byte)((byte)nudVolumeLF.Value | (byte)cboVolFixedVarLF.SelectedIndex << 4);
            buffer[22] = (byte)nudTonePeriodCourseRA.Value;
            buffer[23] = (byte)nudTonePeriodCourseRB.Value;
            buffer[24] = (byte)nudTonePeriodCourseRC.Value;
            buffer[25] = (byte)nudTonePeriodCourseRD.Value;
            buffer[26] = (byte)nudTonePeriodCourseRE.Value;
            buffer[27] = (byte)nudTonePeriodCourseRF.Value;
            buffer[28] = (byte)nudTonePeriodFineRA.Value;
            buffer[29] = (byte)nudTonePeriodFineRB.Value;
            buffer[30] = (byte)nudTonePeriodFineRC.Value;
            buffer[31] = (byte)nudTonePeriodFineRD.Value;
            buffer[32] = (byte)nudTonePeriodFineRE.Value;
            buffer[33] = (byte)nudTonePeriodFineRF.Value;
            buffer[34] = (byte)((byte)nudVolumeRA.Value | (byte)cboVolFixedVarRA.SelectedIndex << 4);
            buffer[35] = (byte)((byte)nudVolumeRB.Value | (byte)cboVolFixedVarRB.SelectedIndex << 4);
            buffer[36] = (byte)((byte)nudVolumeRC.Value | (byte)cboVolFixedVarRC.SelectedIndex << 4);
            buffer[37] = (byte)((byte)nudVolumeRD.Value | (byte)cboVolFixedVarRD.SelectedIndex << 4);
            buffer[38] = (byte)((byte)nudVolumeRE.Value | (byte)cboVolFixedVarRE.SelectedIndex << 4);
            buffer[39] = (byte)((byte)nudVolumeRF.Value | (byte)cboVolFixedVarRF.SelectedIndex << 4);
            buffer[40] = (byte)nudNoisePeriodL1.Value;
            buffer[41] = (byte)nudEnvelopePeriodCourseL1.Value;
            buffer[42] = (byte)nudEnvelopePeriodFineL1.Value;
            buffer[43] = envelopeShapeCycleL1;
            buffer[44] = enableLeft1;
            buffer[45] = enableRight1;
            buffer[46] = enableLeft2;
            buffer[47] = enableRight2;
            //added:
            buffer[48] = (byte)nudNoisePeriodR1.Value;
            buffer[49] = (byte)nudEnvelopePeriodCourseR1.Value;
            buffer[50] = (byte)nudEnvelopePeriodFineR1.Value;
            buffer[51] = envelopeShapeCycleR1;
            buffer[52] = (byte)nudNoisePeriodL2.Value;
            buffer[53] = (byte)nudEnvelopePeriodCourseL2.Value;
            buffer[54] = (byte)nudEnvelopePeriodFineL2.Value;
            buffer[55] = envelopeShapeCycleL2;
            buffer[56] = (byte)nudNoisePeriodR2.Value;
            buffer[57] = (byte)nudEnvelopePeriodCourseR2.Value;
            buffer[58] = (byte)nudEnvelopePeriodFineR2.Value;
            buffer[59] = envelopeShapeCycleR2;


            myPort.Encoding = Encoding.UTF8;
            myPort.Write(buffer, 0, buffer.Length);
            //MessageBox.Show("request sent to Nano...");
        }


        private void stopButton_Click(object sender, EventArgs e)
        {
            if (!myPort.IsOpen)
            {
                MessageBox.Show("Port not open!");
                return;
            }

            //raise interrupt on VIA4 CB1
            //start trigger by sending serial data to Nano
            //Nano will then pull CB1 low

            Byte envelopeShapeCycleL1 = 0;
            if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
            if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
            if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
            if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

            Byte envelopeShapeCycleR1 = 0;
            if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
            if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
            if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
            if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

            Byte envelopeShapeCycleL2 = 0;
            if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
            if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
            if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
            if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

            Byte envelopeShapeCycleR2 = 0;
            if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
            if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
            if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
            if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }


            Byte enableLeft1 = 0;
            Byte enableLeft2 = 0;
            Byte enableRight1 = 0;
            Byte enableRight2 = 0;

            if (!toneLA.Checked) { enableLeft1 |= 1; }
            if (!toneLB.Checked) { enableLeft1 |= 2; }
            if (!toneLC.Checked) { enableLeft1 |= 4; }
            if (!noiseLA.Checked) { enableLeft1 |= 8; }
            if (!noiseLB.Checked) { enableLeft1 |= 16; }
            if (!noiseLC.Checked) { enableLeft1 |= 32; }

            if (!toneRA.Checked) { enableRight1 |= 1; }
            if (!toneRB.Checked) { enableLeft1 |= 2; }
            if (!toneRC.Checked) { enableRight1 |= 4; }
            if (!noiseRA.Checked) { enableRight1 |= 8; }
            if (!noiseRB.Checked) { enableRight1 |= 16; }
            if (!noiseRC.Checked) { enableRight1 |= 32; }

            if (!toneLD.Checked) { enableLeft2 |= 1; }
            if (!toneLE.Checked) { enableLeft2 |= 2; }
            if (!toneLF.Checked) { enableLeft2 |= 4; }
            if (!noiseLD.Checked) { enableLeft2 |= 8; }
            if (!noiseLE.Checked) { enableLeft2 |= 16; }
            if (!noiseLF.Checked) { enableLeft2 |= 32; }

            if (!toneRD.Checked) { enableRight2 |= 1; }
            if (!toneRE.Checked) { enableLeft2 |= 2; }
            if (!toneRE.Checked) { enableRight2 |= 4; }
            if (!noiseRD.Checked) { enableRight2 |= 8; }
            if (!noiseRE.Checked) { enableRight2 |= 16; }
            if (!noiseRF.Checked) { enableRight2 |= 32; }

            byte[] buffer = new byte[60];

            buffer[0] = (byte)'C';
            buffer[1] = (byte)'B';
            buffer[2] = (byte)'1';
            buffer[3] = (byte)':';
            buffer[4] = (byte)nudTonePeriodCourseLA.Value;
            buffer[5] = (byte)nudTonePeriodCourseLB.Value;
            buffer[6] = (byte)nudTonePeriodCourseLC.Value;
            buffer[7] = (byte)nudTonePeriodCourseLD.Value;
            buffer[8] = (byte)nudTonePeriodCourseLE.Value;
            buffer[9] = (byte)nudTonePeriodCourseLF.Value;
            buffer[10] = (byte)nudTonePeriodFineLA.Value;
            buffer[11] = (byte)nudTonePeriodFineLB.Value;
            buffer[12] = (byte)nudTonePeriodFineLC.Value;
            buffer[13] = (byte)nudTonePeriodFineLD.Value;
            buffer[14] = (byte)nudTonePeriodFineLE.Value;
            buffer[15] = (byte)nudTonePeriodFineLF.Value;
            buffer[16] = (byte)0;       //volumes to zero
            buffer[17] = (byte)0;
            buffer[18] = (byte)0;
            buffer[19] = (byte)0;
            buffer[20] = (byte)0;
            buffer[21] = (byte)0;
            buffer[22] = (byte)nudTonePeriodCourseRA.Value;
            buffer[23] = (byte)nudTonePeriodCourseRB.Value;
            buffer[24] = (byte)nudTonePeriodCourseRC.Value;
            buffer[25] = (byte)nudTonePeriodCourseRD.Value;
            buffer[26] = (byte)nudTonePeriodCourseRE.Value;
            buffer[27] = (byte)nudTonePeriodCourseRF.Value;
            buffer[28] = (byte)nudTonePeriodFineRA.Value;
            buffer[29] = (byte)nudTonePeriodFineRB.Value;
            buffer[30] = (byte)nudTonePeriodFineRC.Value;
            buffer[31] = (byte)nudTonePeriodFineRD.Value;
            buffer[32] = (byte)nudTonePeriodFineRE.Value;
            buffer[33] = (byte)nudTonePeriodFineRF.Value;
            buffer[34] = (byte)0;       //volume to zero
            buffer[35] = (byte)0;
            buffer[36] = (byte)0;
            buffer[37] = (byte)0;
            buffer[38] = (byte)0;
            buffer[39] = (byte)0;
            buffer[40] = (byte)nudNoisePeriodL1.Value;
            buffer[41] = (byte)nudEnvelopePeriodCourseL1.Value;
            buffer[42] = (byte)nudEnvelopePeriodFineL1.Value;
            buffer[43] = envelopeShapeCycleL1;
            buffer[44] = enableLeft1;
            buffer[45] = enableRight1;
            buffer[46] = enableLeft2;
            buffer[47] = enableRight2;

            //added:
            buffer[48] = (byte)nudNoisePeriodR1.Value;
            buffer[49] = (byte)nudEnvelopePeriodCourseR1.Value;
            buffer[50] = (byte)nudEnvelopePeriodFineR1.Value;
            buffer[51] = envelopeShapeCycleR1;
            buffer[52] = (byte)nudNoisePeriodL2.Value;
            buffer[53] = (byte)nudEnvelopePeriodCourseL2.Value;
            buffer[54] = (byte)nudEnvelopePeriodFineL2.Value;
            buffer[55] = envelopeShapeCycleL2;
            buffer[56] = (byte)nudNoisePeriodR2.Value;
            buffer[57] = (byte)nudEnvelopePeriodCourseR2.Value;
            buffer[58] = (byte)nudEnvelopePeriodFineR2.Value;
            buffer[59] = envelopeShapeCycleR2;

            myPort.Encoding = Encoding.UTF8;
            myPort.Write(buffer, 0, buffer.Length);
        }

        void SendSequence(int rowNumber)
        {
            if (!myPort.IsOpen)
            {
                MessageBox.Show("Port not open!");
                return;
            }

            if (rowNumber < dataTable1.Rows.Count)
            {
                byte[] buffer = new byte[60];
                for (int i = 0; i < 60; i++)
                {
                    buffer[i] = (byte)dataTable1.Rows[rowNumber][i];
                }

                myPort.Encoding = Encoding.UTF8;
                myPort.Write(buffer, 0, buffer.Length);

                //System.Threading.Thread.Sleep(DELAY_SMALLEST_UNIT * Int32.Parse(dataTable1.Rows[rowNumber][60].ToString()));    //can't send data too quickly with serial :)
                System.Threading.Thread.Sleep((int)nudTimeBase.Value * Int32.Parse(dataTable1.Rows[rowNumber][60].ToString()));    //can't send data too quickly with serial :)
            }
        }

        private void nud_Enter(object sender, EventArgs e)
        {
            NumericUpDown nud = sender as NumericUpDown;
            nud.Select();
            nud.Select(0, nud.Text.Length);
        }

        private void enableUpdateButtonTimer_Tick(object sender, EventArgs e)
        {
            startButton.Enabled = true;
            stopButton.Enabled = true;
            enableUpdateButtonTimer.Enabled = false;
            progressBarTimer.Enabled = false;
            pbConnect.Visible = false;

        }

        private void chkHex_CheckedChanged(object sender, EventArgs e)
        {
            nudTonePeriodCourseLA.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseLB.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseLC.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseLD.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseLE.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseLF.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLA.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLB.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLC.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLD.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLE.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineLF.Hexadecimal = chkHex.Checked;
            nudVolumeLA.Hexadecimal = chkHex.Checked;
            nudVolumeLB.Hexadecimal = chkHex.Checked;
            nudVolumeLC.Hexadecimal = chkHex.Checked;
            nudVolumeLD.Hexadecimal = chkHex.Checked;
            nudVolumeLE.Hexadecimal = chkHex.Checked;
            nudVolumeLF.Hexadecimal = chkHex.Checked;
            nudNoisePeriodL1.Hexadecimal = chkHex.Checked;
            nudNoisePeriodL2.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodCourseL1.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodCourseL2.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodFineL1.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodFineL2.Hexadecimal = chkHex.Checked;

            nudTonePeriodCourseRA.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseRB.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseRC.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseRD.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseRE.Hexadecimal = chkHex.Checked;
            nudTonePeriodCourseRF.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRA.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRB.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRC.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRD.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRE.Hexadecimal = chkHex.Checked;
            nudTonePeriodFineRF.Hexadecimal = chkHex.Checked;
            nudVolumeRA.Hexadecimal = chkHex.Checked;
            nudVolumeRB.Hexadecimal = chkHex.Checked;
            nudVolumeRC.Hexadecimal = chkHex.Checked;
            nudVolumeRD.Hexadecimal = chkHex.Checked;
            nudVolumeRE.Hexadecimal = chkHex.Checked;
            nudVolumeRF.Hexadecimal = chkHex.Checked;
            nudNoisePeriodR1.Hexadecimal = chkHex.Checked;
            nudNoisePeriodR2.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodCourseR1.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodCourseR2.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodFineR1.Hexadecimal = chkHex.Checked;
            nudEnvelopePeriodFineR2.Hexadecimal = chkHex.Checked;
        }

        private void AddToSequenceButton_Click(object sender, EventArgs e)
        {
            DataRow row = SequenceDataSet.Tables[0].NewRow();

            Byte envelopeShapeCycleL1 = 0;
            if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
            if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
            if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
            if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

            Byte envelopeShapeCycleR1 = 0;
            if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
            if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
            if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
            if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

            Byte envelopeShapeCycleL2 = 0;
            if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
            if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
            if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
            if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

            Byte envelopeShapeCycleR2 = 0;
            if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
            if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
            if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
            if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }

            Byte enableLeft1 = 0;
            Byte enableLeft2 = 0;
            Byte enableRight1 = 0;
            Byte enableRight2 = 0;

            //AY1
            if (!toneLA.Checked) { enableLeft1 |= 1; }
            if (!toneLB.Checked) { enableLeft1 |= 2; }
            if (!toneLC.Checked) { enableLeft1 |= 4; }
            if (!noiseLA.Checked) { enableLeft1 |= 8; }
            if (!noiseLB.Checked) { enableLeft1 |= 16; }
            if (!noiseLC.Checked) { enableLeft1 |= 32; }
            enableLeft1 |= 64;      //A port out on PSG     //doing reading with AY1 -- only one PSG (per common ROM) should ever be active for port output at a time

            //AY2
            if (!toneRA.Checked) { enableRight1 |= 1; }
            if (!toneRB.Checked) { enableRight1 |= 2; }
            if (!toneRC.Checked) { enableRight1 |= 4; }
            if (!noiseRA.Checked) { enableRight1 |= 8; }
            if (!noiseRB.Checked) { enableRight1 |= 16; }
            if (!noiseRC.Checked) { enableRight1 |= 32; }

            //AY3
            if (!toneLD.Checked) { enableLeft2 |= 1; }
            if (!toneLE.Checked) { enableLeft2 |= 2; }
            if (!toneLF.Checked) { enableLeft2 |= 4; }
            if (!noiseLD.Checked) { enableLeft2 |= 8; }
            if (!noiseLE.Checked) { enableLeft2 |= 16; }
            if (!noiseLF.Checked) { enableLeft2 |= 32; }
            enableLeft2 |= 64;      //A port out on PSG     //doing reading with AY1 -- only one PSG (per common ROM) should ever be active for port output at a time

            //AY4
            if (!toneRD.Checked) { enableRight2 |= 1; }
            if (!toneRE.Checked) { enableRight2 |= 2; }
            if (!toneRF.Checked) { enableRight2 |= 4; }
            if (!noiseRD.Checked) { enableRight2 |= 8; }
            if (!noiseRE.Checked) { enableRight2 |= 16; }
            if (!noiseRF.Checked) { enableRight2 |= 32; }

            //byte[] buffer = new byte[60];

            row[0] = (byte)'C';
            row[1] = (byte)'B';
            row[2] = (byte)'1';
            row[3] = (byte)':';
            row[4] = (byte)nudTonePeriodCourseLA.Value;
            row[5] = (byte)nudTonePeriodCourseLB.Value;
            row[6] = (byte)nudTonePeriodCourseLC.Value;
            row[7] = (byte)nudTonePeriodCourseLD.Value;
            row[8] = (byte)nudTonePeriodCourseLE.Value;
            row[9] = (byte)nudTonePeriodCourseLF.Value;
            row[10] = (byte)nudTonePeriodFineLA.Value;
            row[11] = (byte)nudTonePeriodFineLB.Value;
            row[12] = (byte)nudTonePeriodFineLC.Value;
            row[13] = (byte)nudTonePeriodFineLD.Value;
            row[14] = (byte)nudTonePeriodFineLE.Value;
            row[15] = (byte)nudTonePeriodFineLF.Value;
            row[16] = (byte)((byte)nudVolumeLA.Value | (byte)cboVolFixedVarLA.SelectedIndex << 4);
            row[17] = (byte)((byte)nudVolumeLB.Value | (byte)cboVolFixedVarLB.SelectedIndex << 4);
            row[18] = (byte)((byte)nudVolumeLC.Value | (byte)cboVolFixedVarLC.SelectedIndex << 4);
            row[19] = (byte)((byte)nudVolumeLD.Value | (byte)cboVolFixedVarLD.SelectedIndex << 4);
            row[20] = (byte)((byte)nudVolumeLE.Value | (byte)cboVolFixedVarLE.SelectedIndex << 4);
            row[21] = (byte)((byte)nudVolumeLF.Value | (byte)cboVolFixedVarLF.SelectedIndex << 4);
            row[22] = (byte)nudTonePeriodCourseRA.Value;
            row[23] = (byte)nudTonePeriodCourseRB.Value;
            row[24] = (byte)nudTonePeriodCourseRC.Value;
            row[25] = (byte)nudTonePeriodCourseRD.Value;
            row[26] = (byte)nudTonePeriodCourseRE.Value;
            row[27] = (byte)nudTonePeriodCourseRF.Value;
            row[28] = (byte)nudTonePeriodFineRA.Value;
            row[29] = (byte)nudTonePeriodFineRB.Value;
            row[30] = (byte)nudTonePeriodFineRC.Value;
            row[31] = (byte)nudTonePeriodFineRD.Value;
            row[32] = (byte)nudTonePeriodFineRE.Value;
            row[33] = (byte)nudTonePeriodFineRF.Value;
            row[34] = (byte)((byte)nudVolumeRA.Value | (byte)cboVolFixedVarRA.SelectedIndex << 4);
            row[35] = (byte)((byte)nudVolumeRB.Value | (byte)cboVolFixedVarRB.SelectedIndex << 4);
            row[36] = (byte)((byte)nudVolumeRC.Value | (byte)cboVolFixedVarRC.SelectedIndex << 4);
            row[37] = (byte)((byte)nudVolumeRD.Value | (byte)cboVolFixedVarRD.SelectedIndex << 4);
            row[38] = (byte)((byte)nudVolumeRE.Value | (byte)cboVolFixedVarRE.SelectedIndex << 4);
            row[39] = (byte)((byte)nudVolumeRF.Value | (byte)cboVolFixedVarRF.SelectedIndex << 4);
            row[40] = (byte)nudNoisePeriodL1.Value;
            row[41] = (byte)nudEnvelopePeriodCourseL1.Value;
            row[42] = (byte)nudEnvelopePeriodFineL1.Value;
            row[43] = envelopeShapeCycleL1;
            row[44] = enableLeft1;
            row[45] = enableRight1;
            row[46] = enableLeft2;
            row[47] = enableRight2;
            row[48] = (byte)nudNoisePeriodR1.Value;
            row[49] = (byte)nudEnvelopePeriodCourseR1.Value;
            row[50] = (byte)nudEnvelopePeriodFineR1.Value;
            row[51] = envelopeShapeCycleR1;
            row[52] = (byte)nudNoisePeriodL2.Value;
            row[53] = (byte)nudEnvelopePeriodCourseL2.Value;
            row[54] = (byte)nudEnvelopePeriodFineL2.Value;
            row[55] = envelopeShapeCycleL2;
            row[56] = (byte)nudNoisePeriodR2.Value;
            row[57] = (byte)nudEnvelopePeriodCourseR2.Value;
            row[58] = (byte)nudEnvelopePeriodFineR2.Value;
            row[59] = envelopeShapeCycleR2;
            row[60] = nudDelay.Value;

            dataTable1.Rows.Add(row);
        }

        private void PlayButton_Click(object sender, EventArgs e)
        {
            stop = false;
            for (int i = 0; i < dgvSequence.Rows.Count; i++)
            {
                if (!stop)  //this doesn't work, as Stop button event isn't processed while this loop is running (move this to separate thread?)
                {
                    SendSequence(i);
                    dgvSequence.ClearSelection();
                    dgvSequence.Rows[i].Selected = true;
                    dgvSequence.Refresh();
                }
                else
                {
                    return;
                }
            }
        }

        private void midiButton_Click(object sender, EventArgs e)
        {
            //MIDI m = new MIDI(nudTonePeriodCourseLA, nudTonePeriodFineLA, nudTonePeriodCourseRA, nudTonePeriodFineRA, AddToSequenceButton);
            MIDI m = new MIDI(this);
            m.Show(this);
        }

        public void SafeAddMIDINoteToSequence(int tone, int duration)
        {
            nudTonePeriodCourseLA.Value = ((tone >> 8) & 15);
            nudTonePeriodCourseRA.Value = ((tone >> 8) & 15);
            nudTonePeriodFineLA.Value = (tone & 255);
            nudTonePeriodFineRA.Value = (tone & 255);
            nudDelay.Value = duration;
            AddToSequenceButton.PerformClick();
        }


        private void editRowButton_Click(object sender, EventArgs e)
        {
            DataRow row;
            //bring data from row back into fields
            if (dgvSequence.CurrentRow != null)
            {
                row = dataTable1.Rows[dgvSequence.CurrentRow.Index];
                nudTonePeriodCourseLA.Value = (byte)row[4];
                nudTonePeriodCourseLB.Value = (byte)row[5];
                nudTonePeriodCourseLC.Value = (byte)row[6];
                nudTonePeriodCourseLD.Value = (byte)row[7];
                nudTonePeriodCourseLE.Value = (byte)row[8];
                nudTonePeriodCourseLF.Value = (byte)row[9];
                nudTonePeriodFineLA.Value = (byte)row[10];
                nudTonePeriodFineLB.Value = (byte)row[11];
                nudTonePeriodFineLC.Value = (byte)row[12];
                nudTonePeriodFineLD.Value = (byte)row[13];
                nudTonePeriodFineLE.Value = (byte)row[14];
                nudTonePeriodFineLF.Value = (byte)row[15];
                cboVolFixedVarLA.SelectedIndex = ((byte)row[16] & 16) >> 4;
                nudVolumeLA.Value = (byte)row[16] & 15;
                cboVolFixedVarLB.SelectedIndex = ((byte)row[17] & 16) >> 4;
                nudVolumeLB.Value = (byte)row[17] & 15;
                cboVolFixedVarLC.SelectedIndex = ((byte)row[18] & 16) >> 4;
                nudVolumeLC.Value = (byte)row[18] & 15;
                cboVolFixedVarLD.SelectedIndex = ((byte)row[19] & 16) >> 4;
                nudVolumeLD.Value = (byte)row[19] & 15;
                cboVolFixedVarLE.SelectedIndex = ((byte)row[20] & 16) >> 4;
                nudVolumeLE.Value = (byte)row[20] & 15;
                cboVolFixedVarLF.SelectedIndex = ((byte)row[21] & 16) >> 4;
                nudVolumeLF.Value = (byte)row[21] & 15;
                nudTonePeriodCourseRA.Value = (byte)row[22];
                nudTonePeriodCourseRB.Value = (byte)row[23];
                nudTonePeriodCourseRC.Value = (byte)row[24];
                nudTonePeriodCourseRD.Value = (byte)row[25];
                nudTonePeriodCourseRE.Value = (byte)row[26];
                nudTonePeriodCourseRF.Value = (byte)row[27];
                nudTonePeriodFineRA.Value = (byte)row[28];
                nudTonePeriodFineRB.Value = (byte)row[29];
                nudTonePeriodFineRC.Value = (byte)row[30];
                nudTonePeriodFineRD.Value = (byte)row[31];
                nudTonePeriodFineRE.Value = (byte)row[32];
                nudTonePeriodFineRF.Value = (byte)row[33];
                cboVolFixedVarRA.SelectedIndex = ((byte)row[34] & 16) >> 4;
                nudVolumeRA.Value = (byte)row[34] & 15;
                cboVolFixedVarRB.SelectedIndex = ((byte)row[35] & 16) >> 4;
                nudVolumeRB.Value = (byte)row[35] & 15;
                cboVolFixedVarRC.SelectedIndex = ((byte)row[36] & 16) >> 4;
                nudVolumeRC.Value = (byte)row[36] & 15;
                cboVolFixedVarRD.SelectedIndex = ((byte)row[37] & 16) >> 4;
                nudVolumeRD.Value = (byte)row[37] & 15;
                cboVolFixedVarRE.SelectedIndex = ((byte)row[38] & 16) >> 4;
                nudVolumeRE.Value = (byte)row[38] & 15;
                cboVolFixedVarRF.SelectedIndex = ((byte)row[39] & 16) >> 4;
                nudVolumeRF.Value = (byte)row[39] & 15;
                nudNoisePeriodL1.Value = (byte)row[40];
                nudEnvelopePeriodCourseL1.Value = (byte)row[41];
                nudEnvelopePeriodFineL1.Value = (byte)row[42];
                chkContL1.Checked = Convert.ToBoolean((byte)row[43] & 8);
                chkAttL1.Checked = Convert.ToBoolean((byte)row[43] & 4);
                chkAltL1.Checked = Convert.ToBoolean((byte)row[43] & 2);
                chkHoldL1.Checked = Convert.ToBoolean((byte)row[43] & 1);

                toneLA.Checked = !Convert.ToBoolean((byte)row[44] & 1);
                toneLB.Checked = !Convert.ToBoolean((byte)row[44] & 2);
                toneLC.Checked = !Convert.ToBoolean((byte)row[44] & 4);
                noiseLA.Checked = !Convert.ToBoolean((byte)row[44] & 8);
                noiseLB.Checked = !Convert.ToBoolean((byte)row[44] & 16);
                noiseLC.Checked = !Convert.ToBoolean((byte)row[44] & 32);
                toneRA.Checked = !Convert.ToBoolean((byte)row[45] & 1);
                toneRB.Checked = !Convert.ToBoolean((byte)row[45] & 2);
                toneRC.Checked = !Convert.ToBoolean((byte)row[45] & 4);
                noiseRA.Checked = !Convert.ToBoolean((byte)row[45] & 8);
                noiseRB.Checked = !Convert.ToBoolean((byte)row[45] & 16);
                noiseRC.Checked = !Convert.ToBoolean((byte)row[45] & 32);
                toneLD.Checked = !Convert.ToBoolean((byte)row[46] & 1);
                toneLE.Checked = !Convert.ToBoolean((byte)row[46] & 2);
                toneLF.Checked = !Convert.ToBoolean((byte)row[46] & 4);
                noiseLD.Checked = !Convert.ToBoolean((byte)row[46] & 8);
                noiseLE.Checked = !Convert.ToBoolean((byte)row[46] & 16);
                noiseLF.Checked = !Convert.ToBoolean((byte)row[46] & 32);
                toneRD.Checked = !Convert.ToBoolean((byte)row[47] & 1);
                toneRE.Checked = !Convert.ToBoolean((byte)row[47] & 2);
                toneRF.Checked = !Convert.ToBoolean((byte)row[47] & 4);
                noiseRD.Checked = !Convert.ToBoolean((byte)row[47] & 8);
                noiseRE.Checked = !Convert.ToBoolean((byte)row[47] & 16);
                noiseRF.Checked = !Convert.ToBoolean((byte)row[47] & 32);

                nudNoisePeriodR1.Value = (byte)row[48];
                nudEnvelopePeriodCourseR1.Value = (byte)row[49];
                nudEnvelopePeriodFineR1.Value = (byte)row[50];

                chkContR1.Checked = Convert.ToBoolean((byte)row[51] & 8);
                chkAttR1.Checked = Convert.ToBoolean((byte)row[51] & 4);
                chkAltR1.Checked = Convert.ToBoolean((byte)row[51] & 2);
                chkHoldR1.Checked = Convert.ToBoolean((byte)row[51] & 1);

                nudNoisePeriodL2.Value = (byte)row[52];
                nudEnvelopePeriodCourseL2.Value = (byte)row[53];
                nudEnvelopePeriodFineL2.Value = (byte)row[54];

                chkContL2.Checked = Convert.ToBoolean((byte)row[55] & 8);
                chkAttL2.Checked = Convert.ToBoolean((byte)row[55] & 4);
                chkAltL2.Checked = Convert.ToBoolean((byte)row[55] & 2);
                chkHoldL2.Checked = Convert.ToBoolean((byte)row[55] & 1);

                nudNoisePeriodR2.Value = (byte)row[56];
                nudEnvelopePeriodCourseR2.Value = (byte)row[57];
                nudEnvelopePeriodFineR2.Value = (byte)row[58];

                chkContR2.Checked = Convert.ToBoolean((byte)row[59] & 8);
                chkAttR2.Checked = Convert.ToBoolean((byte)row[59] & 4);
                chkAltR2.Checked = Convert.ToBoolean((byte)row[59] & 2);
                chkHoldR2.Checked = Convert.ToBoolean((byte)row[59] & 1);

                nudDelay.Value = (byte)row[60];
            }
            else
            {
                MessageBox.Show("No row selected");
            }

        }

        private void saveRowButton_Click(object sender, EventArgs e)
        {
            DataRow row;
            //bring data from row back into fields
            if (dgvSequence.CurrentRow != null)
            {
                row = dataTable1.Rows[dgvSequence.CurrentRow.Index];

                Byte envelopeShapeCycleL1 = 0;
                if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
                if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
                if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
                if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

                Byte envelopeShapeCycleR1 = 0;
                if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
                if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
                if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
                if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

                Byte envelopeShapeCycleL2 = 0;
                if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
                if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
                if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
                if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

                Byte envelopeShapeCycleR2 = 0;
                if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
                if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
                if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
                if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }

                Byte enableLeft1 = 0;
                Byte enableLeft2 = 0;
                Byte enableRight1 = 0;
                Byte enableRight2 = 0;

                //AY1
                if (!toneLA.Checked) { enableLeft1 |= 1; }
                if (!toneLB.Checked) { enableLeft1 |= 2; }
                if (!toneLC.Checked) { enableLeft1 |= 4; }
                if (!noiseLA.Checked) { enableLeft1 |= 8; }
                if (!noiseLB.Checked) { enableLeft1 |= 16; }
                if (!noiseLC.Checked) { enableLeft1 |= 32; }

                //AY2
                if (!toneRA.Checked) { enableRight1 |= 1; }
                if (!toneRB.Checked) { enableRight1 |= 2; }
                if (!toneRC.Checked) { enableRight1 |= 4; }
                if (!noiseRA.Checked) { enableRight1 |= 8; }
                if (!noiseRB.Checked) { enableRight1 |= 16; }
                if (!noiseRC.Checked) { enableRight1 |= 32; }

                //AY3
                if (!toneLD.Checked) { enableLeft2 |= 1; }
                if (!toneLE.Checked) { enableLeft2 |= 2; }
                if (!toneLF.Checked) { enableLeft2 |= 4; }
                if (!noiseLD.Checked) { enableLeft2 |= 8; }
                if (!noiseLE.Checked) { enableLeft2 |= 16; }
                if (!noiseLF.Checked) { enableLeft2 |= 32; }

                //AY4
                if (!toneRD.Checked) { enableRight2 |= 1; }
                if (!toneRE.Checked) { enableRight2 |= 2; }
                if (!toneRE.Checked) { enableRight2 |= 4; }
                if (!noiseRD.Checked) { enableRight2 |= 8; }
                if (!noiseRE.Checked) { enableRight2 |= 16; }
                if (!noiseRF.Checked) { enableRight2 |= 32; }

                //byte[] buffer = new byte[60];

                row[0] = (byte)'C';
                row[1] = (byte)'B';
                row[2] = (byte)'1';
                row[3] = (byte)':';
                row[4] = (byte)nudTonePeriodCourseLA.Value;
                row[5] = (byte)nudTonePeriodCourseLB.Value;
                row[6] = (byte)nudTonePeriodCourseLC.Value;
                row[7] = (byte)nudTonePeriodCourseLD.Value;
                row[8] = (byte)nudTonePeriodCourseLE.Value;
                row[9] = (byte)nudTonePeriodCourseLF.Value;
                row[10] = (byte)nudTonePeriodFineLA.Value;
                row[11] = (byte)nudTonePeriodFineLB.Value;
                row[12] = (byte)nudTonePeriodFineLC.Value;
                row[13] = (byte)nudTonePeriodFineLD.Value;
                row[14] = (byte)nudTonePeriodFineLE.Value;
                row[15] = (byte)nudTonePeriodFineLF.Value;
                row[16] = (byte)((byte)nudVolumeLA.Value | (byte)cboVolFixedVarLA.SelectedIndex << 4);
                row[17] = (byte)((byte)nudVolumeLB.Value | (byte)cboVolFixedVarLB.SelectedIndex << 4);
                row[18] = (byte)((byte)nudVolumeLC.Value | (byte)cboVolFixedVarLC.SelectedIndex << 4);
                row[19] = (byte)((byte)nudVolumeLD.Value | (byte)cboVolFixedVarLD.SelectedIndex << 4);
                row[20] = (byte)((byte)nudVolumeLE.Value | (byte)cboVolFixedVarLE.SelectedIndex << 4);
                row[21] = (byte)((byte)nudVolumeLF.Value | (byte)cboVolFixedVarLF.SelectedIndex << 4);
                row[22] = (byte)nudTonePeriodCourseRA.Value;
                row[23] = (byte)nudTonePeriodCourseRB.Value;
                row[24] = (byte)nudTonePeriodCourseRC.Value;
                row[25] = (byte)nudTonePeriodCourseRD.Value;
                row[26] = (byte)nudTonePeriodCourseRE.Value;
                row[27] = (byte)nudTonePeriodCourseRF.Value;
                row[28] = (byte)nudTonePeriodFineRA.Value;
                row[29] = (byte)nudTonePeriodFineRB.Value;
                row[30] = (byte)nudTonePeriodFineRC.Value;
                row[31] = (byte)nudTonePeriodFineRD.Value;
                row[32] = (byte)nudTonePeriodFineRE.Value;
                row[33] = (byte)nudTonePeriodFineRF.Value;
                row[34] = (byte)((byte)nudVolumeRA.Value | (byte)cboVolFixedVarRA.SelectedIndex << 4);
                row[35] = (byte)((byte)nudVolumeRB.Value | (byte)cboVolFixedVarRB.SelectedIndex << 4);
                row[36] = (byte)((byte)nudVolumeRC.Value | (byte)cboVolFixedVarRC.SelectedIndex << 4);
                row[37] = (byte)((byte)nudVolumeRD.Value | (byte)cboVolFixedVarRD.SelectedIndex << 4);
                row[38] = (byte)((byte)nudVolumeRE.Value | (byte)cboVolFixedVarRE.SelectedIndex << 4);
                row[39] = (byte)((byte)nudVolumeRF.Value | (byte)cboVolFixedVarRF.SelectedIndex << 4);
                row[40] = (byte)nudNoisePeriodL1.Value;
                row[41] = (byte)nudEnvelopePeriodCourseL1.Value;
                row[42] = (byte)nudEnvelopePeriodFineL1.Value;
                row[43] = envelopeShapeCycleL1;
                row[44] = enableLeft1;
                row[45] = enableRight1;
                row[46] = enableLeft2;
                row[47] = enableRight2;
                row[48] = (byte)nudNoisePeriodR1.Value;
                row[49] = (byte)nudEnvelopePeriodCourseR1.Value;
                row[50] = (byte)nudEnvelopePeriodFineR1.Value;
                row[51] = envelopeShapeCycleR1;
                row[52] = (byte)nudNoisePeriodL2.Value;
                row[53] = (byte)nudEnvelopePeriodCourseL2.Value;
                row[54] = (byte)nudEnvelopePeriodFineL2.Value;
                row[55] = envelopeShapeCycleL2;
                row[56] = (byte)nudNoisePeriodR2.Value;
                row[57] = (byte)nudEnvelopePeriodCourseR2.Value;
                row[58] = (byte)nudEnvelopePeriodFineR2.Value;
                row[59] = envelopeShapeCycleR2;
                row[60] = nudDelay.Value;
            }
        }

        private void mergeSequenceItemsButton_Click(object sender, EventArgs e)
        {
            if (dgvSequence.SelectedRows.Count == 2)
            {
                dgvSequence.SelectedRows[0].Cells[5].Value = dgvSequence.SelectedRows[1].Cells[4].Value;    //copy 1:a to 0:b   course left
                dgvSequence.SelectedRows[0].Cells[11].Value = dgvSequence.SelectedRows[1].Cells[10].Value;    //copy 1:a to 0:b fine left
                dgvSequence.SelectedRows[0].Cells[23].Value = dgvSequence.SelectedRows[1].Cells[22].Value;    //copy 1:a to 0:b course right
                dgvSequence.SelectedRows[0].Cells[29].Value = dgvSequence.SelectedRows[1].Cells[28].Value;    //copy 1:a to 0:b course right
                dgvSequence.Rows.Remove(dgvSequence.SelectedRows[1]);
                dgvSequence.SelectedRows[0].Selected = true;
                editRowButton.PerformClick();
            }
            else if (dgvSequence.SelectedRows.Count == 3)
            {
                dgvSequence.SelectedRows[0].Cells[5].Value = dgvSequence.SelectedRows[1].Cells[4].Value;    //copy 1:a to 0:b   course left
                dgvSequence.SelectedRows[0].Cells[11].Value = dgvSequence.SelectedRows[1].Cells[10].Value;    //copy 1:a to 0:b fine left
                dgvSequence.SelectedRows[0].Cells[23].Value = dgvSequence.SelectedRows[1].Cells[22].Value;    //copy 1:a to 0:b course right
                dgvSequence.SelectedRows[0].Cells[29].Value = dgvSequence.SelectedRows[1].Cells[28].Value;

                dgvSequence.SelectedRows[0].Cells[6].Value = dgvSequence.SelectedRows[2].Cells[4].Value;    //copy 1:a to 0:b   course left
                dgvSequence.SelectedRows[0].Cells[12].Value = dgvSequence.SelectedRows[2].Cells[10].Value;    //copy 1:a to 0:b fine left
                dgvSequence.SelectedRows[0].Cells[24].Value = dgvSequence.SelectedRows[2].Cells[22].Value;    //copy 1:a to 0:b course right
                dgvSequence.SelectedRows[0].Cells[30].Value = dgvSequence.SelectedRows[2].Cells[28].Value;

                dgvSequence.Rows.Remove(dgvSequence.SelectedRows[1]);
                dgvSequence.Rows.Remove(dgvSequence.SelectedRows[1]);
                dgvSequence.SelectedRows[0].Selected = true;
                editRowButton.PerformClick();
            }
            else
            {
                MessageBox.Show("Merging of 2 or 3 rows supported");
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Sequence files (*.seq)|*.seq";
            saveFileDialog1.DefaultExt = "*.seq";
            saveFileDialog1.FileName = "";
            saveFileDialog1.ShowDialog();
            SequenceDataSet.WriteXml(saveFileDialog1.FileName, XmlWriteMode.IgnoreSchema);
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Sequence files (*.seq)|*.seq";
            openFileDialog1.FileName = "";
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                SequenceDataSet.Clear();
                SequenceDataSet.ReadXml(openFileDialog1.FileName, XmlReadMode.Auto);
            }
        }

        private void progressBarTimer_Tick(object sender, EventArgs e)
        {
            int incrementValue = progressBarTimer.Interval;
            if (pbConnect.Value + incrementValue < pbConnect.Maximum)
            {
                pbConnect.Value += incrementValue;
            }
            else
            {
                pbConnect.Value = pbConnect.Maximum;
            }
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            PopulateSerialPorts();
        }

        private void stopSequenceButton_Click(object sender, EventArgs e)
        {
            stop = true;
        }

        private void CreateAssemblyButton_Click(object sender, EventArgs e)
        {
            MemoryStream stream = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stream);
            DataRow row;

            for (int i = 0; i < dataTable1.Rows.Count; i++)
            {
                //store row as raw byte data
                row = dataTable1.Rows[i];
                //nudTonePeriodCourseLA.Value = (byte)row[4];
                //nudDelay.Value = (byte)row[60];

                for (int j = 4; j < 61; j++)
                {
                    //sb.Append(string.Format("{0:X2}",(byte)row[j]));
                    writer.Write((byte)row[j]);
                }
                
                //pad out the rest of the 64 bytes for easy boundary management
                //sb.Append("000");
                writer.Write((byte)0);
                writer.Write((byte)0);
                writer.Write((byte)0);
                writer.Write((byte)0);
                writer.Write((byte)0);
                writer.Write((byte)0);
                if (i == dataTable1.Rows.Count - 1)  //last row
                {
                    //Use "FF" to mark end
                    writer.Write((byte)255);
                }
                else
                {
                    writer.Write((byte)0);
                }
            }
            Assembly aOut = new Assembly();
            //aOut.assemblyRichText.Text = sb.ToString();
            
            aOut.bytes = stream.ToArray();
            string tmp = BitConverter.ToString(aOut.bytes);
            //aOut.assemblyRichText.Text = string.Join(Environment.NewLine,Regex.Split(tmp, "(?<=^(.{48})+)"));            // "(?<=^(.{48})+)"
            aOut.assemblyRichText.Text = Regex.Replace(tmp, "(.{48})","$1\n");
            aOut.Show(this);
        }   
    }
}
